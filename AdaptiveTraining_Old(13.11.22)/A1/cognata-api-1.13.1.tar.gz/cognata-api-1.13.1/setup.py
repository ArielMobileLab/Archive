# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import setuptools
import cognata_api

with open("DESCRIPTION.md", 'r') as description_file:
    long_description = description_file.read()

with open("requirements.txt", 'r') as requirements_file:
    requirements_list = requirements_file.read().splitlines()

setuptools.setup(
    name="cognata-api",
    version=cognata_api.__version__,
    author="Cognata Ltd.",
    author_email='support@cognata.com',
    description="Package for python integration with CognataStudio",
    packages=setuptools.find_packages(),
    python_requires='>=3.6',
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3.6",
        "License :: Proprietary License",
        "Operating System :: OS Independent"
    ],
    install_requires=requirements_list,
    data_files=["DESCRIPTION.md",
        "LICENSE",
        "requirements.txt"
    ],
    url='https://www.cognata.com'
)
