# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
# This tutorial demonstrate how to build automated simulation runs using cognata API.

# This tutorial was written in python 2.7.12
# Enjoy!
#
# * Get ego cars list
# * Find the Ego car named "COG-CAMRADARLIDARGPS1"
# * Get AI cars list
# * Find the AI car named "AISUV"
# * Define a sensors preset "DemoPreset" for "AISUV" with camera and GPS
# * Define a scenario "DemoScenario" with start point, end point, spawn area and dynamic objects
# * Create a new simulation based on scenario "DemoScenario" (keep <sim ID>)
# * Run a simulation using <sim ID> with selected client version (keep <run ID>)
# * Select an existing simulation run using <run ID>
# * Wait for simulation run <run ID> to complete
# * Download simulation run Cognata Engine Log using <run ID>
# * Rerun simulation (keep <run2 ID>) and wait for it to complete
# * Download simulation run Cognata Engine Log using <run2 ID>

# Need to sudo pip install requests
import re
import requests
from os import path, environ
from datetime import datetime
from typing import List, Optional
from collections import namedtuple
import sys
import time
import json
from functools import wraps
import inspect
import getpass
import io
from requests_toolbelt import MultipartEncoder

# Get Azure Storage Account link by modifying the follow_redirects to False
follow_redirects=False

_EXTERNAL_PROXY_TRACKING_TOKEN_ENV_VAR = "STUDIO_PROXY_TRACKING_TOKEN"
_AUTHORIZATION_HEADER_NAME = "Cognata-Authorization"

class APICognataTutorialProgram(object):
    @classmethod
    def main(cls):
        """  Main tutorial program

        1. Setup cognata requests api object cognata_api
        2. Get full list of ego cars from catalog
        3. Find and retrieve ego car by ego car SKU
        4. Get full list of ai cars from catalog
        5. Find and retrieve ai car by ai car SKU
        6. Get camera sensor with SKU COGCAM
        7. Get GPS sensor with SKU COGGPS
        8. Create GPS sensor for preset
        9. Create camera sensor for preset
        10. Create new sensors preset
        11. Create all scenario parameters (steps 12 to 16)
        12. Define termination conditions
        13. Define map's terrain
        14. Define cartasian parameters
        15. Define spawn areas
        16. Define ego car sensors preset
        18. Define dynamic objects
        19. Create the scenario - Calls all of the Cognata objects created above
        20. Generate and run a simulation from the new created scenario, NOTICE that getting simulation run id from generate response you must call another API call
        21. rerun a simulation
        22. Get a list of simulation files and download a system file
        """
        # 1. Setup cognata requests api object cognata_api
        # client_url = raw_input("Enter Cognata API URL: ")
        client_url = sys.argv[1]
        # client_user = raw_input("Enter user: ")
        client_user = sys.argv[2]
        # client_password = getpass.getpass("Enter password: ")
        client_password = sys.argv[3]
        # client_queue = raw_input("Enter queue name to use: ")
        client_queue = ''
        cognata_api = CognataRequests(client_url, client_user, client_password)
        if not cognata_api.is_logged_in:
            print("Not logged in!")
            exit(1)

        if len(sys.argv) > 4:
            client_queue = sys.argv[4]
            print(client_queue)

        # 2. Get full list of ego cars from catalog
        ego_car_list = cognata_api.get_ego_cars_list()
        print("Ego car's presets:")
        for preset in ego_car_list:
            print(preset["name"])
        print()
        # 3. Find and retrieve ego car by ego car SKU
        ego_car_sku = "CAMRADAR"
        print("Find Ego car preset: ", ego_car_sku)
        ego_car = cognata_api.find_ego_car(ego_car_sku)
        print("Found: ", ego_car["catalogData"]["name"])
        # 4. Get full list of ai cars from catalog
        ai_car_list = cognata_api.get_ai_cars_list()
        print("AI car list:")
        for car in ai_car_list:
            print(car["name"])
        print()
        # 5. Find and retrieve ai car by ai car SKU
        ai_car = cognata_api.find_ai_car("AISUV")
        print("AI car AISUV:")
        print(ai_car["sku"], " - ", ai_car["description"])
        # 6. Get camera sensor with SKU COGCAM
        camera_sensor = cognata_api.get_sensor("camera", "COGCAM")
        print("Camera sensor COGCAM:")
        print(camera_sensor["catalogData"]["name"], " - ", camera_sensor["catalogData"]["description"])
        # 7. Get GPS sensor with SKU COGGPS
        gps_sensor = cognata_api.get_sensor("gps", "COGGPS")
        print("GPS sensor COGGPS:")
        print(gps_sensor["catalogData"]["name"], " - ", gps_sensor["catalogData"]["description"])

        # 8. Create GPS sensor for preset
        sensors_preset = []
        gps_preset = CognataSensor(sensor_type="gps",
                                   sensor_sku="COGGPS",
                                   sensor_id="GPS0001",
                                   sensor_record={"gps": True},
                                   sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                                   sensor_position={"x": -1.29, "z": 1.7, "y": 0.03})
        sensors_preset.append(gps_preset.get_sensor_for_preset())

        # 9. Create camera sensor for preset
        camera_preset = CognataSensor(sensor_type="camera",
                                      sensor_sku="COGCAM",
                                      sensor_id="CAM0001",
                                      sensor_record={"rgb": True, "bounding_box": True, "semantic_segmentation": False,
                                                     "depth_map": False, "photo_realism": False},
                                      sensor_rotation={"roll": 0, "yaw": 0, "pitch": 0},
                                      sensor_position={"x": 0.49, "z": 1.7, "y": 0.03})
        sensors_preset.append(camera_preset.get_sensor_for_preset())
        # 10. Create new sensors preset
        saved_preset = cognata_api.create_sensors_preset(preset_name="DemoPreset",
                                                         ai_car_type="AISUV",
                                                         sensors=sensors_preset,
                                                         preset_description="Demo preset description")
        new_preset_sku = saved_preset["sku"]
        print("new_preset_sku", new_preset_sku)

        # 11. Create all scenario parameters (steps 12 to 16)

        # 12. Define termination conditions
        simulationTerminationConditions = CognataSimulationTermination(timeout=12, distance=500)

        # 13. Define map's terrain
        terrain_object = CognataTerrain(id="hdm-EU20201842", mode="")

        print("Possible weather conditions:", cognata_api.get_weather_conditions())
        print("Possible time of day:", cognata_api.get_time_of_day())

        # 14. Define cartasian parameters
        cartasian_object = CognataCartesianParams(["6789"], time_of_day=["morning"], weather_conditions=["clear"])
        # 15. Define spawn areas
        spawn_areas = []
        spawn_shapes = []
        spawn_shape_object = CognataShape(id="1", type="polygon",
                                          positions=[
                                                {
                                                    "lat" : 50.06144284761036,
                                                    "lng" : 8.67398165218583
                                                },
                                                {
                                                    "lat" : 50.06146695401278,
                                                    "lng" : 8.672774658129129
                                                },
                                                {
                                                    "lat" : 50.06124655216819,
                                                    "lng" : 8.67274247162095
                                                },
                                                {
                                                    "lat" : 50.06126032731316,
                                                    "lng" : 8.674024567530068
                                                },
                                                {
                                                    "lat" : 50.06144284761036,
                                                    "lng" : 8.674078211710366
                                                }])
        spawn_shapes.append(spawn_shape_object)

        spawn_object = CognataSpawnArea  (name="Spawn area 0001",
                                          id="Spawn area 0001",
                                          end_position={"lane": 3, "sectionId": 2, "fragmentId": 1210},
                                          start_position={"lane": 3, "sectionId": 2, "fragmentId": 1170},
                                          comfortable_braking={"max": 2, "min": 2},
                                          lane_change_speed={"max": 0.25, "min": 0.25},
                                          politeness={"max": 20, "min": 20},
                                          initial_speed={"max": 30, "min": 20},
                                          speed={"max": 30, "min": 20},
                                          time_to_collision={"max": 1.5, "min": 1.5},
                                          distribution=[CognataRequests.get_brand(brand_label="Generic Combi Black"),
                                                        CognataRequests.get_brand(brand_label="Generic SUV White")],
                                          object_count=2,
                                          shapes=spawn_shapes
                                          # color="#c42339",
        )
        spawn_areas.append(spawn_object)

        # 16. Define ego car sensors preset
        ego_car_object = CognataEgoCar(ego_car_sku=new_preset_sku,
                                       starting_point={"lane": -3, "roadId": "1", "firstSectionID": 1, "lastSectionID": 1,
                                                       "segmentId": "1_1_1_-3", "lng": 8.67646097254692, "lat": 50.06138430343974},
                                       ending_point={"lane":- 3, "roadId": "1", "firstSectionID": 4, "lastSectionID": 4,
                                                     "segmentId": "1_4_4_-4", "lng": 8.669625744745645, "lat": 50.06132920297858},
                                       initial_speed=15,
                                       desired_speed=15,
                                       lane_change_speed=0.25,
                                       time_to_collision=1.5,
                                       comfortable_braking=2,
                                       politeness=20
                                       )

        # 17. Define empty analysis rules objects
        analysis_rules = []

        # 18. Define dynamic objects
        dynamic_objects = []
        dynamic_position_start = CognataPositionObject(lane=-3,
                                                       roadId="1",
                                                       firstSectionID=3,
                                                       lastSectionID=3,
                                                       lat=50.061355011569646,
                                                       lng=8.672333304709355)
        dynamic_position_end = CognataPositionObject(lane=-4,
                                                     roadId="1",
                                                     firstSectionID=3,
                                                     lastSectionID=3,
                                                     lat=50.06134812401125,
                                                     lng=8.67045575839893)
        full_dynamic_position = {
            "start": dynamic_position_start,
            "end": dynamic_position_end
        }
        script_object1 = CognataObjectScript(simulationTimeTrigger=0,
                                             actionType="setDesiredSpeed",
                                             actionValue=30)
        script_object2 = CognataObjectScript(simulationTimeTrigger=0,
                                             actionType="setInitialSpeed",
                                             actionValue=30)
        dynamic_scripts = {
            "0": script_object1,
            "1": script_object2
        }
        dynamic_object = CognataDynamicObject(name="Dynamic object 0001",
                                              lane=-3,
                                              type="Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black",
                                              position=full_dynamic_position,
                                              scripts=dynamic_scripts)
        dynamic_objects.append(dynamic_object)

        # 19. Create the scenario
        # Use all of the Cognata objects created above
        demo_scenario = CognataScenario(name="DemoScenario",
                                        description="Demo Scenario with Highway map, spawn area, starting and ending points",
                                        simulation_termination=simulationTerminationConditions,
                                        cartesian_params=cartasian_object,
                                        spawn_objects=spawn_areas,
                                        ego_car=ego_car_object,
                                        terrain=terrain_object,
                                        analysis_rules=analysis_rules,
                                        dynamic_objects=dynamic_objects,
                                        queues=[client_queue])
        demo_scenario_parsed = demo_scenario.to_json()

        saved_scenario = cognata_api.create_scenario(demo_scenario_parsed)
        new_scenario_id = saved_scenario["_id"]
        print("new_scenario_id", new_scenario_id)

        # 20. Generate and run a simulation from the new created scenario
        client_version = ""
        generate_simulation_response = cognata_api.generate_simulation(demo_scenario_parsed, client_version)

        # Notice that getting simulation run id from generate response you must call another API call
        new_simulation_run_id = cognata_api.get_simulation_run_id(generate_simulation_response)
        print(datetime.fromtimestamp(time.time()), "Started simulation run", new_simulation_run_id)
        sim_run_end_status = cognata_api.wait_for_simulation_to_finish(new_simulation_run_id)
        print(datetime.fromtimestamp(time.time()), "Simulation run", new_simulation_run_id, "finished with status", sim_run_end_status)
        print()
        print("Simulation run created artifacts:")
        for artifact in cognata_api.get_simulation_run_files_list(new_simulation_run_id):
            print(artifact["group_name"])
            for file in artifact["files"]:
                print("- ", file["file_name"], " size: ", file["file_size"])
        print("Download CognataEngineLog.json:")
        print(cognata_api.download_simulation_run_file(new_simulation_run_id, "CognataEngineLog.json", allow_redirects=follow_redirects))

        # 21. rerun a simulation
        rerun_sim_id = cognata_api.rerun_simulation(new_simulation_run_id)
        print()
        print()
        print("Rerun simulation id", rerun_sim_id, "started at", datetime.fromtimestamp(time.time()))

        sim_rerun_end_status = cognata_api.wait_for_simulation_to_finish(rerun_sim_id)
        print(datetime.fromtimestamp(time.time()), "Simulation rerun", rerun_sim_id, "finished with status", sim_rerun_end_status)

        # 22. Get a list of simulation files and download a system file
        print("Simulation rerun created artifacts:")
        for artifact in cognata_api.get_simulation_run_files_list(rerun_sim_id):
            print(artifact["group_name"])
            for file in artifact["files"]:
                print("- ", file["file_name"], " size: ", file["file_size"])
        print("Download rerun CognataEngineLog.json:")
        print(cognata_api.download_simulation_run_file(rerun_sim_id, "CognataEngineLog.json", allow_redirects=follow_redirects))


class Singleton(object):
    """ Just create the CognataRequests class a singleton """
    _instances = {}

    def __new__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = object.__new__(cls)
        return cls._instances[cls]

    @classmethod
    def get_instance(cls):
        return cls._instances[cls]


def initializer(func):
    """
    Automatically assigns the parameters of the wrapped function.
    Used to decorate __init__ initializer of a all CognataAttributes classes.
    """
    names, varargs, keywords, defaults = inspect.getargspec(func)

    @wraps(func)
    def wrapper(self, *args, **kargs):
        # iterate
        for name, arg in list(zip(names[1:], args)) + list(kargs.items()):
            setattr(self, name, arg)

        if defaults:
            for name, default in zip(reversed(names), reversed(defaults)):
                if not hasattr(self, name):
                    setattr(self, name, default)
        func(self, *args, **kargs)
    return wrapper


class CognataAttributes(object):
    """
    Parse object attributes in dictionary format (ready for json API request)
    Important: All Cognata Attributes classes properties' names MUST NOT change !!!
    Based on those names the json is generated
    e.g. input class CognataScenario inherits from CognataAttributes class:
        self.name = <string> : native value
        self.cartesian_params = <class CognataCartesianParams> : other CognataAttributes class object
        self.spawn_objects = [<class CognataSpawnArea>] : list of CognataAttributes class objects

    e.g. output of scenario_object.to_json():
        {
        "name": name value,
        "cartesian_params": { : All attributes of CognataCartesianParams class in dictionary
                            "seed" : [seed value]
                            "time_of_day": [time_of_day value]
                            "weather_conditions": [weather condition value]
                            },
        "spawn_objects": [{ : All attributes of CognataSpawnArea class in dictionary
                            "name": spawn object name value,
                            "object_count": object count value of spawn area
                            "start_position": start position object values,
                             # Rest of spawn area attributes ...
                         }]
        }
    """
    @staticmethod
    def __parsed_object(object_to_parse):
        if isinstance(object_to_parse, list):
            return_object = []
            for inner_object in object_to_parse:
                if isinstance(inner_object, CognataAttributes):
                    return_object.append(inner_object.to_json())
                else:
                    return_object.append(inner_object)
        elif isinstance(object_to_parse, CognataAttributes):
            return_object = object_to_parse.to_json()
        elif isinstance(object_to_parse, dict):
            return_object = {}
            for dict_key, dict_value in object_to_parse.items():
                return_object[dict_key] = CognataAttributes.__parsed_object(dict_value)
        else:
            return_object = object_to_parse
        return return_object

    def to_json(self):
        """ Parse Cognata Attributes object to json """
        parsed_object = {}
        for key, value in vars(self).items():
            parsed_object[key] = CognataAttributes.__parsed_object(value)
        return parsed_object

# Next are all classes that describe Cognata modules to create simulations


class CognataSimulationTermination(CognataAttributes):
    """ Cognata Simulation termination conditions

    :type timeout: integer
    :param timeout: timeout termination condition [secs]
    :type distance: integer
    :param distance: distance termination condition [meters]

    {
        "distance": 500,
        "timeout": 12
    }
    """
    @initializer
    def __init__(self, timeout, distance):
        pass


class CognataCartesianParams(CognataAttributes):
    """ CartesianParams cognata class

    :type seed: list of strings
    :param seed: a list of seed numbers
    :type time_of_day: a list of time of day
    :param time_of_day: list of string
    :type weather_conditions: a list of weather conditions
    :param weather_conditions: list of string

    {
        "time_of_day": [
            "morning"
        ],
        "seed": [
            "6789"
        ],
        "weather_conditions": [
            "clear"
        ]
    }
    """
    @initializer
    def __init__(self, seed, time_of_day, weather_conditions):
        pass


class CognataSpawnArea(CognataAttributes):
    """ Cognata Spawn Area

    :type name: string
    :param name: name of the spawn are
    :type object_count: integer
    :param object_count: number of objects in the spawn are
    :type start_position: dictionary {<string>: <integer>}
    :param start_position: starting position of the spawn area.
        keys: "lane", "sectionId" and "fragmentId"
    :type end_position: dictionary {<string>: <integer>}
    :param end_position: ending position of the spawn area.
        keys: "lane", "sectionId" and "fragmentId"
    :type comfortable_braking:  dictionary {<string>: <integer>}
    :param comfortable_braking: comfortable breaking attribute of the spawn area.
        keys: "min" and "max", range: [0,4]
    :type lane_change_speed: dictionary {<string>: <integer>}
    :param lane_change_speed: lane change speed attribute of the spawn area.
        keys: "min" and "max", range: [0.1,0.5]
    :type politeness: dictionary {<string>: <integer>}
    :param politeness: politeness of the drivers in the spawn area.
        keys: "min" and "max", range: [0,1]
    :type initial_speed: dictionary {<string>: <integer>}
    :param initial_speed: initial speed of the cars in the spawn area.
         keys: "min" and "max"
    :type speed: dictionary {<string>: <integer>}
    :param speed:
        keys: "min" and "max"
    :type time_to_collision: dictionary {<string>: <integer>}
    :param time_to_collision: time to collision attribute of the spawn area
        keys: "min" and "max"
    :type distribution: list of dictionaries {<string>: <string>}
    :param distribution: the distribution of the cars in the spawn area.
        dictionary keys: "value" and "label"

    {
        "comfortable_braking": {
            "max": 2,
            "min": 2
        },
        "time_to_collision": {
            "max": 1.5,
            "min": 1.5
        },
        "start_position": {
            "lane": 3,
            "fragmentId": 1170,
            "sectionId": 2
        },
        "initial_speed": {
            "max": 10,
            "min": 5
        },
        "speed": {
            "max": 30,
            "min"  : 20
        },
        "object_count": 2,
        "obj_type": "spawn_objects",
        "name": "Spawn area 0001",
        "end_position": {
            "lane": 3,
            "fragmentId": 1210,
            "sectionId": 2
        },
        "politeness": {
            "max": 20,
            "min": 20
        },
        "lane_change_speed": {
            "max": 0.25,
            "min": 0.25
        },
        "distribution": [
            {
                "value": "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_White",
                "label": "Generic Combi White"
            },
            {
                "value": "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black",
                "label": "Generic Combi Black"
            }
        ],
        "type": "cars"
    }
    """
    @initializer
    def __init__(self, name, id, object_count, start_position, end_position, comfortable_braking, lane_change_speed,
                 politeness, initial_speed, speed, time_to_collision, distribution, shapes, segments=None):
        self.type = "cars"
        self.obj_type = "spawn_objects"
        if not segments:
            self.segments=[]


class CognataShape(CognataAttributes):
    """ Cognata Shape class """
    @initializer
    def __init__(self, id, type, positions):
        pass

class CognataTerrain(CognataAttributes):
    """ Cognata map's Terrain

    :type id: string
    :param id: id of the map
    :type mode: string
    :param mode: the map mode to use
    reads map from database and initialize map's description, name and mode, all strings

    {
        "description": "Highway",
        "name": "Highway",
        "mode": "",
        "id": "hdm-EU20201842"
    }
    """
    @initializer
    def __init__(self, id, mode):
        cognata_request = CognataRequests.get_instance()
        if cognata_request:
            map_properties = cognata_request.find_map(id)
            self.description = map_properties["catalogData"]["description"]
            self.name = map_properties["catalogData"]["name"]
            self.mode = mode
            map_modes = map_properties["properties"]["scenario_template"]["terrain"]["modes"]
            print("Map modes:")
            for m in map_modes:
                print(m["label"])


class CognataEgoCar(CognataAttributes):
    """ Cognata ego car on the map properties

    :type ego_car_sku: string
    :param ego_car_sku: sku of car's preset as defined in database as a catalog object
    :type starting_point: dictionary {<string>: <integer>}
    :param starting_point: Starting point of ego car on the map
        keys: "lane", "sectionId" and "fragmentId"
    :type ending_point: dictionary {<string>: <integer>}
    :param ending_point: Ending point of ego car on the map
        keys: "lane", "sectionId" and "fragmentId"
    :type initial_speed: integer
    :param initial_speed: initial speed of ego car
    :type desired_speed: integer
    :param desired_speed: initial speed of ego car

    {
        "initial_speed": 10,
        "ending_point": {
            "lat": 50.0608926780761,
            "lane": 3,
            "fragmentId": 1299,
            "lng": 8.659265041351318,
            "sectionId": 2
        },
        "desired_speed": 25,
        "ego_car_sku": "DEMOPRES94",
        "starting_point" : {
            "lat" : 50.06138430343974,
            "lng" : 8.67646097254692,
            "roadId" : "1",
            "firstSectionID" : 1,
            "lastSectionID" : 1,
            "segmentId" : "1_1_1_-3",
            "lane" : -3
        }
    }
    """
    @initializer
    def __init__(self, ego_car_sku, starting_point, ending_point, initial_speed, desired_speed,
                 lane_change_speed, time_to_collision, comfortable_braking, politeness):
        pass


class CognataScenario(CognataAttributes):
    """ Cognata Scenario attributes:

    :type name: string
    :param name: name of the scenario
    :type description: string
    :param description: description of the scenario: string
    :type simulation_termination: CognataSimulationTermination object
    :param simulation_termination: simulation termination conditions
    :type cartesian_params: CognataCartesianParams object
    :param cartesian_params: Scenario cartesian parameters
    :type ego_car: CognataEgoCar object
    :param ego_car: Ego car sensors preset to be used
    :type terrain: CognataTerrain object
    :param terrain: Map terrain
    :type spawn_objects: list of CognataSpawnArea objects
    :param spawn_objects: Scenario's spawn areas
    :type  dynamic_objects: list of CognataDynamicObject objects
    :param dynamic_objects: Scenario's dynamic objects
    :type analysis_rules: list of analysis rules objects
    :param analysis_rules: Scenario's analysis rules objects
    :type queues: list of strings
    :param queues: queue names

    {
        "cartesian_params": {
            "time_of_day": [
                "morning"
            ],
            "seed": [
                "6789"
            ],
            "weather_conditions": [
                "clear"
            ]
        },
        "simulation_termination": {
            "distance": 500,
            "timeout": 12
        },
        "description": "Demo Scenario with Highway map, spawn area, starting and ending points",
        "name": "DemoScenario",
        "ego_car": {
            "initial_speed": 10,
            "ending_point": {
                "lat": 50.0608926780761,
                "lane": 3,
                "fragmentId": 1299,
                "lng": 8.659265041351318,
                "sectionId": 2
            },
            "desired_speed": 25,
            "ego_car_sku": "DEMOPRES94",
            "starting_point": {
                "lat": 50.05945314300574,
                "lane": 3,
                "fragmentId": 1167,
                "lng": 8.654050827026367,
                "sectionId": 2
            }
        },
        "spawn_objects": [
            {
                "comfortable_braking": {
                    "max": 2,
                    "min": 2
                },
                "time_to_collision": {
                    "max": 1.5,
                    "min": 1.5
                },
                "start_position": {
                    "lane": 3,
                    "fragmentId": 1170,
                    "sectionId": 2
                },
                "initial_speed": {
                    "max": 10,
                    "min": 5
                },
                "speed": {
                    "max": 30,
                    "min": 20
                },
                "object_count": 2,
                "obj_type": "spawn_objects",
                "name": "Spawn area 0001",
                "end_position": {
                    "lane": 3,
                    "fragmentId": 1210,
                    "sectionId": 2
                },
                "politeness": {
                    "max": 20,
                    "min": 20
                },
                "lane_change_speed": {
                    "max": 0.25,
                    "min": 0.25
                },
                "distribution": [
                    {
                        "value": "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_White",
                        "label": "Generic Combi White"
                    },
                    {
                        "value": "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black",
                        "label": "Generic Combi Black"
                    }
                ],
                "type": "cars"
            }
        ],
        "terrain": {
            "description": "Highway",
            "name": "Highway",
            "mode": "",
            "id": "hdm-EU20201842"
        },
        "analysis_rules": [],
        "dynamic_objects": []
    }
    """
    @initializer
    def __init__(self, name, description, simulation_termination, cartesian_params, ego_car, terrain, queues=None, spawn_objects=[], dynamic_objects=[], analysis_rules=[]):
        if not queues or (len(queues) == 1 and not queues[0]):
            # set default queue to use to cloud
            self.queues = ["cloud"]


class CognataObjectScript(CognataAttributes):
    """ Cognata script for objects, used mostly for scripting dynamic objects

    :type simulationTimeTrigger: int
    :param simulationTimeTrigger: time to trigger the script after simulation start [seconds]
    :type actionType: string
    :param actionType: action type to trigger
    :type actionValue: int
    :param actionValue: action value to set

    {
        "simulationTimeTrigger" : 0,
        "actionType" : "setInitialSpeed",
        "actionValue" : 30
    }
    """
    @initializer
    def __init__(self, simulationTimeTrigger, actionType, actionValue):
        pass


class CognataPositionObject(CognataAttributes):
    """ Cognata position for objects, used by dynamic objects

    :type lane: int
    :param lane: lane position
    :type roadId: string
    :param roadId: road id position
    :type firstSectionID: int
    :param firstSectionID: first section id position
    :type lastSectionID: int
    :param firstSectionID: last section id position
    :type lng: float
    :param lng: longitude position
    :type lat: float
    :param lat:latitude position

    {
        "lane" : -3,
        "roadId" : "1",
        "firstSectionID" : 1,
        "lastSectionID" : 1,
        "lng" : 8.67542612772013,
        "lat" : 50.061393382448706
    }
    """

    @initializer
    def __init__(self, lane, roadId, firstSectionID, lastSectionID, lng, lat):
        pass

    def transform2LatLng(self, x, y, proj_string):
        """ transforms x and y points to latitude and longitude coordinate system

        this is a utility function to be used before calling API calls that expects lat and lng coordinates

        :type x: float/array of floats
        :param x: the x position
        :type y: float/array of floats
        :param y: the y position
        :type proj_string: string
        :param proj_string: defined projection function
        :returns: tuple of (lat, lng) or tuple of lat array and lng array ([lat1, lat2, lat3,...lani], [lng1, lng2, lng3,...lngi])
        :examples:
        map_properties = cognata_request.find_map(id)
        proj_string = map_properties["properties"]["projection"]
        single_point = transform2LatLng(80.4491882324219, 248.836410522461, proj_string)
        print(single_point))
        >> (11.587458419687241, 48.175826149544996)
        array_of_points = transform2LatLng([80.4491882324219, 81.8063049316406], [248.836410522461, 249.200820922852], proj_string)
        print(array_of_points))
        >> ([11.587458419687241, 11.58746393064327], [48.175826149544996, 48.17583823664222])
        """
        pass


class CognataDynamicObject(CognataAttributes):
    """ Cognata Dynamic Object

    :type name: string
    :param name: Name of the dynamic object
    :type lane int
    :param lane: lane number to place the dynamic object
    :type position: dictionary {string: CognataPositionObject object}
    :param position: Position of the dynamic object
    :type scripts: dictionary {string: CognataObjectScript}
    :param scripts: Dynamic objects scripts configuration
    :type type:
    :param type: Type (asset) of dynamic object

    {
        "name" : "Dynamic object 0001",
        "type" : "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black",
        "lane" : -3,
        "scripts" : {
            "0" : {
                "simulationTimeTrigger" : 0,
                "actionType" : "setDesiredSpeed",
                "actionValue" : 30
            },
            "1" : {
                "simulationTimeTrigger" : 0,
                "actionType" : "setInitialSpeed",
                "actionValue" : 30
            }
        },
        "obj_type" : "dynamic_objects",
        "position" : {
            "start" : {
                "lane" : -3,
                "roadId" : "1",
                "firstSectionID" : 1,
                "lastSectionID" : 1,
                "lng" : 8.67542612772013,
                "lat" : 50.061393382448706
            }
        },
        "icon" : "sedan"
    }
    """
    @initializer
    def __init__(self, name, lane, position, scripts, type):
        self.obj_type = "dynamic_objects"


class CognataAnalysisRulesObject(CognataAttributes):
    """ Cognata Analysis Rules Object
    """

    @initializer
    def __init__(self, name, orientation, lane, position, type):
        self.obj_type = "analysis_rules"


class CognataSensor(object):
    """ Cognata sensor properties:

    :type sensor_type: string
    :param sensor_type: one of "gps", "lidar", "radar" and "camera"
    :type sensor_sku: string
    :param sensor_sku: sku of sensor in database catalog object
    :type sensor_id: string
    :param sensor_id: sensor id, neme of sensor, identifies sensor in Studio UI
    :type sensor_record: dictionary {<string>:<boolean>}
    :param sensor_record: dictionary contains all sensor types to record in a simulation.
        keys are sensor type names,
        e.g. sensor_record={"rgb": True, "bounding_box": False}
    :type sensor_rotation: dictionary {<string>:<number>}
    :param sensor_rotation: sensor rotation on the car.
        keys: "yaw", "pitch" and "roll"
    :type sensor_position: dictionary {<string>:<number>}
    :param sensor_position: sensor position on the car.
        keys: "x", "y" and "z"
    """
    def __init__(self, sensor_type, sensor_sku, sensor_name, sensor_record=None, sensor_rotation=None,
                 sensor_position=None, **kwargs):
        # Make sure sensor type is lowercase, as required in backend
        sensor_type = sensor_type.lower()
        if sensor_type not in ["gps", "lidar", "radar", "camera", "ogt"]:
            raise ValueError(f"Given wrong sensor type {sensor_type}")

        cognata_request = CognataRequests.get_instance()
        self.sensor_meta_data = cognata_request.get_sensor(sensor_type, sensor_sku)
        self.name = sensor_name
        self.record = sensor_record

        # In case the sensor model should have fixed position, we prevent the user saving the preset
        # with rotation and position which are different than zero
        if self.sensor_meta_data.get("properties", {}).get("isFixedPosition") is True:
            # Combining both position objects into one
            # Checking sum of absolute values to identify if we need to reset values
            combined_position_objects = {**sensor_rotation, **sensor_position}
            combined_sum = sum([abs(e) for e in combined_position_objects.values()])
            if combined_sum > 0:
                sensor_rotation = {"roll": 0, "yaw": 0, "pitch": 0}
                sensor_position = {"x": 0, "z": 0, "y": 0}
                print(f"Sensor position and rotation for type '{sensor_type}' should be fixed - setting them to zero values")

        self.rotation = sensor_rotation
        self.position = sensor_position
        self.properties = {}
        self.quality = None
        additional_camera_props = ["quality", "display_monitor", "fullscreen"]
        if sensor_type == "camera":
            for k in additional_camera_props:
                if k in kwargs:
                    prop = kwargs.pop(k)
                    # Additional properties should be objects with definition
                    # for rgb, depth_map and heatMap. reject otherwise
                    # TODO: Make this assert work like the 'any' below:
                    # if any(s_type in sensor for s_type in IMAGE_OUTPUT_SENSORS):
                    assert isinstance(prop, dict) and ("rgb" in prop or "depth_map" in prop or "heatMap" in prop), \
                        f"Camera property '{k}' must be an object. Supported keys: 'rgb', 'depth_map' and 'heatMap'"
                    setattr(self, k, prop)

        self.__sku  = self.sensor_meta_data.get("catalogData", {}).get("sku", None)
        self.__type = self.sensor_meta_data.get("catalogData", {}).get("type", None)

    @property
    def record(self):
        return self.__sensor_record

    @property
    def rotation(self):
        return self.__sensor_rotation

    @property
    def position(self):
        return self.__sensor_position

    @record.setter
    def record(self, val):
        """ Setter of sensor record: dictionary with sensor specific record fields """
        if val:
            self.__sensor_record = val

    @rotation.setter
    def rotation(self, val):
        """ Setter of sensor rotation: dictionary with roll, yaw and pitch fields """
        if val:
            if not {"roll", "yaw", "pitch"}.symmetric_difference(set(val.keys())):
                self.__sensor_rotation = val
            else:
                raise ValueError("Sensor rotation must be dictionary with roll, yaw and pitch keys")

    @position.setter
    def position(self, val):
        """ Setter of sensor position: dictionary with x, y and z fields """
        if val:
            if not {"x", "y", "z"}.symmetric_difference(set(val.keys())):
                self.__sensor_position = val
            else:
                raise ValueError("Sensor position must be dictionary with x, y and z keys")

    def set_property(self, property_key, property_value):
        properties = self.sensor_meta_data.get("properties", {})
        properties_keys = list(properties.keys())
        if property_key not in properties_keys:
            raise ValueError(f"Can't set property {property_key}. Available properties are: {properties_keys}")
        self.properties[property_key] = property_value

    @classmethod
    def _make_sensor_data_from_model_props(cls, sensor_properties):
        """Extract default values from sensor model properties and set them to the corresponding field
        """
        # Fill sensor data with default values as they are in the server
        sensor_data = {}
        for prop_key in sensor_properties.keys():
            curr_prop = sensor_properties[prop_key]
            if isinstance(curr_prop, dict) and "default_value" in curr_prop:
                default_val = curr_prop["default_value"]
                if not (curr_prop.get('type') == 'cluster' and isinstance(default_val, list)):
                    # property is a simple property
                    sensor_data[prop_key] = default_val
                    continue
                # Since the addition of beams to radar, properties might be an array containing
                # nested properties (cluster) in the same structure of the general, 'known' properties.
                # In order to extract the default values of the nested properties look for
                # 'id' property inside the elements of the list and push all the sub-properties default values
                # to an object under the list id as key
                nested_default = []
                for sub_prop in default_val:
                    sub_prop_id = sub_prop.get('id', None)
                    if sub_prop_id is None:
                        # Assume none of the elements are properties
                        break
                    nested_default.append(cls._make_sensor_data_from_model_props(sub_prop.get('properties')))
                sensor_data[prop_key] = nested_default

        return sensor_data

    def get_sensor_for_preset(self):
        """ Return sensor object to be used in sensors preset
        {
            "sku": "COGCAM",
            "record": {
                "depth_map": false,
                "rgb": true,
                "semantic_segmentation": false,
                "bounding_box": false,
                "photo_realism": false
            },
            "sensor_data": {
                "fov": 50,
                "resolution": "960X540",
                "fps": 30
            },
            "name": "CognataCamera",
            "position": {
                "y": 0.03,
                "x": 0.49,
                "z": 1.695
            },
            "rotation": {
                "yaw": 0,
                "roll": 0,
                "pitch": 0
            },
            "type": "camera",
            "id": "CAM0676"
        }
        """
        sensor_properties = self.sensor_meta_data.get("properties", {})
        # Fill sensor data with default values as they are in the server
        sensor_data = self._make_sensor_data_from_model_props(sensor_properties)
        # In case user set other values to properties, use them
        sensor_data.update(self.properties)
        preset_object = {
            "name": self.name,
            "sku":  self.__sku,
            "type": self.__type,
            "record": self.record,
            "position": self.position,
            "rotation": self.rotation,
            "sensor_data": sensor_data
        }
        if self.quality:
            preset_object.update({"outputQuality": self.quality})
        if self.__type == "camera":
            preset_object.update({"fullScreen": getattr(self, "fullscreen", {"rgb": False})})
            preset_object.update({"displayMonitor":  getattr(self, "display_monitor", {"rgb": 0})})

        return preset_object

    def __str__(self):
        return json.dumps(self.get_sensor_for_preset())


class CognataRequests(Singleton):
    """ Main class to demonstrate use of Cognata API

        :type client_api_url: string
        :param client_api_url: api url used by client
        e.g. https://{client>-api.cognata-studio.com
        :type user: string
        :param user: Client username
        :type password: string
        :param password: Client password
        :type email: string
        :param email: Client's admin email
        :type request_timeout: integer
        :param request_timeout: Timeout for api requests in seconds, default value: 5
        :type  proxy_config: CognataRequests.ProxyConfig
        :param proxy_config: Configuration for proxy server, if exists. Will be added to every request sent to CognataStudio
        """
    ProxyConfig = namedtuple("ProxyConfig", "protocol host port")

    def __init__(self, client_api_url, user=None, password=None, email="", request_timeout=5, proxy_config=None):
        self.client_api_url = client_api_url
        self.user = user
        self.email = email
        self.password = password
        self.request_timeout = request_timeout
        self.bearer_token = None
        self.proxy_bearer_token = environ.get(_EXTERNAL_PROXY_TRACKING_TOKEN_ENV_VAR, None)
        self.is_logged_in = False

        self.__proxy_config = proxy_config # type: CognataRequests.ProxyConfig
        self.__http_method_map = {"GET":    self.__requests_proxy_wrapper(requests.get),
                                  "POST":   self.__requests_proxy_wrapper(requests.post),
                                  "PUT":    self.__requests_proxy_wrapper(requests.put),
                                  "DELETE": self.__requests_proxy_wrapper(requests.delete)}

        if user and password:
            print("Set up and login to Cognata: {} {}".format(client_api_url, user))
            # Login user and save authentication token
            self.bearer_token = self.login_user()
            self.is_logged_in = self.bearer_token is not None

    def __requests_proxy_wrapper(self, fn):
        """
        Decorator function to automatically add a 'proxies' parameter into the decorated function kwargs.
        Will do nothing in case proxy was not configured
        """
        if not self.__proxy_config:
            # Proxy not configured, continue with original function
            return fn

        proxy_url = f"{self.__proxy_config.protocol}://{self.__proxy_config.host}:{self.__proxy_config.port}"

        def add_proxy_wrap_function(*args, **kwargs):
            if "proxies" not in kwargs:
                kwargs["proxies"] = {
                    "http": proxy_url,
                    "https": proxy_url
                }
            return fn(*args, **kwargs)
        return add_proxy_wrap_function

    def login_user(self):
        """ Login to Cognata API with user and password and get bearer

        Calls /login API

        :returns: login bearer access token
        """
        login_url = "{api_url}/login".format(api_url=self.client_api_url)
        login_body = {
                "password": self.password,
                "email": self.email,
                "username": self.user
        }
        try:
            login_response = self._perform_post_request(login_url, login_body, validate=False)
            self.bearer_token = login_response.get("accessToken", None)
        except requests.exceptions.HTTPError as e:
            json_err = json.loads(e.response.text)
            msg = json_err.get("message")
            reason = json_err.get("error")
            print("{}. {}".format(msg, reason))
            return None
        return self.bearer_token

    def __perform_studio_http_request(self, method, url, body=None, extra_headers=None, query_params=None,
                                      validate=False, allow_redirects=True, parse_response=True, **kwargs):
        override_headers = kwargs.pop("override_headers", None)
        headers = {"Content-Type": "application/json"}
        if override_headers is not None:
            headers = override_headers
        if extra_headers:
            headers.update(extra_headers)

        if validate:
            try:
                self.__validate_token()
            except PermissionError:
                raise PermissionError("User unauthorized!")
        if self.proxy_bearer_token:
            headers.update({"Authorization": "Bearer {}".format(self.proxy_bearer_token)})
        headers.update({_AUTHORIZATION_HEADER_NAME: "Bearer {}".format(self.bearer_token)})
        # Handle large (HUGE) files, based on the example in the following github thread:
        # https://github.com/psf/requests/issues/2717#issuecomment-724725392
        # {
        #     'files': {
        #         'file': (
        #             '{filename}',
        #             <_io.BufferedReader name='{filepath}'>
        #         ),
        #         'parent_dir': '/bert_files/bert_models'
        #     },
        #     'headers': {'Authorization': 'Token {token}'}
        # }
        if 'files' in kwargs:
            m = MultipartEncoder(
                fields={
                    'file': (
                        kwargs['files']['file'].name,
                        kwargs['files']['file'],
                        'text/plain'
                    )
                }
            )
            del kwargs['files']
            body = m
            headers['Content-Type'] =  m.content_type

        try:
            response = self.__http_method_map[method](url=url, data=json.dumps(body) if body and isinstance(body, dict) else body,
                                                      headers=headers,
                                                      params=query_params, allow_redirects=allow_redirects, **kwargs)
            response.raise_for_status()
            if response.status_code == 200:
                # Error handling when backend rejected with status 200
                response_content = response
                if parse_response:
                    response_content = response.json()
                if isinstance(response_content, dict):
                    error = response_content.get('error', None)
                    if error is not None:
                        raise requests.exceptions.HTTPError(response_content, response=response)
                return response_content
            return response

        except requests.exceptions.HTTPError as err:
            error_printable = response.text
            try:
                error_printable = json.dumps(json.loads(error_printable), indent=2)
            except Exception:
                pass
            raise RuntimeError(f"{err}. {error_printable}")

    def __validate_token(self, retry=True):
        validate_url = "{api_url}/validateToken".format(api_url=self.client_api_url)
        # Initialize response
        validate_response = None
        try:
            validate_response = self._perform_get_request(url_request=validate_url, validate=False)
            if validate_response is None:
                raise RuntimeError("Token invalid")
        except Exception:
            if retry:
                # Failed to validate token, trying to re-login with stored credentials
                self.login_user()
                return self.__validate_token(retry=False)
            else:
                raise PermissionError("Failed to validate token. Unauthorized")
        return True

    def _perform_post_request(self, url_request, body, extra_headers=None, query_params=None,
                              validate=True, parse_response=True, **kwargs):
        """ Perform POST HTTP request """
        return self.__perform_studio_http_request(method="POST", url=url_request, body=body,
                                                  extra_headers=extra_headers, query_params=query_params,
                                                  validate=validate, parse_response=parse_response, **kwargs)

    def _perform_put_request(self, url_request, body, extra_headers=None, query_params=None,
                             validate=True, parse_response=True):
        """ Perform POST HTTP request """
        return self.__perform_studio_http_request(method="PUT", url=url_request, body=body,
                                                  extra_headers=extra_headers, query_params=query_params,
                                                  validate=validate, parse_response=parse_response)

    def _perform_get_request(self, url_request, extra_headers=None, query_params=None,
                             allow_redirects=True, validate=True, parse_response=True):
        """ Perform GET HTTP request """
        return self.__perform_studio_http_request(method="GET", url=url_request, extra_headers=extra_headers,
                                                  query_params=query_params, allow_redirects=allow_redirects,
                                                  validate=validate, parse_response=parse_response)

    def _perform_delete_request(self, url_request, extra_headers=None, query_params=None,
                                allow_redirects=True, validate=True, parse_response=True):
        """ Perform DELETE HTTP request """
        return self.__perform_studio_http_request(method="DELETE", url=url_request, extra_headers=extra_headers,
                                                  query_params=query_params, allow_redirects=allow_redirects,
                                                  validate=validate, parse_response=parse_response)

    def get_sensor(self, sensor_type, sensor_sku):
        """ Find sensor in catalog, search sensor by type and SKU

        Calls /catalog/{sensor_type}/{sensor_sku} API

        :type sensor_type: string
        :param sensor_type: sensor type, one of: "camera", "gps", "lidar" and "radar"
        :type sensor_sku: string
        :param sensor_sku: sensor SKU
        :returns: sensor object (dictionary) or None
        """
        sensor_url = "{api_url}/catalog/{sensor_type}/{sensor_sku}".format(api_url=self.client_api_url,
                                                                           sensor_type=sensor_type,
                                                                           sensor_sku=sensor_sku)
        return self._perform_get_request(sensor_url)

    @staticmethod
    def get_brand(brand_label):
        """ Return brand car full name when given brand car short name"""
        brands_map = {"Generic Combi Black": {"value": "Vehicles/Cars/Generic_Combi/Prefabs/Generic_Combi_Black", "label": "Generic Combi Black"},
                      "Generic SUV White": {"value": "Vehicles/Cars/Generic_SUV/Prefabs/Generic_SUV_White", "label": "Generic SUV White"}}
        return brands_map[brand_label]

    def get_weather_conditions(self):
        """ Return all weather conditions options
        Currently this function return hard coded values
        TODO: use API call
        """
        return [
          "clear",
          "cloudy",
          "rain",
          "heavy_rain",
          "fog",
          "overcast"
        ]

    def get_time_of_day(self):
        """ Return all time of day options
        Currently this function return hard coded values
        TODO: use API call
        """
        return [
          "morning",
          "noon",
          "afternoon",
          "evening",
          "sunrise",
          "sunset",
          "before_dawn"
        ]

    def convert_coordinates(self):
        """ Convert from (x, y) to (longitude, latitude) """
        pass

    def get_maps_list(self, **kwargs):
        """ Get list of all Cognata maps

        Calls /catalog/hdmap API

        :Keyword Arguments:
            * *lite* (``bool``) --
              Specify whether the response should be lite. I.e. containing catalog data only
            * *digestible* (``boolean``) --
              Specify whether the list should contain digestible maps only
            * *readOnly* (``boolean``) --
              Specify whether the list should contain read-only maps only

        :returns: HD maps list
        """
        lite = kwargs.get("lite")
        read_only = kwargs.get("readOnly")
        digestible = kwargs.get("digestible")
        kwargs = self.__create_catalog_item_list_query(lite=lite, read_only=read_only, digestible=digestible)

        maps_list_url = "{api_url}/catalog/hdmap".format(api_url=self.client_api_url)
        return self._perform_get_request(maps_list_url, query_params=kwargs)

    def create_map(self, catalog_data, skeleton, **kwargs):
        """ Create new map for scenarios

        Calls POST /catalog/hdmap API

        :returns: map object (dictionary) or None
        """
        maps_list_url = "{api_url}/catalog/hdmap".format(api_url=self.client_api_url)
        skeleton_input = self.__create_hdmap_skeleton_input(catalog_data, skeleton, **kwargs)

        return self._perform_post_request(maps_list_url, body=skeleton_input)

    def is_map_generation_available(self):
        """ Check if map generation is available by server

        Calls GET /catalog/generate/hdmap/is-available API

        :returns: bool
        """
        is_available_url = f"{self.client_api_url}/catalog/generate/hdmap/is-available"
        return self._perform_get_request(is_available_url)

    def set_map_xodr(self, sku, xodr):
        """
        Upload openDrive HD map
        :param sku: Map  SKU to set XODR file to
        :type sku: string
        :param xodr: Path to XODR file
        :type xodr: fp or string
        :return: response from server
        :rtype: requests.Response
        """
        return self._set_catalog_item_file(item_sku=sku, item_type="hdmap", item_file=xodr, field_name="mapXodr")

    def set_map_asset(self, sku, asset, **kwargs):
        r"""
        Upload asset for map (3D scene)
        :param sku: Map  SKU to set file to
        :type sku: string
        :param asset: Path to asset file
        :type asset: fp or string
        :param \**kwargs:
            See below

        :Keyword Arguments:
            * *mode* (``string``) --
              Specify the map asset's mode. Supported values: Normal, Compact, Semantic
            * *os* (``string``) --
              Specify the platform the asset is compatible with. Supported values: linux, mac, windows

        :return: response from server
        :rtype: requests.Response
        """
        self._validate_map_asset_kwargs()
        return self.set_3d_asset(item_type="hdmap", item_sku=sku, asset_file=asset, **kwargs)

    def set_3d_asset(self, item_type, item_sku, asset_file, **kwargs):
        self._validate_3d_asset_kwargs(**kwargs)
        return self._set_catalog_item_file(item_type=item_type, item_sku=item_sku, field_name="asset", item_file=asset_file, **kwargs)

    def _get_catalog_item_file(self, item_type, item_sku, field_name, output_file, **kwargs):
        download_url = f"{self.client_api_url}/catalog/{item_type}/{item_sku}/{field_name}/file"
        return self.download_file_from_studio(url=download_url,
                                              file_path=output_file,
                                              allow_redirects=True,
                                              **kwargs)

    def download_map_xodr(self, sku, output_file):
        r"""
        Download openDrive HD map
        :param sku: Map SKU to set file to
        :type sku: string
        :param output_file: Path to write xodr file
        :type output_file: fp or string

        :return: path to downloaded file
        :rtype: str
        """
        return self._get_catalog_item_file(item_type="hdmap", item_sku=sku, field_name="mapXodr", output_file=output_file)

    def download_map_log(self, sku, output_file):
        r"""
        Download map generation log file
        :param sku: Map SKU to set file to
        :type sku: string
        :param output_file: Path to write log file
        :type output_file: fp or string

        :return: path to downloaded file
        :rtype: str
        """
        return self._get_catalog_item_file(item_type="hdmap", item_sku=sku, field_name="log", output_file=output_file)

    @staticmethod
    def _validate_map_asset_kwargs(**kwargs):
        supported_modes = ["Normal", "Compact", "Semantic", "Datasets"]
        assert "mode" not in kwargs or kwargs.get("mode") in supported_modes, f"mode param must be one of: {', '.join(supported_modes)}"

    @staticmethod
    def _validate_3d_asset_kwargs(**kwargs):
        supported_os = ["linux", "mac", "windows"]
        assert "os" not in kwargs or kwargs.get("os") in supported_os, f"os param must be one of: {', '.join(supported_os)}"

    def download_3d_asset(self, item_type, sku, output_file, **kwargs):
        r"""
        Download asset for map (3D scene)
        :param sku: Map SKU to set file to
        :type sku: string
        :param output_file: Path to write asset file
        :type output_file: fp or string
        :param \**kwargs:
            See below

        :Keyword Arguments:
            * *mode* (``string``) --
              Specify the map asset's mode. Supported values: Normal, Compact, Semantic
            * *os* (``string``) --
              Specify the platform the asset is compatible with. Supported values: linux, mac, windows

        :return: path to downloaded file
        :rtype: str
        """
        self._validate_3d_asset_kwargs(**kwargs)

        return self._get_catalog_item_file(item_type=item_type, item_sku=sku, field_name="asset", output_file=output_file, **kwargs)

    def download_map_asset(self, sku, output_file, **kwargs):
        self._validate_map_asset_kwargs(**kwargs)
        return self.download_3d_asset(item_type="hdmap", sku=sku, output_file=output_file, **kwargs)

    def set_map_thumbnail(self, sku, thumbnail):
        """
        Upload thumbnail HD map
        :param sku: Map SKU to set XODR file to
        :type sku: string
        :param thumbnail: Path to thumbnail file
        :type thumbnail: fp or string
        :return: response from server
        :rtype: requests.Response
        """
        return self._set_catalog_item_file(item_type="hdmap", item_sku=sku, field_name="thumbnail", item_file=thumbnail)

    def set_map_log(self, sku, log_file):
        """
        Upload HD map generation log file
        :param sku: Map SKU to set XODR file to
        :type sku: string
        :param log_file: Path to log file
        :type log_file: fp or string
        :return: response from server
        :rtype: requests.Response
        """
        return self._set_catalog_item_file(item_type="hdmap", item_sku=sku, field_name="log", item_file=log_file)

    def _set_catalog_item_generation_report(self, sku, **kwargs):
        r"""
        Set report for catalog item creation process
        :param sku: Catalog item's SKU
        :type sku: str
        :param \**kwargs:
            See below

        :Keyword Arguments:
            * *status* (``string``) --
              Specify the map creation report's status. Supported values: inProgress, success, failure
            * *message* (``string``) --
              The message describing the status. Can be used to describe the current step in case of inProgress, or the failure
              reason in case of failure
            * *report* (``dict``) --
              An object defining the status and the message altogether
        :return: response from server
        :rtype: requests.Response
        """
        status = kwargs.pop("status", None)
        message = kwargs.pop("message", None)
        report = kwargs.pop("report", None)
        # Make sure at least one of report or (status && message) exists
        assert report is not None or (status is not None and message is not None),\
            "Invalid arguments. Expecting a report(dict) or status (string) and message (string)"
        if report is None:
            report = {"status": status, "message": message}
        report_url = f"{self.client_api_url}/catalog/{sku}/report"
        return self._perform_put_request(report_url, body=report)

    def get_catalog_item_generation_report(self, sku):
        """
        Get report(s) from catalog item creation process
        :param sku: Catalog item's SKU
        :type sku: str
        :return: response from server
        :rtype: requests.Response
        """
        report_url = f"{self.client_api_url}/catalog/{sku}/report"
        return self._perform_get_request(report_url)

    def update_map(self, map_sku, catalog_data, skeleton, **kwargs):
        """ Update existing HD map in catalog by map SKU

        Calls PUT /catalog/hdmap/{map_sku} API

        :type map_sku: string
        :param map_sku: HD Map to update
        :returns: map object (dictionary) or None
        """
        map_url = "{api_url}/catalog/hdmap/{map_sku}".format(api_url=self.client_api_url, map_sku=map_sku)
        # fetch existing
        hdmap = self.find_map(map_sku)
        skeleton_input = self.__create_hdmap_skeleton_input(catalog_data, skeleton, **kwargs)
        merged = {}
        merged.update(hdmap)
        props =skeleton_input.get("properties")
        for k in props:
            merged["properties"][k] = props[k]
        return self._perform_put_request(map_url, body=merged)

    @staticmethod
    def __create_catalog_item_list_query(lite=None, read_only=None, digestible=None):
        kwargs = {
            "lite":       json.dumps(lite)       if lite       is not None else None,
            "readOnly":   json.dumps(read_only)  if read_only  is not None else None,
            "digestible": json.dumps(digestible) if digestible is not None else None
        }
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        return kwargs

    def __find_catalog_item(self, item_type, item_sku, **kwargs):
        catalog_url = f"{self.client_api_url}/catalog/{item_type}/{item_sku or ''}"
        return self._perform_get_request(catalog_url, query_params=kwargs)

    def find_map(self, map_sku, **kwargs):
        """ Find HD map in catalog by map SKU

        Calls /catalog/hdmap/{map_sku} API

        :type map_sku: string
        :param map_sku: HD Map to look for
        :returns: map object (dictionary) or None
        """

        return self.__find_catalog_item(item_type="hdmap", item_sku=map_sku, **kwargs)

    def find_asset(self, asset_sku, **kwargs):
        """ Find asset in catalog by map SKU

        Calls /catalog/asset/{asset_sku} API

        :type map_sku: string
        :param map_sku: asset to look for
        :returns: asset object (dictionary) or None
        """

        return self.__find_catalog_item(item_type="asset", item_sku=asset_sku, **kwargs)

    def get_ai_cars_list(self):
        """ Get a list of all ego cars from catalog

        Calls /catalog/aicar API

        :returns: ai car list
        """
        ai_car_list_url = "{api_url}/catalog/aicar".format(api_url=self.client_api_url)
        return self._perform_get_request(ai_car_list_url)

    def find_ai_car(self, ai_car_sku):
        """ Find ai car in catalog by car SKU

        Calls /catalog/aicar/{ai_car_sku} API

        :type ai_car_sku: string
        :param ai_car_sku: ai car SKU to look for
        :returns: ai car object (dictionary) or None
        """
        ai_car_url = "{api_url}/catalog/aicar/{ai_car_sku}".format(api_url=self.client_api_url, ai_car_sku=ai_car_sku)
        return self._perform_get_request(ai_car_url)

    def get_ego_cars_list(self):
        """ Get a list of all ego cars from catalog

        Calls /catalog/egocar API

        :returns: Ego car sensors preset list
        """
        ego_car_list_url = "{api_url}/catalog/egocar".format(api_url=self.client_api_url)
        return self._perform_get_request(ego_car_list_url)

    def find_ego_car(self, ego_car_sku):
        """ Find ego car in catalog by car SKU

        Calls /catalog/egocar/{ego_car_sku} API

        :type ego_car_sku: string
        :param ego_car_sku: ego car SKU to look for
        :returns: ego car object (dictionary) or None
        """
        ego_car_url = "{api_url}/catalog/egocar/{ego_car_sku}".format(api_url=self.client_api_url, ego_car_sku=ego_car_sku)
        return self._perform_get_request(ego_car_url)

    def create_sensors_preset(self, preset_name, ai_car_type, sensors, preset_description=None):
        """ Create a sensors preset object and save it using API POST request

        Calls /catalog/egocar POST API

        :type preset_name: string
        :param preset_name: Ego car's sensors preset name
        :type ai_car_type: string
        :param ai_car_type: AI car type ("AISUV")
        :type sensors: list of dictionaries
        :param sensors: sensors dictionary data. (generated by CognataSensor.get_sensor_for_preset())
        :type preset_description: string
        :param preset_description: preset description. if not given - use name by default
        """
        # Go over sensors and validate
        # Make sure names are unique
        # Make sure names are no special chars
        # Set id to every sensor
        sensors_cnt = 0
        existing_names = []
        for sensor in sensors:
            sensor_name = sensor.get("name", None)
            assert bool(sensor_name), "Sensor name not provided"
            no_special_chars = re.sub(r"\W+", "", sensor_name)
            assert sensor_name == no_special_chars, \
                "Sensor contains illegal characters. Only alphanumeric and underscores are allowed"
            assert sensor_name not in existing_names, "Sensors names must be unique within the same preset"
            sensor["name"] = sensor_name
            existing_names.append(sensor.get("name"))
            if "id" not in sensor:
                sensor["id"] = f"SEN{sensors_cnt:-04d}"
            sensors_cnt += 1
        preset_object = {
            "catalogData": {
                "name": preset_name,
                "description": preset_description or preset_name,
                "type": "egocar",
                "version": 0.1,
            },
            "properties": {
                "ai_car": ai_car_type,
                "sensors": sensors
            }
        }
        create_preset_url = "{api_url}/catalog/egocar".format(api_url=self.client_api_url)
        return self._perform_post_request(create_preset_url, preset_object)

    def create_scenario(self, cognata_scenario_object):
        """ Create a scenario

        Calls /scenario POST API

        :type cognata_scenario_object: CognataScenario object
        :param cognata_scenario_object: Scenario object to create and save to DB
        :returns: Create scenario response
        """
        create_scenario_url = "{api_url}/scenario".format(api_url=self.client_api_url)
        return self._perform_post_request(create_scenario_url, cognata_scenario_object)

    def evaluate_simulation(self, scenario_data):
        """ Evaluate a simulation run

        Calls /simulations/evaluate API

        :type scenario_data: dictionary
        :param scenario_data: scenario data that the simulation is based on (scenario formula)
        :returns: Evaluate simulation response
        """
        evaluate_simulation_url = "{api_url}/simulations/evaluate".format(api_url=self.client_api_url)
        evaluate_body = scenario_data
        evaluate_response = self._perform_post_request(evaluate_simulation_url, evaluate_body)
        return evaluate_response

    def generate_simulation(self, scenario_data, client_driver_version='', cognata_engine_version='',
                            annotate=False, visibility_report=False):
        """ Generate a simulation run

        Calls /simulations/generate API

        :type scenario_data: dictionary
        :param scenario_data: scenario data that the simulation is based on (scenario formula)
        :type client_driver_version: string
        :param client_driver_version: Client's driver version to control engine
        :type cognata_engine_version: string
        :param cognata_engine_version: Engine's version to use for the simulation
        :type annotate: bool
        :param annotate: Set to True in order to annotate simulation outputs
        :type visibility_report: bool
        :param visibility_report: Set to True in order to produce visibility report for simulation
        :returns: Generate simulation response
        """
        generate_simulation_url = "{api_url}/simulations/generate".format(api_url=self.client_api_url)
        generate_body = {"formula": scenario_data,
                         "driver_version": client_driver_version, "engine_version": cognata_engine_version}
        generate_body.update({
            # At the moment annotation is boolean, either no annotation, or all cameras will be annotated
            "annotate": annotate,
            "visibility_report": visibility_report and annotate
        })
        generate_response = self._perform_post_request(generate_simulation_url, generate_body)
        return generate_response

    def find_simulation_runs_queue(self, queue="cloud", status=None, resolution=None, sort="creation_time|desc",
                                   limit=None, offset=None, search_str=None):
        """ Find simulation runs by queue id

        Calls /simulations/queue/{queue} API

        :type queue: string
        :param queue: queue to filter by
        :type status: string
        :param status: status to filter by
        :type resolution: string
        :param resolution: resolution to filter by
        :type sort: string
        :param sort: sort by field - SQL format
        :type limit: string
        :param limit: maximum records in response
        :type offset: string
        :param offset: pages to skip
        :type search_str: string
        :param search_str: name of simulation or part of it
        :returns: list of simulation runs from queue
        """
        sim_runs_queue_url = "{api_url}/simulations/queue/{queue}".format(api_url=self.client_api_url, queue=queue)
        options = {}
        if status:
            options["status"] = status
        if resolution:
            options["resolution"] = resolution
        if sort:
            options["sort"] = sort
        if limit:
            options["limit"] = limit
        if offset:
            options["offset"] = offset
        if search_str:
            options["searchStr"] = search_str

        return self._perform_get_request(sim_runs_queue_url, query_params=options)

    def find_simulation_run(self, simulation_run_id):
        """ Find simulation run by id

        Calls /simulations/runs/{simulation_run_id} API

        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to look for
        :returns: simulation run object (dictionary) or None
        """
        sim_run_url = "{api_url}/simulations/runs/{simulation_run_id}".format(api_url=self.client_api_url, simulation_run_id=simulation_run_id)
        return self._perform_get_request(sim_run_url)

    def get_simulation_run_id(self, generate_response):
        """ Get actual simulation run id from generate API response,

        Calls /simulations/runs/simulation/{id_from_response} API

        :type generate_response: string
        :param generate_response: Generate response
        """
        id_from_response = generate_response[0]["_id"]
        simulation_run_from_simulations_url = "{api_url}/simulations/runs/simulation/{id_from_response}".format(api_url=self.client_api_url, id_from_response=id_from_response)
        simrun_response = self._perform_get_request(simulation_run_from_simulations_url)
        if simrun_response:
            return simrun_response["_id"]

    def get_scenrios_list(self):
        """ Get a list of all scenarios

        Calls /scenarios API

        :returns: list of all scenarios (ids)
        """
        sceanrio_list_url = "{api_url}/scenarios".format(api_url=self.client_api_url)
        print("sceanrio_list_url", sceanrio_list_url)
        return self._perform_get_request(sceanrio_list_url)

    def find_scenario(self, scenario_id):
        """ Find scenario by id

        Calls /scenarios/{scenario_id} API

        :type scenario_id: string
        :param scenario_id: scenario id to look for
        :returns: scenario object (dictionary) or None
        """
        scenario_url = "{api_url}/scenarios/{scenario_id}".format(api_url=self.client_api_url,
                                                                  scenario_id=scenario_id)
        return self._perform_get_request(scenario_url)

    def get_simulations_list(self, **kwargs) -> dict:
        """ List all simulations

        Calls /simulations API

        :param limit: (optional) Maximum simulations number to retrieve
        :param offset: (optional) Pages offset
        :param filters: (optional) Sort options by fields
        :param searchStr: (optional) Retrieve simulations where pattern searchStr is found
        :param parentId: (optional) simulation parent ID to filter by

        :returns: simulations array (list)
        """
        options = {}
        for param_name in ("limit", "offset", "filters", "searchStr", "parentId"):
            if param_name in kwargs:
                options[param_name] = kwargs.get(param_name)

        simulations_url = "{api_url}/simulations".format(api_url=self.client_api_url)
        return self._perform_get_request(simulations_url, query_params=options)

    def find_simulation_parent(self, parent_id):
        """ Find simulation parent by id

        Calls /simulations/{parent_id} API

        :type parent_id: string
        :param parent_id: simulation parent id to look for
        :returns: simulation object (dictionary) or None
        """
        simulations_url = "{api_url}/simulations/{parent_id}".format(api_url=self.client_api_url,
                                                                     parent_id=parent_id)
        res = self._perform_get_request(simulations_url)
        if "error" in res or ("type" in res and res["type"] != "parent"):
            res = None
        return res


    def get_simulation_run_status(self, simulation_run_id):
        """ Get simulation run execution status

        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to look for
        :returns: simulation run status
        """
        sim_run = self.find_simulation_run(simulation_run_id)
        if sim_run:
            return sim_run["status"]

    def get_simulation_run_queue(self, simulation_run_id):
        """ Get simulation run queue id

        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to look for
        :returns: simulation run queue_id
        """
        sim_run = self.find_simulation_run(simulation_run_id)
        if sim_run:
            return sim_run["queue_id"]

    def get_simulation_run_files_list(self, simulation_run_id):
        """ Get simulation run files

        Calls /simulations/runs/{simulation_run_id}/files API

        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to look for
        :returns: list of simulation run output files
        """
        simulation_run_files_url = "{api_url}/simulations/runs/{simulation_run_id}/files".format(api_url=self.client_api_url, simulation_run_id=simulation_run_id)
        return self._perform_get_request(simulation_run_files_url)

    def download_simulation_engine_config(self, simulation_id, local_path):
        """ Get simulation engine config

        Calls /simulations/{simulation_id}/hdsimulation API

        :type simulation_id: string
        :param simulation_id: simulation id to look for
        :type local_path: string
        :param local_path: path to write simulation engine config file to
        :returns: local engine config file name written
        """

        local_file_name = path.join(local_path, "{}.json".format(simulation_id))
        simulation_engine_config_url = "{api_url}/simulations/{simulation_id}/hdsimulation".format(
            api_url=self.client_api_url,
            simulation_id=simulation_id)
        with open(local_file_name, "w") as write_file:
            write_file.write(json.dumps(self._perform_get_request(simulation_engine_config_url), indent=2))
        return local_file_name

    def download_simulation_run_file(self, simulation_run_id, file_name, download_path=None, allow_redirects=True,
                                     run_id_prefix=False):
        """ Get simulation run file

        Calls /simulations/{simulation_run_id}/files/{file_name} API

        :param allow_redirects:
        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to look for
        :type file_name: string
        :param file_name: file name to get
        :type download_path: string
        :param download_path: the path to write the file to
        :type run_id_prefix: bool
        :param run_id_prefix: prefix saved filename with run_id?
        :returns: local file name written or redirection URL (in case of allow_redirects=False)
        """

        local_file_name = file_name
        if run_id_prefix:
            local_file_name = f"{simulation_run_id}-{local_file_name}"
        if download_path is not None:
            local_file_name = path.join(download_path, file_name)
        simulation_run_files_url = f"{self.client_api_url}/simulations/{simulation_run_id}/files/{file_name}"
        return self.download_file_from_studio(url=simulation_run_files_url,
                                              file_path=local_file_name,
                                              allow_redirects=allow_redirects)

    def download_file_from_studio(self, url, file_path, allow_redirects, **kwargs):
        resp = self._perform_get_request(url, allow_redirects=allow_redirects, parse_response=False, query_params=kwargs)
        if resp.status_code == 302:
            # Set return value to be the redirected URL
            print("url:", resp.url)
            file_path = resp.headers["Location"]
            print("redir:", file_path)
        else:
            with open(file_path, "wb") as write_file:
                write_file.write(resp.content)
        return file_path


    def wait_for_simulation_to_finish(self, simulation_run_id, wait_timeout=300):
        """ Wait for simulation run to finish

        :type simulation_run_id: string
        :param simulation_run_id: simulation run id to track
        :type wait_timeout: integer
        :param wait_timeout: timeout to wait for simulation to finish [seconds], default is 5 minutes

        :returns: simulation run id ending status
        """
        print("Waiting for simulation", simulation_run_id, "to finish")
        sim_run_status = self.get_simulation_run_status(simulation_run_id)
        if sim_run_status:
            counter = 0
            while sim_run_status in ("pending", "running", "analysis_pending", "analysis") and counter < wait_timeout:
                time.sleep(1)
                counter += 1
                print(".", end=" ", flush=True)
                sim_run_status = self.get_simulation_run_status(simulation_run_id)
        print()
        return sim_run_status

    def rerun_simulation(self, simulation_run_id):
        """ Re-run a simulation run

        Calls /simulations/{simulation_run_id}/run API

        :type simulation_run_id:  string
        :param simulation_run_id: simulation run id
        :returns: new simulation run id generated

        """
        simulation_run_data = self.find_simulation_run(simulation_run_id)
        queue_id = simulation_run_data["queue_id"]
        simulation_related = simulation_run_data["simulation_id"]
        rerun_url = "{api_url}/simulations/{simulation_run_id}/run".format(api_url=self.client_api_url, simulation_run_id=simulation_related)
        rerun_response = self._perform_post_request(rerun_url, {}, query_params={"queue": queue_id})
        return rerun_response["simulation_run_id"]

    def __create_hdmap_skeleton_input(self, catalog_data, skeleton, **kwargs):
        _properties = {}
        if skeleton is not None:
            _properties["mapSkeleton"] = skeleton

        is_asset_bundle = True
        if "is_asset_bundle" in kwargs:
            is_asset_bundle = kwargs["is_asset_bundle"]
        _properties["is_asset_bundle"] = is_asset_bundle

        map_type = "highway"
        if "type" in kwargs:
            map_type = kwargs["type"]
        _properties["type"] = map_type

        modes = [{
            "label": "Normal",
            "suffix": ""
        }]
        if "modes" in kwargs:
            modes = kwargs["modes"]
        _properties["modes"] = modes
        return {
            "catalogData": catalog_data,
            "properties": _properties
        }

    def get_dynamic_analysis_rules_list(self, lite=True) -> list:
        """ List all DARs

        Calls /catalog/dynamicAnalysisRule API

        :returns: DARs array (list)
        """
        dars_list_url = "{api_url}/catalog/dynamicAnalysisRule".format(api_url=self.client_api_url)
        return self._perform_get_request(dars_list_url, query_params={"lite": json.dumps(lite)})

    def __prepare_dar_body(self, name, description, file_path):
        catalog_data = {
            "name": name,
            "description": description,
            "type": "dynamicAnalysisRule"
        }
        with open(file_path, 'r') as dar_file:
            file_content = dar_file.read()  # self.__create_hdmap_skeleton_input(catalog_data, skeleton, **kwargs)

        return {
            "catalogData": catalog_data,
            "properties": {
                "fileContent": file_content
            }
        }

    def create_dynamic_analysis_rule(self, name, description, dar_filepath):
        """ Create new DAR

        Calls POST /catalog/dynamicAnalysisRule API

        :returns: DAR object (dictionary) or None
        """
        dar_request_body = self.__prepare_dar_body(name, description, dar_filepath)

        dars_list_url = "{api_url}/catalog/dynamicAnalysisRule".format(api_url=self.client_api_url)
        return self._perform_post_request(dars_list_url, body=dar_request_body)

    def update_dynamic_analysis_rule(self, dar_sku, name, description, dar_filepath):
        """ Update existing DAR in catalog by SKU

        Calls PUT /catalog/dynamicAnalysisRule/{dar_sku} API

        :type dar_sku: string
        :param dar_sku: DAR to update
        :returns: dar object (dictionary) or None
        """
        dar_url = "{api_url}/catalog/dynamicAnalysisRule/{dar_sku}".format(api_url=self.client_api_url, dar_sku=dar_sku)
        dar_request_body = self.__prepare_dar_body(name, description, dar_filepath)
        return self._perform_put_request(dar_url, body=dar_request_body)

    def find_dynamic_analysis_rule(self, dar_sku):
        """ Find DAR in catalog by SKU

        Calls GET /catalog/dynamicAnalysisRule/{dar_sku} API

        :type dar_sku: string
        :param dar_sku: DAR to look for
        :returns: dar object (dictionary) or None
        """
        dar_url = "{api_url}/catalog/dynamicAnalysisRule/{dar_sku}".format(api_url=self.client_api_url, dar_sku=dar_sku)
        return self._perform_get_request(dar_url)

    def _create_car_physics(self, car_physics_object):
        """ Create a new Car Physics model

        Calls POST /catalog/carPhysics API
        """

        create_car_physics_url = "{api_url}/catalog/carPhysics".format(api_url=self.client_api_url)
        return self._perform_post_request(create_car_physics_url, car_physics_object)

    def _get_car_physics(self, car_physics_sku=None, lite=False, read_only=None):
        """ Get car physics models

        Calls GET /catalog/carPhysics API

        if an SKU is provided, a single carPhysics will be returned, otherwise, a list will be returned
        """

        car_physics_list_url = "{api_url}/catalog/carPhysics/{car_physics_sku}".format(api_url=self.client_api_url, car_physics_sku=car_physics_sku or "")
        query = self.__create_catalog_item_list_query(lite=lite, read_only=read_only)
        return self._perform_get_request(car_physics_list_url, query_params=query)

    def _update_car_physics(self, car_physics_sku, car_physics_object):
        """Update single Car Physics model

        Calls PUT /catalog/carPhysics API
        """

        car_physics_url = "{api_url}/catalog/carPhysics/{car_physics_sku}".format(api_url=self.client_api_url, car_physics_sku=car_physics_sku)
        return self._perform_put_request(car_physics_url, car_physics_object)

    def delete_car_physics(self, car_physics_sku):
        """Delete single Car Physics model from catalog

        Calls DELETE /catalog/carPhysics API
        """

        self._delete_catalog_item("carPhysics", item_sku=car_physics_sku)

    def create_car_physics(self, car_physics_name, json_file):
        """
        Create car physics object
        """

        car_physics_model_content = json.dumps(CognataRequests._read_json_file(json_file))

        car_physics_object = {
            "catalogData": CognataRequests.create_catalog_data(car_physics_name, "carPhysics"),
            "properties": {
                "carPhysicsModelContent": car_physics_model_content # parsed file
            }
        }
        return self._create_car_physics(car_physics_object)

    def update_car_physics(self, car_physics_sku, car_physics_name=None, json_file=None):
        """
        Update single car physics model
        """

        car_physics_object = self.get_single_car_physics(car_physics_sku)

        if car_physics_object is None:
            raise ValueError(f"Car physics object with sku: {car_physics_sku} was not found")

        if car_physics_name is not None:
            print("Updating name")
            car_physics_object.get("catalogData", {})["name"] = car_physics_name

        if json_file is not None:
            print("Updating json file")
            car_physics_object.get("properties", {})["carPhysicsModelContent"] = json.dumps(
                CognataRequests._read_json_file(json_file)
            )

        return self._update_car_physics(car_physics_sku, car_physics_object)

    def get_single_car_physics(self, car_physics_sku):
        """
        Get single car physics models
        """
        return self._get_car_physics(car_physics_sku)

    def get_car_physics_list(self, car_physics_sku=None, lite=False, read_only=None):
        """
        Get a list of car physics models
        """
        return self._get_car_physics(None, lite, read_only)

    @staticmethod
    def create_catalog_data(name, _type, description=None, sku=None, brandID=None, tags=None, version=None):
        rv = {
            "name": name, # mandatory
            "type": _type, # mandatory,
            "sku": sku,
            "veriosn": version,
            "description": description,
            "brandID": brandID,
            "tags": tags
        }

        return {k: v for k, v in rv.items() if v is not None}

    @staticmethod
    def _read_json_file(json_file):
        """
        Read JSON file, agnostic to File or path as str
        :param json_file: File or path as str
        :type json_file:
        :return: dict
        :rtype:
        """
        content = None
        if isinstance(json_file, str):
            if path.exists(json_file):
                fp = open(json_file, 'r')
                content = json.load(fp)
            else:
               raise ValueError("File: " + json_file + " does not exist")
        else:
            content = json.load(json_file)
        return content

    def _check_generate_is_available(self, catalog_type):
        """
        Checks whether the server is available for catalog object generation
        """
        is_available_url = f"{self.client_api_url}/catalog/generate/{catalog_type}/is-available"
        result = self._perform_get_request(is_available_url).get("result")
        return result

    def create_catalog_asset(self, fbx_file, asset_json, wait=True, **kwargs):
        """
        Import new asset

        :Keyword Arguments:
            * *make_ego_car* (``bool``) --
              Specify whether the created asset should be an EgoCar
            * *default_car_physics_sku* (``string``) --
              Specify the carPhysics default preset attached to the created EgoCar (if requested)

        :returns: Newly created asset
        """
        created_asset = self._create_asset(asset_json, **kwargs)
        asset_sku = created_asset.get("catalogData", {}).get("sku")
        assert asset_sku is not None, created_asset.get("message")

        resp = self._set_asset_fbx(asset_sku, fbx_file)

        response = created_asset
        if wait:
            while not self._check_generate_is_available("asset"):
                time.sleep(5)

            response = self.get_asset_list(asset_sku=asset_sku)
            status = response.get("properties").get("uploadStatus")
            reports = response.get("properties").get("reports")
            first_fail = ([r for r in reports if r.get("status")] or [None])[0]
            assert response.get("properties").get("uploadStatus") == "success", f"Asset creation failed. Reason: {first_fail.get('message')}"
            print(f"Asset {asset_sku} uploaded successfully")
        return response

    def _create_asset(self, asset_json, **kwargs):
        """ Create new asset

        Calls POST /catalog/asset API

        :returns: asset object (dictionary) or None
        """
        asset_content = self._read_json_file(asset_json)

        asset_body = {
            "userInput": asset_content
        }

        if "make_ego_car" in kwargs:
            egoCarProperties = {
                "defaultCarPhysicsSKU": kwargs.pop("default_car_physics_sku", None),
                "makeEgoCar": kwargs.pop("make_ego_car")
            }
            asset_body.update({"egoCarProperties": {k: v for k, v in egoCarProperties.items() if v is not None}})

        for kw in kwargs:
            print(f"Ignoring {kw}. Unknown kwarg")

        asset_url = f"{self.client_api_url}/catalog/asset"
        return self._perform_post_request(asset_url, body=asset_body)

    def _update_asset(self, sku, asset_json, **kwargs):
        """ Update existing asset

        Calls PUT /catalog/asset API

        :returns: asset object (dictionary) or None
        """
        asset_content = self._read_json_file(asset_json)

        asset_url = f"{self.client_api_url}/catalog/asset/{sku}"
        return self._perform_put_request(asset_url, body=asset_content)

    def _set_catalog_item_file(self, item_type, item_sku, field_name, item_file, **kwargs):
        if not isinstance(item_file, io.IOBase):
            item_file = open(item_file, 'rb')
        if not item_file.readable():
            raise RuntimeError("file must be readable")

        upload_url = f"{self.client_api_url}/catalog/{item_type}/{item_sku}/{field_name}/file"
        return self._perform_post_request(url_request=upload_url, body=None, parse_response=False, files={"file": item_file}, override_headers={}, query_params=kwargs)

    def _set_asset_fbx(self, asset_sku, fbx_file):
        return self._set_catalog_item_file(item_type="asset", item_sku=asset_sku, field_name="fbx", item_file=fbx_file)

    def download_asset_fbx(self, sku, output_file):
        r"""
        Download gbx defining asset
        :param sku: asset SKU to get file from
        :type sku: string
        :param output_file: Path to write fbx file
        :type output_file: fp or string

        :return: path to downloaded file
        :rtype: str
        """
        return self._get_catalog_item_file(item_type="asset", item_sku=sku, field_name="fbx", output_file=output_file)

    def _delete_catalog_item(self, item_type, item_sku):
        """
        Delete only assets that were not used in simulation
        """

        item_url = f"{self.client_api_url}/catalog/{item_type}/{item_sku}"
        return self._perform_delete_request(item_url, parse_response=False)

    def get_asset_list(self, asset_sku=None, lite=False, read_only=None, digestible=None):
        """
        Add support for download assets

        :param sku: Optional - asset SKU to get file from. If provided, result will be a single asset
        :type sku: string
        :Keyword Arguments:
            * *lite* (``bool``) --
              Specify whether the response should be lite. I.e. containing catalog data only
            * *digestible* (``str``) --
              Specify whether the list should contain digestible assets only. Valid values are: "digestible", "notDigestible", "all"
            * *read_only* (``boolean``) --
              Specify whether the list should contain read-only maps only

        :returns: Assets list or a single asset (dict)
        """
        kwargs = self.__create_catalog_item_list_query(lite=lite, read_only=read_only, digestible=digestible)
        return self.__find_catalog_item(item_type="asset", item_sku=asset_sku, **kwargs)

    def download_asset_description_file(self, sku, asset_description_file="assetDescription.json"):
        r"""
        Download asset’s description file to file at given path
        :param sku: asset SKU to find the object
        :type sku: string
        :param asset_description_file: Path of asset_description_file
        :type asset_description_file: string

        :return: path to asset_description_file
        :rtype: str
        """
        asset_object = self.find_asset(asset_sku=sku)
        with open(asset_description_file, 'w') as json_file:
            json.dump(asset_object.get("properties", {}).get("userInput"), json_file, indent=4)
        return asset_description_file

    def get_thermal_config_list(self, lite=None, read_only=None):
        """ Get Thermal Configuration List

        Calls /catalog/thermalConfig API

        :returns: list of thermal configuration list
        """
        thermal_config_list_url = "{api_url}/catalog/thermalConfig".format(api_url=self.client_api_url)
        query = self.__create_catalog_item_list_query(lite=lite, read_only=read_only)
        return self._perform_get_request(thermal_config_list_url, query_params=query)

    def get_thermal_config(self, thermal_config_sku):
        """ Get Thermal Configuration By sku

        Calls /catalog/thermalConfig/sku API

        :param thermal_config_sku: Required - Represents the thermal config sku
        :returns: Thermal configuration
        """
        thermal_config_url = "{api_url}/catalog/thermalConfig/{thermal_config_sku}".format(
            api_url=self.client_api_url, thermal_config_sku=thermal_config_sku
        )
        return self._perform_get_request(thermal_config_url)

    def delete_thermal_config(self, thermal_config_sku):
        """ Delete Thermal Configuration By sku

        Calls /catalog/thermalConfig/sku API

        :param thermal_config_sku: Required - Represents the thermal config sku
        :returns: Dict with the response message
        :example {'msg': 'thermalConfig TEST20NP removed successfully'}
        """
        thermal_config_url = "{api_url}/catalog/thermalConfig/{thermal_config_sku}".format(
            api_url=self.client_api_url, thermal_config_sku=thermal_config_sku
        )
        return self._perform_delete_request(thermal_config_url)

    def create_thermal_config(self, name, description, emissivity_table_path, temperature_table_path):
        """ Create new Thermal Configuration

        Calls /catalog/thermalConfig API

        :param name: Required - Represents the thermal camera name
        :param description: Required - Represents the thermal camera description
        :param emissivity_table_path: Required - Represents the thermal camera emissivity table file path
        :param temperature_table_path: Required - Represents the thermal camera temperature table file path
        :returns: The New Thermal configuration
        """
        catalog_type = 'thermalConfig'
        files_to_upload = [
            {"field_name": 'temperatureTable', "path": temperature_table_path},
            {"field_name": 'emissivityTable', "path": emissivity_table_path}
        ]
        body = {
            "catalogData": self.create_catalog_data(name, catalog_type, description=description),
            "properties": {
                "is_asset_bundle": True
            }
        }
        try:
            # Create the thermal config object
            thermal_config_url = "{api_url}/catalog/thermalConfig".format(api_url=self.client_api_url)
            thermal_configuration_response = self._perform_post_request(thermal_config_url, body)
            sku = thermal_configuration_response["sku"]
            # Iterate over fields that represents files
            for file_to_upload in files_to_upload:
                # Upload the thermal configuration catalog files
                self._set_catalog_item_file(
                    item_type=catalog_type,
                    item_sku=sku,
                    field_name=file_to_upload["field_name"],
                    item_file=file_to_upload["path"]
                )
            # get the object to have full details
            thermal_configuration_response = self.get_thermal_config(sku)
            return thermal_configuration_response
        except Exception as error:
            print(error)

    ############################################
    #               AD CLIENT                  #
    ############################################
    @classmethod
    def cast_catalog_fields(cls, ad_client):
        # ad_client might be returned with catalogData as flattened fields. If there is no catalogdata
        # in the response object, move all except the properties to be nested under catalogData
        if 'catalogData' not in ad_client:
            props = ad_client.pop('properties')
            tmp = ad_client
            ad_client = {
                'properties': props,
                'catalogData': tmp
            }
        return ad_client

    def get_ad_client_info(self, name: str, cast=True):
        res = self._perform_get_request(f"{self.client_api_url}/catalog/AutoDriveClient/{name}")
        if cast and isinstance(res, dict):
            res = self.cast_catalog_fields(res)
        return res

    @classmethod
    def _get_ad_clients_tags(cls, ad_client: dict):
        return ad_client.get('properties').get('container_tags')

    @classmethod
    def _get_ad_client_tag_from_tags(cls, container_tags: list, tag: str, index_only=False):
        idx = None
        for i, t in enumerate(container_tags):
            if t.get('tag') == tag:
                if idx is not None:
                    # found 2 tags matching, set to idx None to fail later
                    idx = None
                    break
                idx = i

        if idx is None:
            raise RuntimeError(f"Expecting exactly one tag to exist ('{tag}')")
        return idx if index_only else container_tags[idx]

    @classmethod
    def get_ad_client_tag_info(cls, ad_client: dict, tag: str):
        container_tags = cls._get_ad_clients_tags(ad_client)
        return cls._get_ad_client_tag_from_tags(container_tags, tag)

    def list_ad_clients(self):
        # Empty name results in a list of clients
        return self.get_ad_client_info(name="")

    def create_ad_client(self, name: str, description: str):
        """Create a new "project" for AutoDriver Clients.
        This will not create a usable client, but a namespace underwhich ad client tags can be added
        """
        body = {
            "catalogData": {
                "name": name,
                "description": description,
                "type": "ad_client"
            },
            "properties": {
                "container_tags": []
            }
        }
        return self._perform_post_request(f"{self.client_api_url}/catalog/AutoDriveClient", body=body)

    @classmethod
    def _create_ad_client_tag_structure(cls, tag: str, filename: str, cli_options: list = None):
        return {
            'tag': tag,
            'file': filename,
            'options': cli_options or []
        }

    def _set_ad_client_tag_file(self, name: str, tag: str, filename: str):
        if not isinstance(filename, io.IOBase):
            filename = open(filename, 'rb')
        if not filename.readable():
            raise RuntimeError("file must be readable")

        upload_url = f"{self.client_api_url}/catalog/AutoDriveClient/{name}/{tag}/file"
        return self._perform_post_request(url_request=upload_url, body=None,
                                          files={"adclient_file": filename}, override_headers={})

    def add_ad_client_tag_options(self, name: str, tag: str, cli_options: list):
        ad_client = self.get_ad_client_info(name=name)
        tag_properties = self.get_ad_client_tag_info(ad_client=ad_client, tag=tag)
        tag_properties['options'] += cli_options
        return self._perform_put_request(f'{self.client_api_url}/catalog/AutoDriveClient/{name}',
                                         body=ad_client)

    def remove_ad_client_tag_options(self, name: str, tag: str,
                                     cli_option_labels: list):
        ad_client = self.get_ad_client_info(name=name)
        tag_properties = self.get_ad_client_tag_info(ad_client=ad_client, tag=tag)
        # search for cli option whose name matches the given label. accept only a single instance
        # in order to avoid multiple removals
        if not isinstance(cli_option_labels, list):
            cli_option_labels = [cli_option_labels]
        for cli_option_label in cli_option_labels:
            print(f"Removing option {cli_option_label}")
            orig_opts = tag_properties.get('options')
            opts = [opt for opt in orig_opts if not opt.get('name') == cli_option_label]
            if not (len(orig_opts) - len(opts)) == 1:
                raise RuntimeError(f"Can't remove command line option '{cli_option_label}' from {name}:{tag}."
                                   " Expecting exactly one option to exist")
            tag_properties['options'] = opts

        return self._perform_put_request(f'{self.client_api_url}/catalog/AutoDriveClient/{name}',
                                         body=ad_client)

    def create_ad_client_tag(self, name: str, tag: str, filename: str,
                             cli_options=None, description=None):
        """Create a tag for an AutoDriver client "project". Will create ad client if no such project exists
        :type name: string
        :param name: AutoDriver client "project" name
        :type tag: string
        :param tag: Autdriver tag to create
        :type cli_options: list
        :param cli_options: (Optional) list of name:value pairs, describing the addiitonal parameters
        added to the AD Client launch command
        :type description: str
        :param description: (Optional) ADClient description. Used for creating an ADClient if not exists.
        """
        # declare ad_client
        ad_client = None
        try:
            # Try getting existing ADClient in order to update
            ad_client = self.get_ad_client_info(name=name)
        except Exception as e:
            e_args = e.args[0]
            if 'No driver found' in e_args:
                print(f'Creating new adclient for tag {tag}')
            else:
                print(f'Caught excpetion {e}')
        if not ad_client:
            # ADClient not exists
            if not description:
                # ADClient creation requires name and description
                raise RuntimeError(f'No ADClient named "{name}" was found and'
                                   ' description is required in order to create one')
            # Create new ADClient with name and description
            ad_client = self.create_ad_client(name=name, description=description)
        # ad_client might be returned with catalogData as flattened fields. If there is no catalogdata
        # in the response object, move all except the properties to be nested under catalogData
        if 'catalogData' not in ad_client:
            props = ad_client.pop('properties')
            tmp = ad_client
            ad_client = {
                'properties': props,
                'catalogData': tmp
            }
        # adclient tag is being created by uploading a file for the tag. After the tag is created, need to set the
        # rest of the properties, by updating the tag
        res = self._set_ad_client_tag_file(name=name, tag=tag, filename=filename)

        # adclient name might be modified by the server, catch the exact name from the response in order to
        # update the catalog info
        name = res.get('catalogData').get('name')

        # Add tags to existing ADClient
        client_tags = ad_client.get('properties').get('container_tags', [])
        client_tags.append(self._create_ad_client_tag_structure(tag=tag, filename=filename, cli_options=cli_options))

        # Set updated list of tags
        ad_client.get('properties')['container_tags'] = client_tags

        # Update ADClient in server
        return self._perform_put_request(f'{self.client_api_url}/catalog/AutoDriveClient/{name}',
                                         body=ad_client)

    def delete_ad_client(self, name: str):
        url = f'{self.client_api_url}/catalog/AutoDriveClient/{name}'
        return self._perform_delete_request(url_request=url)

    def delete_ad_client_tag(self, name: str, tag: str):
        ad_client = self.get_ad_client_info(name=name)
        container_tags = self._get_ad_clients_tags(ad_client)
        tag_idx = self._get_ad_client_tag_from_tags(container_tags, tag, index_only=True)
        if tag_idx is None:
            raise RuntimeError(f'Can not delete tag {tag} from client {name}')
        del container_tags[tag_idx]

        url = f'{self.client_api_url}/catalog/AutoDriveClient/{name}'
        return self._perform_put_request(url_request=url, body=ad_client)


if __name__ == "__main__":
    APICognataTutorialProgram.main()
