import unittest

import cognata_api.scenario.ai_vehicle as actors
import cognata_api.scenario.position as position
from cognata_api.utils.utils import color_to_hex, range_object, get_id


class SpawnAreaTests(unittest.TestCase):
    def test_creating_basic_spawn_area_cars_WORKS(self):
        self.maxDiff = None
        expected = {
            "name": "Spawn area 0003",
            "type": "cars",
            "object_count": 10,
            "color": "#c0b23e",
            "use_full_physics": True,
            "initial_speed": {
                "min": 20,
                "max": 30
            },
            "speed": {
                "min": 20,
                "max": 30
            },
            "politeness": {
                "min": 20,
                "max": 20
            },
            "time_to_collision": {
                "min": 1.5,
                "max": 1.5
            },
            "comfortable_braking": {
                "min": 2,
                "max": 2
            },
            "lane_change_speed": {
                "min": 0.25,
                "max": 0.25
            },
            "id": "wsg7jyjtc-57e9524hm-lput4m9ot-4bazqnxtp",
            "segments": [
                {
                    "segmentId": "2_19_19_-2",
                    "lane": -2,
                    "firstSectionID": 19,
                    "lastSectionID": 19,
                    "roadId": "2"
                },
                {
                    "segmentId": "2_19_19_-4",
                    "lane": -4,
                    "firstSectionID": 19,
                    "lastSectionID": 19,
                    "roadId": "2"
                },
                {
                    "segmentId": "2_19_19_-3",
                    "lane": -3,
                    "firstSectionID": 19,
                    "lastSectionID": 19,
                    "roadId": "2"
                },
                {
                    "segmentId": "2_19_19_-1",
                    "lane": -1,
                    "firstSectionID": 19,
                    "lastSectionID": 19,
                    "roadId": "2"
                }
            ],
            "shapes": [],
            "obj_type": "spawn_objects",
            "distribution": [
                {
                    "label": "Car-Generic Pickup Blue",
                    "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Blue",
                }
            ]
        }
        segments = [
            position.create_position(lane=-2, road_id="2", first_section_id=19, last_section_id=19, segment_id="2_19_19_-2"),
            position.create_position(lane=-4, road_id="2", first_section_id=19, last_section_id=19, segment_id="2_19_19_-4"),
            position.create_position(lane=-3, road_id="2", first_section_id=19, last_section_id=19, segment_id="2_19_19_-3"),
            position.create_position(lane=-1, road_id="2", first_section_id=19, last_section_id=19, segment_id="2_19_19_-1")
        ]
        tested = actors.create_spawn_area_cars(name="Spawn area 0003",
                                               segments=segments,
                                               shapes=[],
                                               color=color_to_hex("Yellow"),
                                               object_count=10,
                                               distribution=[
                                                   {
                                                       "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Blue",
                                                       "label": "Car-Generic Pickup Blue"
                                                   }
                                               ],
                                               use_full_physics=True,
                                               speed=range_object(20, 30),
                                               initial_speed=range_object(20,30),
                                               politeness_range=range_object(20,20),
                                               lane_change_speed_range=range_object(0.25, 0.25),
                                               comfortable_braking=range_object(2, 2),
                                               time_to_collision_range=range_object(1.5, 1.5))
        # ids are unique, drop them
        tested.pop("id")
        expected.pop("id")
        self.assertDictEqual(tested, expected)

    def test_creating_basic_spawn_area_parking_WORKS(self):
        self.maxDiff = None
        expected = {
            "name": "Spawn area 0001",
            "type": "parking_cars",
            "object_count": 10,
            "color": "#8e1208",
            "id": "j86vz4hij-a2qvndkk0-kua4s1id4-ci6hjt12e",
            "segments": [
                {
                    "segmentId": "1001000_24_25_-4",
                    "lane": -4,
                    "firstSectionID": 24,
                    "lastSectionID": 25,
                    "roadId": "1001000"
                },
                {
                    "segmentId": "1031000_20_20_-4",
                    "lane": -4,
                    "firstSectionID": 20,
                    "lastSectionID": 20,
                    "roadId": "1031000"
                }
            ],
            "shapes": [],
            "obj_type": "spawn_objects",
            "distribution": [
                {
                    "label": "Car-Generic Pickup Black",
                    "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Black",
                },
                {
                    "label": "Electric Car 2017",
                    "value": "Vehicles/Cars/Electric_Car_2017/Prefabs/Electric_Car_2017",
                }
            ]
        }
        segments = [
            position.create_position(lane=-4, road_id="1001000", first_section_id=24, last_section_id=25, segment_id="1001000_24_25_-4"),
            position.create_position(lane=-4, road_id="1031000", first_section_id=20, last_section_id=20, segment_id="1031000_20_20_-4")
        ]

        tested = actors.create_spawn_area_parking(name="Spawn area 0001",
                                                  segments=segments,
                                                  shapes=[],
                                                  color=color_to_hex("Red"),
                                                  object_count=10,
                                                  distribution=[

                                                          {
                                                              "label": "Car-Generic Pickup Black",
                                                              "value": "Vehicles/Cars/Generic_Pickup/Prefabs/Generic_Pickup_Black",
                                                          },
                                                          {
                                                              "label": "Electric Car 2017",
                                                              "value": "Vehicles/Cars/Electric_Car_2017/Prefabs/Electric_Car_2017",
                                                          }
                                                      ]
                                                  )
        # ids are unique, drop them
        tested.pop("id")
        expected.pop("id")
        self.assertDictEqual(tested, expected)

    def test_creating_basic_spawn_area_pedestrians_WORKS(self):
        self.maxDiff = None
        expected = {
            "name": "Spawn area 0001",
            "type": "people",
            "object_count": 10,
            "color": "#6e32c5",
            "use_full_physics": True,
            "id": "39ua7vjkz-an4gc7dma-usxguys30-l1siw25jq",
            "segments": [],
            "shapes": [
                {
                    "type": "polygon",
                    "id": "39ua7vjkz-an4gc7dma-usxguys30-l1siw25jq",
                    "positions": [
                        {
                            "lat": 40.4639051186553,
                            "lng": -79.97111710254104
                        },
                        {
                            "lat": 40.46375739748412,
                            "lng": -79.97144737571944
                        },
                        {
                            "lat": 40.46355112217889,
                            "lng": -79.97127519047355
                        },
                        {
                            "lat": 40.463755835096755,
                            "lng": -79.97081916779281
                        }
                    ]
                }
            ],
            "obj_type": "spawn_objects",
            "distribution": [
                {
                    "label": "Akio Walker",
                    "value": "Pedestrians/Age_20_40/Male/Akio_Walker",
                },
                {
                    "label": "Arthur Walker",
                    "value": "Pedestrians/Age_50_80/Male/Arthur_Walker",
                }
            ]
        }
        shape = {"id": get_id(),
                 "type": "polygon",
                 "positions":[
                     position.create_position(lng=-79.97111710254104, lat=40.4639051186553),
                     position.create_position(lng=-79.97144737571944, lat=40.46375739748412),
                     position.create_position(lng=-79.97127519047355, lat=40.46355112217889),
                     position.create_position(lng=-79.97081916779281, lat=40.463755835096755)]}

        tested = actors.create_spawn_area_pedestrians(name="Spawn area 0001",
                                                      segments=[],
                                                      shapes=[shape],
                                                      color=color_to_hex("Purple"),
                                                      object_count=10,
                                                      distribution=[
                                                          {
                                                              "label": "Akio Walker",
                                                              "value": "Pedestrians/Age_20_40/Male/Akio_Walker",
                                                          },
                                                          {
                                                              "label": "Arthur Walker",
                                                              "value": "Pedestrians/Age_50_80/Male/Arthur_Walker",
                                                          }
                                                      ],
                                                      use_full_physics=True)
        # ids are unique, drop them
        tested.pop("id")
        tested.get("shapes")[0].pop("id")
        expected.pop("id")
        expected.get("shapes")[0].pop("id")
        self.assertDictEqual(tested, expected)
