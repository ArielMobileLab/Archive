import unittest

import cognata_api.scenario.ai_vehicle as actors


class MovingObjectsTests(unittest.TestCase):
    def test_creating_basic_moving_object_WORKS(self):
        expected = {
            "name": "mo1",
            "obj_type": "moving_objects",
            "type": "some/brand/id",
            "waypoints": [],
            "scripts": []
        }
        tested = actors.create_moving_object("mo1", "some/brand/id", scripts=[], path=[])
        self.assertDictEqual(tested, expected)


if __name__ == "__main__":
    unittest.maxDiff = None
    unittest.main()

