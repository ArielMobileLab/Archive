class InputJsonStrings:
    TestName = 'TestName'


class TestDataStrings:
    EgoLocation = 'EgoLocation'
    EgoSpeed = 'EgoSpeed'
    EgoLateralDisplacement = 'EgoLateralDisplacement'
    EgoAcceleration = 'EgoAcceleration'
    EgoLane = 'EgoLane'

    TargetLocation = 'TargetLocation'
    AiDistance = 'AiDistance'
    AiCarSpeed = 'AiCarSpeed'
    AiCarLateralDisplacement = 'AiCarLateralDisplacement'
    AiCarLane = 'AiCarLane'

    ADStart = 'ADStart'
    FrameNumber = 'FrameNumber'
    DataState = 'DataState'
    LateralFrequency = 'LateralFrequency'
    Amplitude = 'Amplitude'
    SpiralStart = 'Ego Incoming Spiral Start'
    CurveStart = 'Ego Curve Start'
    AccelerationPoint = 'AccelerationPoint'

    SdkSetSpeed = 'TargetSpeed'
    SdkSetBlinker = 'indicators'

    AccStart = 'AI car started acceleration'
    AccEnd = 'AI car ended acceleration'

    LaneAnchors = 'LaneAnchors'


class TestData():
    # TODO - 1. add lane index/side
    # TODO - change this to dictionary
    def __init__(self):
        self.EgoLocation = None
        self.EgoSpeed = None
        self.EgoLateralDisplacement = None
        self.EgoAcceleration = None
        self.EgoLane = None

        self.TargetLocation = None
        self.AiDistance = None
        self.AiCarSpeed = None
        self.AiCarLateralDisplacement = None
        self.AiCarLane = None

        self.ADStart = None  # default - true.
        self.FrameNumber = None
        self.DataState = False
        self.LateralFrequency = None
        self.Amplitude = None

        self.SpiralStart = False
        self.CurveStart = False
        self.AccelerationPoint = None

        self.SdkSetSpeed = None
        self.SdkSetBlinker = None
        self.AccStart = False
        self.AccEnd = False

        self.LaneAnchors = None

    def get_dictionary(self):
        dict = {
            TestDataStrings.EgoLocation: self.EgoLocation,
            TestDataStrings.EgoSpeed: self.EgoSpeed,
            TestDataStrings.EgoLateralDisplacement: self.EgoLateralDisplacement,
            TestDataStrings.EgoAcceleration: self.EgoAcceleration,
            TestDataStrings.EgoLane: self.EgoLane,

            TestDataStrings.TargetLocation: self.TargetLocation,
            TestDataStrings.AiDistance: self.AiDistance,
            TestDataStrings.AiCarSpeed: self.AiCarSpeed,
            TestDataStrings.AiCarLateralDisplacement: self.AiCarLateralDisplacement,
            TestDataStrings.AiCarLane: self.AiCarLane,

            TestDataStrings.ADStart: self.ADStart,
            TestDataStrings.FrameNumber: self.FrameNumber,
            TestDataStrings.DataState: self.DataState,
            TestDataStrings.LateralFrequency: self.LateralFrequency,
            TestDataStrings.Amplitude: self.Amplitude,

            TestDataStrings.SpiralStart: self.SpiralStart,
            TestDataStrings.CurveStart: self.CurveStart,
            TestDataStrings.AccelerationPoint: self.AccelerationPoint,

            TestDataStrings.SdkSetSpeed: self.SdkSetSpeed,
            TestDataStrings.SdkSetBlinker: self.SdkSetBlinker,
            TestDataStrings.AccStart: self.AccStart,
            TestDataStrings.AccEnd: self.AccEnd,

            TestDataStrings.LaneAnchors: self.LaneAnchors,

        }
        return dict


class RulesStrings:
    RulesClass = 'RulesClass'
    RulesList = 'RulesList'
    RuleName = 'RuleName'
    RuleDefs = 'RuleDefs'
    Trigger = 'Trigger'

    RunningConditions = 'RunningConditions'
    LogFormat = 'LogFormat'

    # Rule Types
    MaintainDistanceRule = 'MaintainDistanceRule'
    MaintainTTCRule = 'MaintainTTCRule'
    DisplacementFromLaneCenterRule = 'DisplacementFromLaneCenterRule'
    MaxAmplitudeRule = 'MaxAmplitudeRule'

    DisplacementFrequencyRule = 'DisplacementFrequencyRule'
    MaintainSpeedRule = 'MaintainSpeedRule'
    MessagesCountRule = 'MessagesCountRule'
    VerifyLaneIDRule = 'VerifyLaneIDRule'
    TimeRule = 'TimeRule'
    ValueDifferenceBetweenMessagesRule = 'ValueDifferenceBetweenMessagesRule'
    MinimumAccRule = 'MinimumAccRule'
    UndefinedRule = 'UndefinedRule'
    RSSRule = 'RSSRule'

    MessageCount = 'MessageCount'
    RuleID = 'RuleID'
    Tolerance = 'Tolerance'
    WarnTolerance = 'WarnTolerance'
    Threshold = 'Threshold'
    ToleranceType = 'ToleranceType'
    AbsTolerance = 'abs'
    PercentageTolerance = 'percentage'
    ReferenceDistance = 'ReferenceDistance'
    ReferenceAcc = 'ReferenceAcc'
    ReferenceTTC = 'ReferenceTTC'
    ReferenceSpeed = 'ReferenceSpeed'
    MessageReferenceVal = 'MessageReferenceVal'
    DeltaBetweenMessages = 'DeltaBetweenMessages'
    Message = 'Message'
    MaxCountMsg = 'MaxCountMsg'
    BelongingLane = 'BelongingLane'
    MeasUnit = 'MeasUnit'
    Time = 'Time'
    Headway = 'Headway'
    TargetData = 'TargetData'

    RuleType = 'RuleType'
    Target = 'Target'

    TimeToReachGoal = 'TimeToReachGoal'

    # for RSS
    a_max_accel = "a_max_accel"
    a_max_brake = "a_max_brake"
    a_min_brake = "a_min_brake"
    ro = "ro"
    a_min_brake_correct = "a_min_brake_correct"
    a_max_accel_lat = "a_max_accel_lat"
    a_min_brake_lat = "a_min_brake_lat"
    mu = "mu"
    # Trigger issues
    # General trigger issues
    TriggerOn = 'ON'
    TriggerOff = 'OFF'
    TriggerType = 'type'
    TriggerEvent = 'event'
    TriggerValue = 'TriggerValue'
    AnchorName = 'AnchorName'
    # specific trigger issues
    TriggerTimeFromSimStart = 'TriggerTimeFromSimStart'
    TriggerTimeFromTriggerOn = 'TriggerTimeFromTriggerOn'
    TriggerFramesFromTriggerOn = 'TriggerFramesFromTriggerOn'
    TriggerDistance = 'distance'
    TriggerAdOn = 'AD-ON'
    TriggerAccelerationLocalMinima = 'TriggerAccelerationLocalMinima'
    TriggerSpeed = 'TriggerSpeed'
    TriggerFramesBeforeTriggerOff = 'FramesBeforeTriggerOff'
    TriggerEndOfSimulation = 'EndOfSimulation'
    TriggerSpiralStart = 'TriggerSpiralStart'
    TriggerCurveStart = 'TriggerCurveStart'
    TriggerAccelerationPoint = 'TriggerAccelerationPoint'

    TriggerSdkSetSpeed = 'TriggerSdkSetSpeed'
    TriggerSdkSetBlinker = 'TriggerSdkSetBlinker'
    TriggerAccStart = 'TriggerAccStart'
    TriggerAccEnd = 'TriggerAccEnd'
    TriggerLane = 'TriggerLane'


class ToleranceDetails:
    ToleranceRangeFrom = 'ToleranceRangeFrom'
    ToleranceRangeTo = 'ToleranceRangeTo'
    ToleranceRelativeValues = 'ToleranceRelativeValues'
    ToleranceList = 'ToleranceList'
    Min = 'Min'
    Max = 'Max'


class TriggerStatus:
    TriggerNotStarted = 'TriggerNotStarted'
    InTrigger = 'InTrigger'
    TriggerStopped = 'TriggerStopped'


class ResultStrings:
    RulesResults = 'RulesResults'
    SimulationRunResult = 'SimulationRunResult'
    ScenarioDefinitions = 'ScenarioDefinitions'
    Status = 'Status'
    ResultDetails = 'ResultDetails'


class RuleType:
    Verification = 'Verification'
    RunningConditon = 'RunningConditon'


class TargetType:
    EgoCar = 'EgoCar'
    AiCar = 'AiCar'
    InterVehicle = 'InterVehicle'
    AllCars = 'None'


class StatusStrings:
    NOT_INIT = 'NOT_INIT'
    FAIL = 'FAIL'
    PASS = 'PASS'
    WARN = 'WARN'
    INVALID = 'INVALID'
    # frontend do not support Valid status
    VALID = PASS


class EngineLogStrings:
    CurveSpeedLimit = 'CurveSpeedLimit'  # {'CurveSpeedLimit':20}
    TargetSpeed = 'TargetSpeed'
    EgoLength = 'EgoLength'
    AiCarLength = 'AiCarLength'


class AnchorsNames:
    StraightStart = 'Road Start'
    EgoCar = 'EgoCar'
    AiCar = 'AiCar'


class PermutationParams:
    TargetSpeed = 'TargetSpeed'
    TargetInterval = 'TargetInterval'
    BelongingLane = 'BelongingLane'
    CurveSpeed = 'CurveSpeed'
    TriggerTime = 'TriggerTime'
    LaneChangeSpeedPlusTime = 'LaneChangeSpeedPlusTime'


class MeasurementUnit:
    Meters = 'Meters'
    Headway = 'Headway'


class TargetData:
    Speed = 'Speed'
    LateralDisplacement = 'LateralDisplacement'
