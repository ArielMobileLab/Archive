# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from .define_rules import *


def ego_reach_speed_scn2(target_interval, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerDistance, trigger_value=target_interval,
                                    trigger_tolerance=0.05, tolerance_type=RulesStrings.PercentageTolerance))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=1, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.56, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=target_speed, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_inter_speed(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.56, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=0, check_target=TargetType.InterVehicle)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_inter_speed(target_interval, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerDistance, trigger_value=target_interval,
                                    trigger_tolerance=0.05, tolerance_type=RulesStrings.PercentageTolerance))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.56, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=0, check_target=TargetType.InterVehicle)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_speed_scn4(target_interval, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerDistance, trigger_value=target_interval,
                                    trigger_tolerance=0.05, tolerance_type=RulesStrings.PercentageTolerance))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=1, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.56, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=target_speed, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_speed_scn7(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerDistance, trigger_value=target_interval,
                                    trigger_tolerance=0.05, tolerance_type=RulesStrings.PercentageTolerance))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=1, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.56, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=0, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_speed(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.28, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=target_speed, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_speed_tolerance_var(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed, trigger_tolerance=0.027,
                    tolerance_type=RulesStrings.AbsTolerance, trigger_target=TargetType.EgoCar))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    tolerance_dict = {ToleranceDetails.ToleranceList:
                          [{ToleranceDetails.ToleranceRangeFrom: 0, ToleranceDetails.ToleranceRangeTo: 19.445,
                            ToleranceDetails.ToleranceRelativeValues: {ToleranceDetails.Min: -1.389,
                                                                       ToleranceDetails.Max: 2.78}},
                           {ToleranceDetails.ToleranceRangeFrom: 19.445, ToleranceDetails.ToleranceRangeTo: 7777,
                            ToleranceDetails.ToleranceRelativeValues: {ToleranceDetails.Min: -0.8334,
                                                                       ToleranceDetails.Max: 1.389}}]
                      }
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=tolerance_dict,
                              tolerance_type=RulesStrings.AbsTolerance, reference_speed=target_speed,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_speed_after_curve(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerCurveStart))
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerAccelerationLocalMinima, trigger_value=0.08))
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed, trigger_tolerance=0.028,
                    tolerance_type=RulesStrings.AbsTolerance, trigger_target=TargetType.EgoCar))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.28, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=target_speed, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ai_car_maintain_speed_after_acc(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAccEnd))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.56,
                              tolerance_type=RulesStrings.AbsTolerance, reference_speed=target_speed,
                              check_target=TargetType.AiCar)
    log_format = ' Ai car speed {AiCarSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_speed_after_reach_speed(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed,
                                    tolerance_type=RulesStrings.AbsTolerance, trigger_tolerance=0.027, trigger_target=TargetType.EgoCar))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=1.389,
                              tolerance_type=RulesStrings.AbsTolerance, reference_speed=target_speed,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_time_to_reach_speed(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerSdkSetSpeed, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed,
                                     tolerance_type=RulesStrings.AbsTolerance, trigger_tolerance=0.027, trigger_target=TargetType.EgoCar))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=3.3, tolerance_type=RulesStrings.AbsTolerance,
                              time=0, check_target=TargetType.EgoCar)
    log_format = ' Goal was not reached in the required time:{Time} (s). Actual time: {TimeToReachGoal}(s)'
    rule = get_rule(test_name=RulesStrings.TimeRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_time_to_reach_speed_after_curve(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerCurveStart, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed,
                                     tolerance_type=RulesStrings.AbsTolerance, trigger_tolerance=0.027,trigger_target=TargetType.EgoCar))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=3.3, tolerance_type=RulesStrings.AbsTolerance,
                              time=0, check_target=TargetType.EgoCar)
    log_format = ' Goal was not reached in the required time:{Time} (s). Actual time: {TimeToReachGoal}(s)'
    rule = get_rule(test_name=RulesStrings.TimeRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_dist_scn2(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerAccelerationLocalMinima, trigger_value=0.08))
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=0, trigger_tolerance=0.56,
                                    trigger_target=TargetType.InterVehicle,
                                    tolerance_type=RulesStrings.AbsTolerance))

    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_dist_after_ai_acc(target_interval, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    # trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAccStart))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAccEnd))
    # trigger_off_l.append(
    #     get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed, trigger_tolerance=0.56,
    #                 trigger_target=TargetType.AiCar,
    #                 tolerance_type=RulesStrings.AbsTolerance))

    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.3,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_dist_scn4(target_speed, target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed, trigger_tolerance=0.56,
                    tolerance_type=RulesStrings.AbsTolerance, trigger_target=TargetType.EgoCar))

    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_dist_curve(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerCurveStart))

    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_dist(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_dist_after_set_speed(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerSdkSetSpeed, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_dist_while_decc(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAccStart, ))
    trigger_off_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAccEnd, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.3,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_maintain_dist_curve_scn7(target_interval, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerSpeed, trigger_value=target_speed,
                                    tolerance_type=RulesStrings.AbsTolerance, trigger_tolerance=0.56, trigger_target=TargetType.EgoCar))

    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, reference_distance=target_interval,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_on_correct_lane(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, belonging_lane=belonging_lane,
                              check_target=TargetType.EgoCar, anchor_name=AnchorsNames.StraightStart)
    log_format = ' Ego is not in belonging lane '
    rule = get_rule(test_name=RulesStrings.VerifyLaneIDRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ai_car_on_correct_lane(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, belonging_lane=belonging_lane,
                              check_target=TargetType.AiCar, anchor_name=AnchorsNames.StraightStart)
    log_format = ' Ego is not in belonging lane '
    rule = get_rule(test_name=RulesStrings.VerifyLaneIDRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_on_center_of_lane_ver(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=15, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.2, warn_tolerance=0.6,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.EgoCar)
    log_format = ' Lateral Displacement {EgoLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}'
    rule = get_rule(test_name=RulesStrings.DisplacementFromLaneCenterRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_on_center_of_lane_run(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerAdOn, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.2, warn_tolerance=0.2,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.EgoCar)
    log_format = ' Lateral Displacement {EgoLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}'
    rule = get_rule(test_name=RulesStrings.DisplacementFromLaneCenterRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def ego_min_acc(test_id, trigger_time):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=trigger_time, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.01,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.EgoCar, reference_acc=-0.3)
    log_format = ' decceleration {EgoAcceleration} (m/s^2) does not comply with {ReferenceAcc} (m/s^2) with tolerance {Tolerance}'
    rule = get_rule(test_name=RulesStrings.MinimumAccRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ai_car_on_center_of_lane(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.2, warn_tolerance=0.2,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.AiCar)
    log_format = ' Lateral Displacement {AiCarLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}'
    rule = get_rule(test_name=RulesStrings.DisplacementFromLaneCenterRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def ai_car_on_center_of_lane_scn21(test_id, time_trigger):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=time_trigger, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.2, warn_tolerance=0.2,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.AiCar)
    log_format = ' Lateral Displacement {AiCarLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}'
    rule = get_rule(test_name=RulesStrings.DisplacementFromLaneCenterRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def ai_car_on_center_of_lane_scn23(test_id, time_trigger):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=time_trigger, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.2, warn_tolerance=0.2,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.AiCar)
    log_format = ' Lateral Displacement {AiCarLateralDisplacement} (m) does not comply with Tolerance values, Pass:{Tolerance} Warning:{WarnTolerance}'
    rule = get_rule(test_name=RulesStrings.DisplacementFromLaneCenterRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule



def inter_car_distance(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesBeforeTriggerOff, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerAdOn, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, reference_distance=target_interval, tolerance=0.1,
                              tolerance_type=RulesStrings.PercentageTolerance, check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def inter_car_distance_scn4(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesBeforeTriggerOff, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerAdOn, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, reference_distance=200, tolerance=0.1,
                              tolerance_type=RulesStrings.PercentageTolerance, check_target=TargetType.EgoCar, mes_unit=MeasurementUnit.Meters)
    log_format = ' Ego distance  {AiDistance} (m) does not comply with target distance {ReferenceDistance} (m) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def inter_car_distance_after_blinker(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesBeforeTriggerOff, trigger_value=1, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerSdkSetBlinker, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, reference_distance=target_interval, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, check_target=TargetType.EgoCar)
    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def inter_car_distance_spiral(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerSpiralStart, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=1, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, reference_distance=105, tolerance=25,
                              tolerance_type=RulesStrings.AbsTolerance, check_target=TargetType.EgoCar)
    log_format = ' Ego inter distance {AiDistance} (m) does not comply with target distance {ReferenceDistance} (m) with tolerance {Tolerance} (m)'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_enter_curve_when_inter_dist(target_interval, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0, ))
    trigger_off_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerDistance, trigger_value=target_interval,
                    tolerance_type=RulesStrings.PercentageTolerance, trigger_tolerance=0.05))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=TestDataStrings.CurveStart)

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_reach_speed_on_ad_on(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesBeforeTriggerOff, trigger_value=1, ))
    trigger_off_l.append(get_trigger_ad_on())
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.56,
                              tolerance_type=RulesStrings.AbsTolerance, reference_speed=target_speed,
                              check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ai_car_reach_speed_on_ad_on(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAdOn, ))
    trigger_off_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.56,
                              tolerance_type=RulesStrings.AbsTolerance, reference_speed=target_speed,
                              check_target=TargetType.AiCar)
    log_format = ' Ego speed {AiCarSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def get_ad_start_message_count_rule(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar, message=TestDataStrings.ADStart)

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def get_spiral_start_message_count_rule(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAdOn))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=TestDataStrings.SpiralStart)

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def get_curve_start_message_count_rule(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAdOn))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=TestDataStrings.CurveStart)

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def get_curve_speed_diff(delta, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn,
                                     trigger_value=1))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=EngineLogStrings.TargetSpeed, message_val=EngineLogStrings.CurveSpeedLimit,
                              delta_between_messages=delta, tolerance=0.001, tolerance_type=RulesStrings.PercentageTolerance)

    log_format = ' difference of target speed value {Message} (m/s) from curve speed value {MessageReferenceVal} (m/s) is not delta {DeltaBetweenMessages}'
    rule = get_rule(test_name=RulesStrings.ValueDifferenceBetweenMessagesRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def get_AD_ON_message_before_curve_rule(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerCurveStart))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar, message=TestDataStrings.ADStart)

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def displacement_position_freq(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))

    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.Verification, check_target=TargetType.EgoCar, tolerance=0.1, warn_tolerance=0.5,
                              tolerance_type=RulesStrings.AbsTolerance, threshold=0.003)

    log_format = 'Lateral displacement frequency {LateralFrequency} (Hz) is not within target Tolerance values, Pass {Tolerance} (Hz) Warning:{WarnTolerance} (Hz)'
    rule = get_rule(test_name=RulesStrings.DisplacementFrequencyRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def displacement_position_amp(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromTriggerOn, trigger_value=15, ))

    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.Verification, check_target=TargetType.EgoCar, tolerance=0.3,
                              tolerance_type=RulesStrings.AbsTolerance, threshold=0.01, target_data=TargetData.LateralDisplacement)

    log_format = 'Lateral displacement Amplitude {Amplitude} (m) is not within tolerance {Tolerance} (m)'
    rule = get_rule(test_name=RulesStrings.MaxAmplitudeRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def speed_amp(test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerEndOfSimulation, ))

    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.Verification, check_target=TargetType.EgoCar, tolerance=0.833,
                              tolerance_type=RulesStrings.AbsTolerance, threshold=0.01, target_data=TargetData.Speed)

    log_format = 'Speed Amplitude {Amplitude} (m/s) is not within tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaxAmplitudeRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def sdk_set_speed(target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=TestDataStrings.SdkSetSpeed, message_val=target_speed, )

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def sdk_blinker(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(RuleType.RunningConditon, check_target=TargetType.EgoCar,
                              message=TestDataStrings.SdkSetBlinker, message_val=belonging_lane, )

    log_format = ' message appears {MessageCount} times'
    rule = get_rule(test_name=RulesStrings.MessagesCountRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ego_change_lane(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerSdkSetBlinker))
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerLane, trigger_value=belonging_lane,
                                    trigger_target=TargetType.EgoCar, anchor_name=AnchorsNames.StraightStart))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, belonging_lane=belonging_lane,
                              check_target=TargetType.EgoCar, anchor_name=AnchorsNames.StraightStart)

    log_format = ' Ego is not in belonging lane '

    rule = get_rule(test_name=RulesStrings.VerifyLaneIDRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def ai_car_change_lane(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerSdkSetBlinker))
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerLane, trigger_value=belonging_lane,
                                    trigger_target=TargetType.AiCar, anchor_name=AnchorsNames.StraightStart))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerEndOfSimulation))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, belonging_lane=belonging_lane,
                              check_target=TargetType.AiCar, anchor_name=AnchorsNames.StraightStart)

    log_format = ' Ego is not in belonging lane '

    rule = get_rule(test_name=RulesStrings.VerifyLaneIDRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule


def verify_car_change_lane(time_trigger, belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=time_trigger,
                                    trigger_target=TargetType.AiCar))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn,
                                     trigger_value=1))
    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, belonging_lane=belonging_lane,
                              check_target=TargetType.AiCar, anchor_name=AnchorsNames.StraightStart)

    log_format = ' Ego is not in belonging lane '

    rule = get_rule(test_name=RulesStrings.VerifyLaneIDRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def not_change_lane(belonging_lane, test_id):
    trigger_on_l = []
    trigger_off_l = []
    trigger_on_l.append(
        get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerEndOfSimulation,))

    trigs = get_triggers(trigger_on_l, trigger_off_l)

    test_defs = get_rule_defs(rule_type=RuleType.Verification, belonging_lane=belonging_lane,
                              check_target=TargetType.EgoCar, anchor_name=AnchorsNames.StraightStart)

    log_format = ' Ego is not in belonging lane '

    rule = get_rule(test_name=RulesStrings.UndefinedRule,
                    test_defs=test_defs,
                    triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule
def maintain_dist_until_set_speed(test_id, target_interval):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger_ad_on())
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerSdkSetSpeed, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, reference_distance=target_interval, tolerance=0.05,
                              tolerance_type=RulesStrings.PercentageTolerance, check_target=TargetType.EgoCar)

    log_format = ' Ego headway {Headway} (s) does not comply with target headway {ReferenceDistance} (s) with tolerance {Tolerance}%'
    rule = get_rule(test_name=RulesStrings.MaintainDistanceRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def time_to_reach_acc(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerAccelerationPoint, ))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent,
                                     trigger_value=RulesStrings.TriggerAccStart, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.RunningConditon, tolerance=0.1, tolerance_type=RulesStrings.AbsTolerance,
                              time=0, check_target=TargetType.AiCar)
    log_format = ' Goal was not reached in the required time:{Time} (s). Actual time: {TimeToReachGoal}(s)'
    rule = get_rule(test_name=RulesStrings.TimeRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule

def maintain_speed_scn23(trigger_time_start, trigger_time_end, target_speed, test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=trigger_time_start))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerFramesFromTriggerOn, trigger_value=trigger_time_end, ))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.28, tolerance_type=RulesStrings.AbsTolerance,
                              reference_speed=target_speed, check_target=TargetType.EgoCar)
    log_format = ' Ego speed {EgoSpeed} (m/s) does not comply with target speed {ReferenceSpeed} (m/s) with tolerance {Tolerance} (m/s)'
    rule = get_rule(test_name=RulesStrings.MaintainSpeedRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule
def get_trigger_ad_on():
    trigger = get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerAdOn)
    return trigger

def rss(test_id):
    trigger_on_l = []
    trigger_off_l = []

    trigger_on_l.append(get_trigger(trigger_type=RulesStrings.TriggerTimeFromSimStart, trigger_value=0))
    trigger_off_l.append(get_trigger(trigger_type=RulesStrings.TriggerEvent, trigger_value=RulesStrings.TriggerEndOfSimulation,))
    trigs = get_triggers(trigger_on_l, trigger_off_l)
    test_defs = get_rule_defs(rule_type=RuleType.Verification, tolerance=0.5, tolerance_type=RulesStrings.PercentageTolerance,
                              check_target=TargetType.AllCars, a_max_accel=9.8, a_max_accel_lat=1.8, a_max_brake=9.8,
                              a_min_brake=4.9, a_min_brake_correct=2.45, a_min_brake_lat=7.4, mu=0.3, ro=0.215)

    log_format = ''
    rule = get_rule(test_name=RulesStrings.RSSRule, test_defs=test_defs, triggers=trigs,
                    log_format=log_format, test_id=test_id)
    return rule