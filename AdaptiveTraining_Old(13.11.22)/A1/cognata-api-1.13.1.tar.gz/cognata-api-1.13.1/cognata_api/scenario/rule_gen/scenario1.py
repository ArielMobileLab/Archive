# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from rules_gen import *


def gen_scenario1(target_speed,  target_interval, belonging_lane):
    rule_list = []
    # maintain_speed_rule
    ego_maintain_speed_rule = ego_reach_inter_speed(test_id='Target1_001.04.01')
    rule_list.append(ego_maintain_speed_rule)
    # reach target interval
    ego_dist_rule = ego_maintain_dist(target_interval=get_var_expression(target_interval), test_id='Target1_001.05.01')
    rule_list.append(ego_dist_rule)
    # maintain center lane
    ego_maintain_center = ego_on_center_of_lane_ver(test_id='Target1_001.06.01')
    rule_list.append(ego_maintain_center)
    # displacement amplitude
    amp = displacement_position_amp(test_id='Target1_001.06.02')
    rule_list.append(amp)

    freq = displacement_position_freq(test_id='Target1_001.06.02')
    rule_list.append(freq)

    # running conditions
    # Ego car is in the correct lane
    ego_maintain_lane_rule = ego_on_correct_lane(belonging_lane=get_var_expression(belonging_lane), test_id='Target1_001.R.1')
    rule_list.append(ego_maintain_lane_rule)
    # ai car is in the correct lane
    ai_car_maintain_lane_rule = ai_car_on_correct_lane(belonging_lane=get_var_expression(belonging_lane), test_id='Target1_001.R.2')
    rule_list.append(ai_car_maintain_lane_rule)
    # ego car is on center of lane
    ego_maintain_center_lane = ego_on_center_of_lane_run(test_id='Target1_001.R.3')
    rule_list.append(ego_maintain_center_lane)
    # ai car is on center of lane
    ai_car_maintain_center_lane = ai_car_on_center_of_lane(test_id='Target1_001.R.4')
    rule_list.append(ai_car_maintain_center_lane)
    # AD ON Inter-Vehicle distance is TargetInterval
    inter_car_dist = inter_car_distance(target_interval=get_var_expression(target_interval), test_id='Target1_001.R.5')
    rule_list.append(inter_car_dist)
    # Ego car speed at AD ON is TargetSpeed - 10
    ego_speed_ad_on = ego_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed, offset=-2.78), test_id='Target1_001.R.6')
    rule_list.append(ego_speed_ad_on)
    # ai car speed at AD ON is TargetSpeed - 10
    ai_car_speed_ad_on = ai_car_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed, offset=-2.78), test_id='Target1_001.R.7')
    rule_list.append(ai_car_speed_ad_on)
    # ad on message count
    ad_on_message = get_ad_start_message_count_rule(test_id='Target1_001.R.8')
    rule_list.append(ad_on_message)
    # TODO - add sensor check
    return rule_list

if __name__ == '__main__':
    rules = gen_scenario1(5.56, 1, 0)
    test_def = get_scenario_analysis_def(analysis_title='kuku', rules_list=rules)
    save_defs_to_file(test_def, 'D:\\test\\scn1.json')