# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from rules_gen import *


def gen_scenario21(target_speed,  target_interval, belonging_lane,trigger_time):
    rule_list = []

    # TODO - Target1_021.04
    undef = not_change_lane(belonging_lane, test_id='Target1_021.04')
    rule_list.append(undef)
    # TODO - Target1_021.05
    # deacc valid
    decc_rule = ego_min_acc(test_id='Target1_021.05', trigger_time=get_var_expression(trigger_time))
    rule_list.append(decc_rule)

    ego_maintain_center_lane = ego_on_center_of_lane_run(test_id='Target1_021.R.1')
    rule_list.append(ego_maintain_center_lane)
    # ai car is on center of lane
    ai_car_maintain_center_lane = ai_car_on_center_of_lane_scn21(test_id='Target1_021.R.2', time_trigger=get_var_expression(trigger_time))
    rule_list.append(ai_car_maintain_center_lane)
    # AD ON Inter-Vehicle distance is TargetInterval * 0.5
    # inter_car_dist = inter_car_distance(target_interval=get_var_expression(target_interval),
    #                                     test_id='Target1_021.R.3')
    # rule_list.append(inter_car_dist)
    # Ego car speed at AD ON is TargetSpeed
    ego_speed_ad_on = ego_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed), test_id='Target1_021.R.3')
    rule_list.append(ego_speed_ad_on)
    # ai car speed at AD ON is TargetSpeed
    # ai_car_speed_ad_on = ai_car_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed), test_id='Target1_021.R.5')
    # rule_list.append(ai_car_speed_ad_on)
    #TODO - Target1_021.R.6
    # # ai car change_lane TODO - fix
    # ai_car_change_lane_rule = ai_car_change_lane(belonging_lane=get_var_expression(belonging_lane, factor=-1, offset=-1), test_id='Target1_021.R.6')
    # rule_list.append(ai_car_change_lane_rule)
    # ad on message count
    ad_on_message = get_ad_start_message_count_rule(test_id='Target1_021.R.4')
    rule_list.append(ad_on_message)

    return rule_list

if __name__ == '__main__':
    rules = gen_scenario21(PermutationParams.TargetSpeed, PermutationParams.TargetInterval, PermutationParams.BelongingLane, PermutationParams.TriggerTime)
    test_def = get_scenario_analysis_def(analysis_title='kuku', rules_list=rules)
    save_defs_to_file(test_def, 'D:\\test\\scn21.json')