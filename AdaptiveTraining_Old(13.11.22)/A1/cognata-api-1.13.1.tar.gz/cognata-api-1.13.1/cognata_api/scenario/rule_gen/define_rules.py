# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from .validation_definitions import *

import json


def get_trigger(trigger_type, trigger_value, trigger_target=None, trigger_tolerance=None, tolerance_type=None,
                anchor_name=None):
    trigger = {}
    trigger[RulesStrings.TriggerType] = trigger_type
    trigger[RulesStrings.TriggerValue] = trigger_value
    if trigger_target is not None:
        trigger[RulesStrings.Target] = trigger_target
    if trigger_tolerance is not None:
        trigger[RulesStrings.Tolerance] = trigger_tolerance
    if tolerance_type is not None:
        trigger[RulesStrings.ToleranceType] = tolerance_type
    if anchor_name is not None:
        trigger[RulesStrings.AnchorName] = anchor_name
    return trigger


def get_triggers(trigger_on, trigger_off):
    return {RulesStrings.TriggerOn: trigger_on, RulesStrings.TriggerOff: trigger_off}


def get_rule(test_name, test_defs, triggers, log_format, test_id):
    return {RulesStrings.RuleName: test_name, RulesStrings.RuleDefs: test_defs,
            RulesStrings.Trigger: triggers, RulesStrings.LogFormat: log_format, RulesStrings.RuleID: test_id}


def get_scenario_analysis_def(analysis_title, rules_list):
    return {InputJsonStrings.TestName: analysis_title, RulesStrings.RulesList: rules_list}


def get_rule_defs(rule_type, tolerance=None, warn_tolerance=None,
                  tolerance_type=None, reference_speed=None,
                  reference_distance=None, reference_acc=None, check_target=None, message=None, message_val=None,
                  delta_between_messages=None, belonging_lane=None, time=None, anchor_name=None, threshold=None,
                  mes_unit=None, target_data=None,  a_max_accel=None, a_max_brake=None, a_min_brake=None, ro=None,
                  a_min_brake_correct=None, a_max_accel_lat=None, a_min_brake_lat=None, mu=None):
    # TODO - refactor to value
    defs = {}
    defs[RulesStrings.RuleType] = rule_type
    if tolerance is not None:
        defs[RulesStrings.Tolerance] = tolerance
    if warn_tolerance is not None:
        defs[RulesStrings.WarnTolerance] = warn_tolerance
    if tolerance_type is not None:
        defs[RulesStrings.ToleranceType] = tolerance_type
    if reference_speed is not None:
        defs[RulesStrings.ReferenceSpeed] = reference_speed
    if reference_distance is not None:
        defs[RulesStrings.ReferenceDistance] = reference_distance
    if check_target is not None:
        defs[RulesStrings.Target] = check_target
    if time is not None:
        defs[RulesStrings.Time] = time
    if message is not None:
        defs[RulesStrings.Message] = message
        if message_val is not None:
            defs[RulesStrings.MessageReferenceVal] = message_val
        if delta_between_messages is not None:
            defs[RulesStrings.DeltaBetweenMessages] = delta_between_messages
    if belonging_lane is not None:
        defs[RulesStrings.BelongingLane] = belonging_lane
    if anchor_name is not None:
        defs[RulesStrings.AnchorName] = anchor_name
    if threshold is not None:
        defs[RulesStrings.Threshold] = threshold
    if mes_unit is not None:
        defs[RulesStrings.MeasUnit] = mes_unit
    if reference_acc is not None:
        defs[RulesStrings.ReferenceAcc] = reference_acc
    if target_data is not None:
        defs[RulesStrings.TargetData] = target_data
    if a_max_accel is not None:
        defs[RulesStrings.a_max_accel] = a_max_accel
    if a_max_brake is not None:
        defs[RulesStrings.a_max_brake] = a_max_brake
    if a_min_brake is not None:
        defs[RulesStrings.a_min_brake] = a_min_brake
    if ro is not None:
        defs[RulesStrings.ro] = ro
    if a_min_brake_correct is not None:
        defs[RulesStrings.a_min_brake_correct] = a_min_brake_correct
    if a_max_accel_lat is not None:
        defs[RulesStrings.a_max_accel_lat] = a_max_accel_lat
    if a_min_brake_lat is not None:
        defs[RulesStrings.a_min_brake_lat] = a_min_brake_lat
    if mu is not None:
        defs[RulesStrings.mu] = mu
    return defs


def save_defs_to_file(defs, save_path):
    with open(save_path, 'wb')as save_stream:
        json.dump(defs, save_stream)


def get_var_expression(var_name, offset=0.0, factor=1.0):
    if isinstance(var_name, str):
        return "${{{fac}*{var}+{off}}}".format(fac=factor, var=var_name, off=offset)
    else:
        return var_name * factor + offset

def get_var_expression2(var_name):
    if isinstance(var_name, str):
        return "${{1/{var}}}".format( var=var_name)
    else:
        return var_name

def get_var_expression3(var_name1, var_name2, offset=0.0, factor=1.0 ):
    if isinstance(var_name1, str):
        return "${{{fac}*{var1}+{off} + 1/{var2}}}".format( var1=var_name1, var2=var_name2, fac=factor, off=offset)
    else:
        return var_name1


# class ComputedVariable(VariableBase):
#     def __init__(self, name, data_type, computation_formula):
#         super(ComputedVariable, self).__init__(name, data_type, self.VariableTypes.computed, [0])
#         self.computation_formula = computation_formula
#
#     def to_json(self):
#         base_result = super(ComputedVariable, self).to_json_base()
#         base_result.update({"computation_formula": self.computation_formula})
#         return base_result
if __name__ == '__main__':
    print(get_var_expression('speed'))