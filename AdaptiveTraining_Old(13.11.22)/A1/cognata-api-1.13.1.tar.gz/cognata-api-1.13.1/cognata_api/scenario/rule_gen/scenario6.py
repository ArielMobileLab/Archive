# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from rules_gen import *


def gen_scenario6(target_speed,  target_interval, belonging_lane, curve_speed):
    rule_list = []
    # time to reach speed
    ego_time_to_reach_speed_after_curve_rule = ego_time_to_reach_speed_after_curve(target_speed=get_var_expression(curve_speed), test_id='FCR001-002.04.01 ')
    rule_list.append(ego_time_to_reach_speed_after_curve_rule)
    # maintain speed after reach speed
    ego_maintain_speed_after_curve_rule = ego_maintain_speed_after_curve(target_speed=get_var_expression(curve_speed), test_id='FCR001-002.04.02')
    rule_list.append(ego_maintain_speed_after_curve_rule)
    # running conditions
    # Ego car is in the correct lane
    ego_maintain_lane_rule = ego_on_correct_lane(belonging_lane=get_var_expression(belonging_lane), test_id='Target1_006.R.1')
    rule_list.append(ego_maintain_lane_rule)
    # ai car is in the correct lane
    ai_car_maintain_lane_rule = ai_car_on_correct_lane(belonging_lane=get_var_expression(belonging_lane), test_id='Target1_006.R.2')
    rule_list.append(ai_car_maintain_lane_rule)
    # ego car is on center of lane
    ego_maintain_center_lane = ego_on_center_of_lane_run(test_id='Target1_006.R.3')
    rule_list.append(ego_maintain_center_lane)
    # ai car is on center of lane
    ai_car_maintain_center_lane = ai_car_on_center_of_lane(test_id='Target1_006.R.4')
    rule_list.append(ai_car_maintain_center_lane)
    # AD ON Inter-Vehicle distance is TargetInterval
    inter_car_dist = inter_car_distance(target_interval=get_var_expression(target_interval), test_id='Target1_006.R.5')
    rule_list.append(inter_car_dist)
    # Ego car speed at AD ON is TargetSpeed
    ego_speed_ad_on = ego_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed, offset=-1.389), test_id='Target1_006.R.6')
    rule_list.append(ego_speed_ad_on)
    # ai car speed at AD ON is TargetSpeed - 10
    ai_car_speed_ad_on = ai_car_reach_speed_on_ad_on(target_speed=get_var_expression(target_speed), test_id='Target1_006.R.7')
    rule_list.append(ai_car_speed_ad_on)
    # ad on message count
    ad_on_message = get_ad_start_message_count_rule(test_id='Target1_006.R.8')
    rule_list.append(ad_on_message)
    # spiral message count
    spiral_message = get_spiral_start_message_count_rule(test_id='Target1_006.R.9')
    rule_list.append(spiral_message)
    # curve message count
    curve_message = get_curve_start_message_count_rule(test_id='Target1_006.R.10')
    rule_list.append(curve_message)
    # curve_speed_diff
    curve_speed_diff = get_curve_speed_diff(delta=1.389, test_id='Target1_006.R.11')
    rule_list.append(curve_speed_diff)
    return rule_list

if __name__ == '__main__':
    rules = gen_scenario6(30.56, 1, 0, 27.78)
    test_def = get_scenario_analysis_def(analysis_title='kuku', rules_list=rules)
    save_defs_to_file(test_def, 'D:\\test\\scn6.json')