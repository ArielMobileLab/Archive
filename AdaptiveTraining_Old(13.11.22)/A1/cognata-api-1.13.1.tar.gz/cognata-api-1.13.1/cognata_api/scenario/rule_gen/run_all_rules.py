# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
from scenario1 import gen_scenario1
from scenario2 import gen_scenario2
from scenario3 import gen_scenario3
from scenario4 import gen_scenario4
from scenario5 import gen_scenario5
from scenario6 import gen_scenario6
from scenario7 import gen_scenario7
from scenario8 import gen_scenario8
from scenario9 import gen_scenario9
from scenario10 import gen_scenario10
from scenario11 import gen_scenario11
from scenario13 import gen_scenario13
from scenario14 import gen_scenario14
from scenario15 import gen_scenario15
from scenario16 import gen_scenario16
from scenario17 import gen_scenario17
from scenario18 import gen_scenario18
from scenario20 import gen_scenario20
from scenario21 import gen_scenario21
from scenario22 import gen_scenario22
from scenario23 import gen_scenario23
from define_rules import get_scenario_analysis_def, save_defs_to_file
for i in range(1,24):
    if i == 1:
      rules = gen_scenario1(5, 1, 0)
    elif i == 2:
      rules = gen_scenario2(5, 1, 0)
    elif i == 3:
      rules = gen_scenario3(5, 1, 0)
    elif i == 4:
      rules = gen_scenario4(5, 1, 0)
    elif i == 5:
      rules = gen_scenario5(5, 1, 0)
    elif i == 6:
      rules = gen_scenario6(5, 1, 0, 5)
    elif i == 7:
      rules = gen_scenario7(5, 1, 0)
    elif i == 8:
      rules = gen_scenario8(5, 1, 0)
    elif i == 9:
        rules = gen_scenario9(5, 1, 0)
    elif i == 10:
      rules = gen_scenario10(5, 1, 0)
    elif i == 11:
      rules = gen_scenario11(5, 1, 0)
    elif i == 12:
        continue
    elif i == 13:
      rules = gen_scenario13(5, 1, 0)
    elif i == 14:
      rules = gen_scenario14(5, 1, 0)
    elif i == 15:
      rules = gen_scenario15(5, 1, 0)
    elif i == 16:
      rules = gen_scenario16(5, 1, 0)
    elif i == 17:
        rules = gen_scenario17(5, 1, 0, 5)
    elif i == 18:
        rules = gen_scenario18(5, 1, 0)
    elif i == 19:
        continue
    elif i == 20:
        rules = gen_scenario20(5, 1, 0)
    elif i == 21:
        rules = gen_scenario21(5, 1, 0, 1)
    elif i == 22:
        rules = gen_scenario22(5, 1, 0,1)
    elif i == 23:
        rules = gen_scenario23(5, 1, 0, 5, 0.3)

    test_def = get_scenario_analysis_def(analysis_title='kuku', rules_list=rules)
    save_defs_to_file(test_def, 'D:\\test\\regression\\scn' + str(i) + '.json')