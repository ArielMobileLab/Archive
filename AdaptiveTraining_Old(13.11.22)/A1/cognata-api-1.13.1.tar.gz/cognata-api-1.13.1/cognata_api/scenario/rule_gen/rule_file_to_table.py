# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import json
from validation_definitions import *
import csv
import glob
import shutil
import ntpath

import os


# extract the relevant data from rule json
def rule_file_to_table(json_rule_data):
    table_dict = {}
    rule_list = json_rule_data[RulesStrings.RulesList]
    for idx, rule in enumerate(rule_list):
        table_dict[idx] = {}
        table_dict[idx][RulesStrings.RuleName] = rule[RulesStrings.RuleName]
        table_dict[idx][RulesStrings.RuleID] = rule[RulesStrings.RuleID]
        table_dict[idx][RulesStrings.RuleDefs] = rule[RulesStrings.RuleDefs]
        table_dict[idx]['Trigger_on'] = rule[RulesStrings.Trigger][RulesStrings.TriggerOn]
    return table_dict


# parsing dictionary to csv format
def write_table_dict_to_csv(table, write_path,  test_name, read_path=None,):
    r = None
    # if strcture is defined and template file is already exists read it
    if read_path is not None:
        rf = open(read_path, 'rb')
        r = csv.reader(rf)
    with open(write_path, 'wb') as f:
        w = csv.writer(f)
        test_name_list = []
        if r is not None:
            test_name_prev = r.next()
            test_name_list.append(tuple(test_name_prev + [test_name]))
        else:
            test_name_list.append(('test_name', test_name))
        w.writerows(test_name_list)
        # every space should be skipped when reading
        w.writerows([''])
        if r is not None:
            r.next()

        for rule_idx in table:
            rule = table[rule_idx]
            for itm in rule:
                write = True
                # if item is dict
                if isinstance(rule[itm], dict):
                    w.writerows([''])
                    if r is not None:
                        r.next()
                    w.writerows([(itm, '')])
                    if r is not None:
                        r.next()
                    data = sorted(rule[itm].iteritems())
                    if r is not None:
                        # remove key
                        for idx, tup in enumerate(data):
                            data[idx] = tuple(r.next() + [tup[1]])
                    data_to_write = iter(data)
                # if item is list of dicts
                elif isinstance(rule[itm], list):
                    write = False
                    w.writerows([''])
                    if r is not None:
                        r.next()
                    w.writerows([(itm, '')])
                    if r is not None:
                        r.next()
                    for element in rule[itm]:
                        data = sorted(element.iteritems())
                        if r is not None:
                            # remove key
                            for idx, tup in enumerate(data):
                                data[idx] = tuple(r.next() + [tup[1]])
                        data_to_write = iter(data)
                        w.writerows(data_to_write)
                        w.writerows([''])
                        if r is not None:
                            r.next()
                # if item is key only
                else:
                    data_list = []
                    if r is not None:
                        data_list.append(tuple(r.next() + [rule[itm]]))
                    else:
                        data_list.append(tuple([itm, rule[itm]]))
                    data_to_write = data_list
                if write:
                    w.writerows(data_to_write)
            w.writerows([''])
            if r is not None:
                r.next()
            w.writerows([''])
            if r is not None:
                r.next()
        f.close()


def make_table_from_dir(dir_path):
    f_list = sorted(glob.glob(dir_name + '\\' + '*'))
    table_path = dir_path + r'\test.csv'
    temp_table_path = r'\test_temp.csv'
    for f_idx, f_path in enumerate(f_list):
        f = open(f_path, 'r')
        json_data = json.load(f)
        f.close()
        dict_table = rule_file_to_table(json_data)
        test_name = os.path.splitext(ntpath.basename(f_path))[0]
        # first file only write
        if f_idx == 0:
            write_table_dict_to_csv(dict_table, table_path, test_name, read_path=None)
        # others append to previous lines
        else:
            write_table_dict_to_csv(dict_table, temp_table_path, test_name, read_path=table_path)
            shutil.move(temp_table_path, table_path)


if __name__ == '__main__':
    dir_name = r'D:\honda\analysis_jsons'
    make_table_from_dir(dir_name)
