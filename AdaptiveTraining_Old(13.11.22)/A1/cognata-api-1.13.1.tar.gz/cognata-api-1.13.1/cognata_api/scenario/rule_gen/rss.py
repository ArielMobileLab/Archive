from rules_gen import *


def gen_rss():
    rule_list = []
    # maintain_speed_rule
    rss_rule = rss(test_id='rss01')
    rule_list.append(rss_rule)

    return rule_list

if __name__ == '__main__':
    rules = gen_rss()
    test_def = get_scenario_analysis_def(analysis_title='kuku', rules_list=rules)
    save_defs_to_file(test_def, 'D:\\test\\rss.json')