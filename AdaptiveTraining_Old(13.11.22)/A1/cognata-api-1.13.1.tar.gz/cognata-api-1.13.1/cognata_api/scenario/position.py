# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential


def create_position(lane=None,
                    lng=None, lat=None,
                    road_id="0",
                    first_section_id=0,
                    last_section_id=0,
                    segment_id=None):
    try:
        int(road_id)
    except ValueError:
        my_exception = ValueError("road_id must be integer")
        raise my_exception

    rv = {
        "roadId": f"{road_id}",
        "firstSectionID": int(first_section_id),
        "lastSectionID": int(last_section_id)
    }
    if lane is not None:
        rv["lane"] = lane
    if lat is not None and lng is not None:
        rv["lng"] = lng
        rv["lat"] = lat
    if segment_id:
        rv["segmentId"] = segment_id

    return rv


def create_moving_object_waypoint(lat, lng, is_anchor, anchor_name=None):
    rv = {
        "position": {
            "lat": lat,
            "lng": lng
        },
        "isAnchor": is_anchor
    }
    if is_anchor:
        if anchor_name is None:
            raise ValueError("Can't create anchor waypoint w/o name")
        rv["anchorName"] = anchor_name
    return rv


def create_anchor_object(anchor_name, lat=None, lng=None, waypoint_id=None, waypoint_moving_obj_id=None):
    if lat is None or lng is None:
        raise ValueError("Note: lat,lng params for anchor objects are required")
    assert isinstance(anchor_name, str), f"anchor_name must be of type string. got {type(anchor_name).__name__}"
    rv = {
        "name": anchor_name,
        "lat": lat,
        "lng": lng
    }

    if waypoint_id is not None and waypoint_moving_obj_id is not None:
        rv["isMovingObjectIndex"] = waypoint_id
        rv["isMovingObjectId"] = waypoint_moving_obj_id
    return rv


def create_anchor_reference_object(anchor_name, lat=None, lng=None, waypoint_id=None, waypoint_moving_obj_id=None):
    if lat is not None or lng is not None:
        print("Note: lat,lng params for anchor reference objects are deprecated")
    assert isinstance(anchor_name, str), f"anchor_name must be of type string. got {type(anchor_name).__name__}"
    rv = {
        "name": anchor_name
    }

    if waypoint_id is not None and waypoint_moving_obj_id is not None:
        rv["isMovingObjectIndex"] = waypoint_id
        rv["isMovingObjectId"] = waypoint_moving_obj_id
    return rv


def create_relative_location_object(headway, lane_offset, relative_distance,
                                    anchor_name=None, lat=None, lng=None, waypoint_id=None, waypoint_moving_obj_id=None,
                                    anchor_reference_object=None):
    if anchor_reference_object is None:
        anchor_reference_object = create_anchor_reference_object(anchor_name=anchor_name, lat=lat, lng=lng,
                                                                 waypoint_id=waypoint_id,
                                                                 waypoint_moving_obj_id=waypoint_moving_obj_id)
    rv = {
        "headway": headway,
        "laneOffset": lane_offset,
        "relativeDistance": relative_distance,
        "isRelative": True,
        "anchorRef": anchor_reference_object}

    return rv


