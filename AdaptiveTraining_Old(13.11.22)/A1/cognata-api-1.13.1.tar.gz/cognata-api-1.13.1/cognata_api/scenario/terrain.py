# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential


class Terrain:
    def __init__(self, map_id, mode=""):
        self.id = map_id
        self.mode = mode

    def to_json(self):
        return {"id": self.id,
                "mode": self.mode}
