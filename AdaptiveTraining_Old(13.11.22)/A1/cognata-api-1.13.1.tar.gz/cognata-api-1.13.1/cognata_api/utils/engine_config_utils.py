# Copyright Cognata Ltd. (c) 2019 - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
# Proprietary and confidential
import json
import sys
from difflib import context_diff
from os import listdir


def print_json_diff(file1, file2):
    for line in context_diff(open(file1).readlines(), open(file2).readlines()):
        sys.stdout.write(line)


def engine_configs_identical(file1, file2):
    json1 = json.load(open(file1))
    json2 = json.load(open(file2))
    #remove these keys before comparing because it is supposed to be different
    json1['sceneDescription'].pop("sessionId")
    json1['sceneDescription'].pop("dateCreated")
    json1['sceneDescription'].pop("dateModified")
    json1['generalSettings'].pop("outputFolder")

    json2['sceneDescription'].pop("sessionId")
    json2['sceneDescription'].pop("dateCreated")
    json2['sceneDescription'].pop("dateModified")
    json2['generalSettings'].pop("outputFolder")
    return ordered(json1) == ordered(json2)


def compare_engine_config_directories(path1, path2):
    diff_count = 0
    # compare engine_configs
    dir1_files = listdir(path1)
    dir2_files = listdir(path2)
    for index in range(len(dir1_files)-1):
        if dir1_files[index] != "index.json":
            full_file_name1 = path1 + "\\" + dir1_files[index]
            full_file_name2 = path2 + "\\" + dir2_files[index]
            if not engine_configs_identical(full_file_name1, full_file_name2):
                sys.stdout.write(full_file_name1 + " is not identical to " + full_file_name2 + "\n")
                diff_count += 1
    sys.stdout.write("diff count = " + str(diff_count) + "\n")
    return diff_count != 0


def ordered(obj):
    if isinstance(obj, dict):
        return sorted((k, ordered(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return sorted(ordered(x) for x in obj)
    else:
        return obj


if __name__ == "__main__":
    file1 = sys.argv[1]
    file2 = sys.argv[2]
    if engine_configs_identical(file1, file2):
        sys.stdout.write("\nFiles are identicl")
    else:
        sys.stdout.write("\nFiles are different")
        print_json_diff(file1, file2)
