##Please note, there is a repo within a repo(submodule) in this project, it is not yet widely used across Cognata, so feel free to ask for help; as a beginning, after cloning perform the following commands in order to be fully synced:
```$ git clone git@bitbucket.org:cognatadev/scenariosgenerator.git ScenariosGenerator # clone of parent repo into ScenariosGenerator
$ cd ScenariosGenerator
$ git submodule init
$ git submodule update --recursive --remote # Notice Telegram combines two sequential dashes (-) into a big one, so add one in case needed
```

####Link to the repo's overview page in bitbucket:
https://bitbucket.org/cognatadev/scenariosgenerator/src/master/