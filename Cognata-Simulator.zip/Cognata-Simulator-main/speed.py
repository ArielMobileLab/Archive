#!/usr/bin/env python
#Speed meter for all scripts
import rospy
from sensor_msgs.msg import NavSatFix

rospy.init_node("speedometer")


class fonts: # works only for print() function
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'


def callback(msg):
    speed = msg.longitude
    print(fonts.RED + str(round(speed * 3.6, 1)) + " km/h")


sub = rospy.Subscriber("/cognataSDK/GPS/info", NavSatFix, callback, queue_size=10)

rospy.spin()
