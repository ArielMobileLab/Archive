from inspect import Parameter
import rospy
import tkinter
from geometry_msgs.msg import Point
from std_msgs.msg import Float64


# from tkinter import *
# from tkinter import messagebox


def callback_glass(data): # Get the massages from the Sub from matlab
   

    print(data)
    print(type(data))

    #print(value)
    #print(type(value))
    #print(value[6:])
    value = str(data)

    if value[6] == "0" :
       
     root = tkinter.Tk() # print on the screen warrning
     root.title('WARRNING')
     root.configure(bg='red')
     root.mainloop()

    # root.title('Ariel - Moblie lab')
    # root.iconbitmap('c:/gui/codemy.ico')
    # root.geometry("300x300")                                                                                                                                           
    # massagebox.showinfo("shoinfo", "information")
    # root.mainloop()
if __name__ == '__main__':
   
    rospy.init_node('Glasses_node') # name of the Sub node
    
    #rospy.Subscriber('/glasses_topic', Point, callback_glass)  ## Sub function (name of the topic that we listen to, massage type, call fanction)
    rospy.Subscriber('/glasses_topic', Float64, callback_glass)
    
    rospy.spin()