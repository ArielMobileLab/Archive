#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  talk with car


import rospy
from std_msgs.msg import Float32,Int8,Float64


if __name__ == '__main__':

  

    rospy.init_node('Alex_the_king')  # open node

    car_cmd_publisher_gas = rospy.Publisher('cognataSDK/car_command/gas_cmd', Float32, queue_size=1) #  open Publisher

    rate = rospy.Rate(10) 

    gs_cmd = Float32()  
    gs_cmd = 0.9
   
    while not rospy.is_shutdown():
        car_cmd_publisher_gas.publish(gs_cmd)  # send massages
        print(gs_cmd)     

        rate.sleep()

    

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ without the change of puls


#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy




class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()

        self.wheel_listener = rospy.Subscriber("delayed", Joy, self.WHEELcb)  # wheel Listener
	    #self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32, queue_size=1)  # Publisher
        # Queue sizes are queue_size=1 because old information is not relevant and does not need to be sent to the car
        print(fonts.BLUE + "starting latency" + fonts.ENDC)
        
        self.rate = rospy.Rate(50)  # 50 [Hz]
        
        while not rospy.is_shutdown():

            self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
            self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
            self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
            self.rate.sleep()

        self.in_session = True

    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_gas.data = (1 + msg.axes[1]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2
        

if __name__ == '__main__':
    try:
        wheel_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Latency Control")
    except rospy.ROSInterruptException:
        rospy.loginfo("latency_node finished")




#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ with the change of puls

#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, Int8, Float64
from sensor_msgs.msg import Joy


class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()

        self.wheel_listener = rospy.Subscriber("delayed", Joy, self.WHEELcb)  # wheel Listener
        # self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32,
                                                       queue_size=1)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32,
                                                     queue_size=1)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32,
                                                       queue_size=1)  # Publisher

        # Queue sizes are queue_size=1 because old information is not relevant and does not need to be sent to the car
        print(fonts.BLUE + "starting latency" + fonts.ENDC)

        self.rate = rospy.Rate(50)  # 50 [Hz]
        
        while not rospy.is_shutdown():
            self.puls_listner = rospy.Subscriber('/puls', Float64, self.puls)  
            self.rate.sleep()

        self.in_session = True

    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_gas.data = (1 + msg.axes[1]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2


    def puls(self, msg):
        value = str(msg)
        if value[9] == "1" : 
            self.car_cmd_publisher_gas.publish(0.9)
        else:
            self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
            self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
            self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
            
if __name__ == '__main__':
    try:
        wheel_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Latency Control")
    except rospy.ROSInterruptException:
        rospy.loginfo("latency_node finished")


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ego car with matlab

import rospy
from std_msgs.msg import Float32,Int8,Float64


if __name__ == '__main__':

  

    rospy.init_node('Alex_the_king')  # open node

    car_cmd_publisher_gas = rospy.Publisher('cognataSDK/car_command/gas_cmd', Float32, queue_size=1) #  open Publisher

    rate = rospy.Rate(10) 
  

    puls_listener = rospy.Subscriber("/puls", Float64, Puls)
   
    def Puls(data):
        value = str(data)

        if value[9] == "1" :
            while not rospy.is_shutdown():
            car_cmd_publisher_gas.publish(0.9)  # send massages   
            rate.sleep()
    


    #!!!!!!!!!!!!!!!!!!!!!!!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ last
#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy




class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()
        self.flag=False

        self.wheel_listener = rospy.Subscriber("delayed", Joy, self.WHEELcb)  # wheel Listener
	    #self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32, queue_size=1)  # Publisher
        # Queue sizes are queue_size=1 because old information is not relevant and does not need to be sent to the car
        self.wheel_listener = rospy.Subscriber("puls", Float32, self.puls)  # wheel Listener

        print(fonts.BLUE + "starting latency" + fonts.ENDC)
        
        self.rate = rospy.Rate(50)  # 50 [Hz]
        
        while not rospy.is_shutdown():
            
            if self.flag == True:
                self.car_cmd_publisher_gas.publish(0.9)
            else:
                self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
                self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
                self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
                self.rate.sleep()

        self.in_session = True
            

    def puls(self, msg):
        if msg.data == 1.0:
            self.flag = True


    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_gas.data = (1 + msg.axes[1]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2
        

if __name__ == '__main__':
    try:
        wheel_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Latency Control")
    except rospy.ROSInterruptException:
        rospy.loginfo("latency_node finished")


        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ last version

        #!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy


class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()
        self.flag = False

        self.wheel_listener = rospy.Subscriber("delayed", Joy, self.WHEELcb)  # wheel Listener
	    #self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)
        
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32, queue_size=1)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32, queue_size=1)  # Publisher
        
        # Queue sizes are queue_size=1 because old information is not relevant and does not need to be sent to the car
        self.wheel_listener_puls = rospy.Subscriber("puls", Float32, self.puls)  # wheel Listener
        
        print(fonts.BLUE + "starting latency" + fonts.ENDC)
        
        self.rate = rospy.Rate(50)  # 50 [Hz]
        
        while not rospy.is_shutdown():
            if self.flag == True:
                self.Logic()

            else:
                self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
                self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
                self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
            
            self.rate.sleep()

        self.in_session = True
            

    def puls(self, msg):
        if msg.data == 1.0:
            self.flag = True
        #else:
        #    self.flag = False


    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_gas.data = (1 + msg.axes[1]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2


    def Logic(self):
        self.car_cmd_publisher_steer.publish(0)
        self.car_cmd_publisher_gas.publish(0)
        self.car_cmd_publisher_brake.publish(1)   

    
    #def drive(self):
    #    self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
    #    self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
    #    self.car_cmd_publisher_brake.publish(0)
      


if __name__ == '__main__':
    try:
        #flag = False
        wheel_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Latency Control")
    
    except rospy.ROSInterruptException:
        rospy.loginfo("latency_node finished")