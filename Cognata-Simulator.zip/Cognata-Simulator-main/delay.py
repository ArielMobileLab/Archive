#!/usr/bin/env python
#Node for setting the delay time 
from sensor_msgs.msg import Joy
import functools
import rospy

rospy.init_node("delay")

pub = rospy.Publisher("delayed", Joy, queue_size=4)


def delayed_callback(msg, event):
    pub.publish(msg)


def callback(msg):
    timer = rospy.Timer(rospy.Duration(1.0), functools.partial(delayed_callback, msg), oneshot=True) #Duration is the delay time 


sub = rospy.Subscriber("joy", Joy, callback, queue_size=4)
rospy.spin()
