# Station setup
## Install
1. **Install nvidia driver 460**  

2. **Install docker**   
`sudo snap install docker`

3. **Install ros melodic**  
(http://wiki.ros.org/melodic/Installation/Ubuntu)

4. **Install cognata station**  
- copy dir
- enable all executables
- run `./install.sh`

5. **Install SDK**
(SDK in home dir)
- Extract the src folder to a catkin workspace (or a new folder if you wish to create a new workspace for this).  
- Copy all protobuf files files in `src/cognata_sdk_ros/libs/cognataSDKLibs to /usr/lib` (specifically : libprotobuf.so libprotobuf.so.19 libprotoc.so)  
- Run `catkin_make` in the workspace directory (the outer folder, one level below src).  
- add to bashrc `source ~/cognata_sdk_ros1_ws/devel/setup.bash`

6. **Install joy pack for ROS**  
`sudo apt-get install ros-melodic-joy`  
## Setup connection with "Windows Computer"

1. Connect lan cable
2. Go to setting-->network-->new wired connection
3. In IPv4, choose manual  
4. IP: address: 169.254.154.85  Netmask:255.255.0.0 Gateway: empty

# How to run

1. **Start roscore**  
open new terminal  
`roscore`

2. **Start wheel node and force feedback**  
open new terminal    
`ffset /dev/input/by-id/usb-Logitech_G29_Driving_Force_Racing_Wheel-event-joystick -a 50`  or for Xbox wheel  
`ffset /dev/input/by-id/usb-Logitech_G920_Driving_Force_Racing_Wheel_for_Xbox_One_0000b2eff7d6c59f-event-joystick -a 50`  or    
`ffset /dev/input/by-id/usb-Logitech_G920_Driving_Force_Racing_Wheel_for_Xbox_One_00006d6a90207f33-event-joystick -a 50`
`rosrun joy joy_node`

4. **Optional features**  
- **Start rear image view**  
open new treminal    
`rosrun image_view image_view image:=/cognataSDK/image/raw`  

- **Start speed meter**  
new treminal  
`rosrun cognata_sdk speed.py`  

5. **_Choose python script:_**    
- **Script for simple wheel control**  
open new terminal   
` rosrun cognata_sdk wheel.py`  

- **Script for for acc control**  
open new terminal   
`sudo -s`    
`rosrun cognata_sdk adaptive_cruise_control.py`  
open another new terminal   
`rostopic pub -r 1 /acc_distance std_msgs/Float32 "data: 20.0" `  

- **Script for for latency**  
open new terminal   
`rosrun cognata_sdk delay.py`      
open another new terminal   
`rosrun cognata_sdk latecny.py`  

6. **Start Cognata ROS SDK**  
new treminal  
`rosrun cognata_sdk ROSCognataSDK 10.5.0.43 9999 --optimize-rendering --gps`

## Auto launch setup

1.Copy the folder with simulation id name from `~/cognataStation_new_5.1.2021/simulations` to `~/cognataStation_new_5.1.2021/simclouds`

2.Create folder named `results`in the simulation id folder

3. **Create new launch file** 
replace $ID$ with simulation id name  

```
#!/bin/bash

~/cognataStation_new_5.1.2021/bin/engine/2020.4.0.3.7/SimCloud.x86_64 -logfile /home/omer/cognataStation_new_5.1.2021/simclouds/$ID$/Player.log --json-file /home/omer/cognataStation_new_5.1.2021/simclouds/$ID$/engine_config.json --control-ip 10.5.0.43 --control-port 5000 --asset-bundle-path /home/omer/cognataStation_new_5.1.2021/simulations/assetBundles -screen-height 1050 -screen-width 5760 -screen-quality Ultra -screen-fullscreen 0 --sdk-ip 10.5.0.43 --sdk-port 9999

mv ~/cognataStation_new_5.1.2021/simulations/$ID$ ~/cognataStation_new_5.1.2021/simclouds/$ID$/results/$(date +'leon_'%d.%m.%Y_%H':'%M':'%S)
```


