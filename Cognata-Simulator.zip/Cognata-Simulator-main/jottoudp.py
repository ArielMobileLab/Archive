#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Joy
import socket
import pickle


MY_ADDRESS = ('192.168.0.12', 12345)
CAR_ADDRESS = ('192.168.0.10', 12345)


def toUdp(msg):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(MY_ADDRESS)
    bmsg = pickle.dumps(msg)
    s.sendto(bmsg, CAR_ADDRESS)
    rospy.loginfo(str(msg) + ' send to :' + str(CAR_ADDRESS))
    s.close()


def callback(data):
    arr = [data.axes[0], data.axes[1], data.axes[2]]
    toUdp(arr)


if __name__ == '__main__':
    rospy.init_node('joyToUdp', anonymous=False)
    rospy.loginfo('Joy to UDP node ,init successfully')
    rospy.Subscriber("joy", Joy, callback)
    rospy.spin()
