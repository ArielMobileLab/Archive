#!/usr/bin/env python
#scripts for Cognata_ROS1_SDK that enable simulator teleoperation control for EGO car via wheel and pedals inputs.
#for Cognata SDK_ROS1-v0.1.04 and G920 wheel and pedals.

import rospy
from cognata_sdk.msg import DOGTOutput
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy
from wadllib.tests import data


class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()

        self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)  # wheel Listener
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32, queue_size=10)  #Publisher,queue_size=10 default 10
        #self.car_cmd_publisher_accel = rospy.Publisher('/cognataSDK/car_command/acceleration_cmd', Float32, queue_size=10)  #Publisher,queue_size=10 default 10
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32, queue_size=10)  # Publisher,queue_size=10 default 10
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32, queue_size=10)  # Publisher,queue_size=10 default 10
        print(fonts.BLUE + "starting wheel" + fonts.ENDC)
        self.rate = rospy.Rate(10)  # 10 [Hz]

        while not rospy.is_shutdown():
            self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
            self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
            self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
            #self.car_cmd_publisher_accel.publish(self.car_cmd_accel)
            self.rate.sleep()

        self.in_session = True

    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0] #reverse wheel input
        self.car_cmd_gas.data = (1 + msg.axes[1])/2 #range correction
        #self.car_cmd_accel.data = 0
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2 #range correction

if __name__ == '__main__':
    try:
        wheel_control()
    except rospy.ROSInterruptException:
        rospy.loginfo("wheel_node finished")


