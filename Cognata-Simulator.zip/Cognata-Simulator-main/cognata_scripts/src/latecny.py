#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy



class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class wheel_control:

    def __init__(self):
        rospy.init_node('wheel', anonymous=True)
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_accB = Float32()

        self.wheel_listener = rospy.Subscriber("delayed", Joy, self.WHEELcb)  # wheel Listener
	#self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32, queue_size=10)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32, queue_size=10)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32, queue_size=10)  # Publisher
        print(fonts.BLUE + "starting latency" + fonts.ENDC)
        self.rate = rospy.Rate(10)  # 10 [Hz]

        while not rospy.is_shutdown():
            self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
            self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
            self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
            self.rate.sleep()

        self.in_session = True

    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_gas.data = (1 + msg.axes[1]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[2]) / 1.2


if __name__ == '__main__':
    try:
        wheel_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Latency Control")
    except rospy.ROSInterruptException:
        rospy.loginfo("latency_node finished")


