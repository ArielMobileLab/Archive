#!/usr/bin/env python2.7
# image view 
import rospy
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge, CvBridgeError

rospy.init_node('opencv', anonymous=True)

bridge = CvBridge()


def show_image(img):
    cv2.imshow("rear_view", img)
    cv2.waitKey(3)


def image_callback(img_msg):
    rospy.loginfo(img_msg.header)

    try:
        cv_image = cv2.flip(bridge.imgmsg_to_cv2(img_msg, "passthrough"), 1)
    except CvBridgeError as e:
        rospy.logerr("CvBridge Error: {0}".format(e))

    show_image(cv_image)


cv2.namedWindow("rear_view", cv2.WINDOW_NORMAL)


while not rospy.is_shutdown():
    sub_image = rospy.Subscriber("cognataSDK/image/raw", Image, image_callback)
    rospy.spin()

