# SDK_sagi
This is a small sample/POC for Cognata SDK integration with ROS1:

Prequesits:

Ubuntu 16/18 with Ros Melodic Morenia (desktop distribution)
OR
Ubuntu 20 with Ros Neotic (desktop distribution)

Catkin build tool installed

Installation:
1 - Verify you have sourced you ROS installation in your current terminal - (run "source /opt/ros/melodic/setup.bash")
2 - Extract the src folder to a catkin workspace (or a new folder if you wish to create a new workspace for this).
3 - Copy all protobuf files files in src/cognata_sdk_ros/libs/cognataSDKLibs to /usr/lib (specifically : libprotobuf.so libprotobuf.so.19 libprotoc.so)
4 - Run catkin_make in the workspace directory (the outer folder, one level below src).
5 - The project will build & compile the executable to /devel/lib/cognata_sdk/
6 - Run ROS core - (run "roscore &")

Running:
In a second terminal:
1 - Run 'source devel/setup.bash' in the same folder you ran catkin_make to source package env.
2 - You can now run the sample in path /devel/lib/cognata_sdk:
ROSCognataSDK <IP> <PORT>
(The sample needs to run with an IP & port matching the settings on the Cognata Station you are connecting to.)
Adding a '--ai' starts the simulation with the Simulation Engine's AI driver.
Example command from the workspace folder : "./devel/lib/cognata_sdk/ROSCognataSDK 192.168.123.45 4010 --ai"

The sample will function just like the sample shown during the SDK presentation on a basic level - it will connect to the station and recieve 
keyboard commands (published and subscribed internally via ROS messages).
The sample's output will be published to topics as defined in ros_sample.hpp by name/type, it is limited to one sensor per type for proper functionality.
Implemented sensors include RGB camera, instance and class segmentation, GPS, car telemetries, radar and Cognata's semantic dogt and roi sensors.
