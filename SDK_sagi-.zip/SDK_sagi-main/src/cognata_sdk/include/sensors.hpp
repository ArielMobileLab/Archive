//
// sensors.hpp - sample application that use cognata simulation engine SDK
//
// Copyright Cognata Ltd. (c) 2018 - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
// Proprietary and confidential

#ifndef __COGNATASENSORS_H__
#define __COGNATASENSORS_H__

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>

#include <CognataSim.h>
#include <MathUtils.h>
#include <vectors.pb.h>
#include <google/protobuf/util/json_util.h>

#include "keyPress.hpp" // simple keyboard handling for windows and Linux

//ROS Messages
#include <sensor_msgs/Image.h> //  Image
#include <sensor_msgs/PointCloud2.h> // PointCloud
#include <nav_msgs/Odometry.h> // Odometry
#include <sensor_msgs/NavSatFix.h> // NavSatFix
#include <sensor_msgs/NavSatStatus.h> // NavSatStatus
#include <sensor_msgs/Imu.h> // Imu

#include <ros/console.h> //ROS_INFO

// User defined ROS Messages
#include "cognata_sdk/CarTelemetriesMsg.h"
#include "cognata_sdk/RadarOutputHeader.h"
//DOGT & ROI
#include "cognata_sdk/DOGTOutput.h"
#include "cognata_sdk/ROIOutput.h"

using namespace Cognata::SDK;
using namespace std;

class EgoData;

/*!
 * Class containing information on ego car
 */
class EgoData
{
public:
    EgoData() : mPosition(0.0f, 0.0f, 0.0f),
                mGPSPosition(0.0f, 0.0f, 0.0f),
                mVelocityLocal(0.0f, 0.0f, 0.0f),
                mAccelerationLocal(0.0f, 0.0f, 0.0f),
                mAngularVelocityLocal(0.0f, 0.0f, 0.0f),
                mAngularAccelerationLocal(0.0f, 0.0f, 0.0f)
    {
    }

    /// true if ego car was initialized successfully
    bool initialized = false;
    /// ego car heading in degrees
    float heading = 0.0f;
    /// ego car speed in meters per second
    float speed = 0.0f;
    /// ego car position
    Eigen::Vector3f mPosition;
    /// position of GPS
    Eigen::Vector3f mGPSPosition;
    /// ego car local velocity
    Eigen::Vector3f mVelocityLocal;
    /// ego car local acceleration
    Eigen::Vector3f mAccelerationLocal;
    /// ego car local angular velocity
    Eigen::Vector3f mAngularVelocityLocal;
    /// ego car local angular acceleration
    Eigen::Vector3f mAngularAccelerationLocal;
};

class ClosestTarget
{
public:
    bool isValid = false;
    float DistLgt = 0.0f;
};

class OEM_ROIProcessing : public CameraGT
{
public:
    OEM_ROIProcessing(ClosestTarget *closestTarget, const EgoData *egoData)
        : mClosestTarget(closestTarget),
          mEgoData(egoData)
    {
    }

    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const ROIOutput &roiOutput) override;
    
    cognata_sdk::ROIOutput getRoiRosMsg()
    {
        return mRoiRosMsg;
    }

private:
    ClosestTarget *mClosestTarget;
    const EgoData *mEgoData;
    bool mfirstProcess = true;
    Eigen::Vector3f mEgoBeginningPos;
    float mEgoBeginningHdg;
    // nav_msgs::Odometry mRosMsg;
    cognata_sdk::ROIOutput mRoiRosMsg;
};

class OEM_E2CCProcessing : public E2CChannel
{
public:
    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const E2COutput &e2COutput) override;
};

class OEM_LaneDetectorProcessing : public LaneDetector
{
public:
    OEM_LaneDetectorProcessing(EgoData *egoData) : m_EgoData(egoData)
    {
    }
    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const LaneDetectorOutput &ldOutput) override;

private:
    EgoData *m_EgoData = nullptr;
};

/*!
 * \brief Example Class: GPS Sensor output handler.
 *
 * This class is an example for writing GPS Sensor output handlers. In order to handle GPS sensor output you must:
 *  -# create an object of class
 *  \code
 *  OEM_GPSProcessing* mMyGPSProcessing = nullptr;
 *  mMyGPSProcessing = new OEM_GPSProcessing(&mEgoData, mGPSPosition);
 *  \endcode
 *  -# register the output handler with the \ref Cognata::SDK::CognataSim object
 * \code
 *  CognataErr mErr = mSim->registerSensor<GPSOutput>(EgoCarNumber, GPSID, *mMyGPSProcessing);
 *  \endcode
 *  -# Once a new message is received the \ref Dispatch method is called.
  */

class OEM_GPSProcessing : public GPS
{
public:
    OEM_GPSProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
     * Main method for handling GPS sensor output
     * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
     * @param baseSensorInfo general sensor information.
     * @param gpsOutput GPS sensor output in a <a href="./CognataSimMessages.html#Cognata.SDK.GPSOutput">GPSOutput </a> object
     *
     * use the Dispatch method to read the sensor data:
     * \code
     * // update ego data from GPS
        mEgoData->heading = gpsOutput.orientation().z();
        mEgoData->speed = gpsOutput.speed();

     * \endcode
     */
    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const GPSOutput &gpsOutput) override;
   
    sensor_msgs::Imu getRosIMUMsg()
    {
        return mRosIMUMsg;
    }

    sensor_msgs::NavSatFix getRosGPSMsg()
    {
        return mRosGPSMsg;
    }

private:
    EgoData *mEgoData = nullptr;
    sensor_msgs::Imu mRosIMUMsg;
    sensor_msgs::NavSatFix mRosGPSMsg;
};

/*!
 * \brief Example Class: Lidar Sensor output handler.
 *
 * This class is an example for writing Lidar Sensor output handlers. In order to handle Lidar sensor output you must:
 *  -# create an object of class
 *  \code
    OEM_LidarProcessing mMyLidarProcessing = new OEM_LidarProcessing(&mEgoData, mGPSPosition);
*  \endcode
 *  -# register the output handler with the \ref Cognata::SDK::CognataSim object
 * \code
 *  CognataErr mErr = mSim->registerSensor<LidarOutput>(EgoCarNumber, mLidarID, *mMyLidarProcessing);
 *  \endcode
 *  -# Once a new message is received the \ref Dispatch method is called.
  */

class OEM_LidarProcessing : public Lidar
{
public:
    OEM_LidarProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
 * Main method for handling Lidar sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param lidarOutput Lidar sensor output in a <a href="./CognataSimMessages.html#Cognata.SDK.LidarOutput">LidarOutput</a> object
 *
 * use the Dispatch method to read the sensor data:
 * \code
 * // read Lidar data point array from LidarOutput object
    const string& pointsStr = lidarOutput.points();
    float* pData = (float*)(&lidarOutput.points()[0]);
     // go over data and process it
    }
* \endcode
 */
    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const LidarOutput &lidarOutput) override;
    
    sensor_msgs::PointCloud2 getRosMsg()
    {
        return mRosMsg;
    }

private:
    EgoData *mEgoData = nullptr;
    sensor_msgs::PointCloud2 mRosMsg;
};

/*!
 * \brief Example Class: Radar Sensor output handler.
 *
 * This class is an example for writing an Radar Sensor output handlers. In order to handle Radar Sensor output you must:
 *  -# create an object of class
 *  \code
    OEM_RadarProcessing mMyRadarProcessing = new OEM_RadarProcessing(&mEgoData, mGPSPosition);
*  \endcode
 *  -# register the output handler with the \ref Cognata::SDK::CognataSim object
 * \code
    CognataErr mErr = mSim->registerSensor<RadarOutput>(EgoCarNumber, mRadarID, *mMyRadarProcessing);
 *  \endcode
 *  -# Once a new message is received the \ref Dispatch method is called.
  */
class OEM_RadarProcessing : public Radar
{
public:
    OEM_RadarProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
 * Main method for handling Radar sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param radarOutput Radar sensor output: representation of the current frame as captured by the Radar sensor POV
 *
 * use the Dispatch method to read the sensor data:
 * \code

  \endcode
 */

    void Dispatch(const EngineToClientMessage &baseInfo, const SensorOutput &baseSensorInfo, const RadarOutput &radarOutput) override;

    cognata_sdk::RadarOutputHeader getRosMsg()
    {
        return mRosMsg;
    }
    
private:
    EgoData *mEgoData = nullptr;
    cognata_sdk::RadarOutputHeader mRosMsg;
};

/*!
 * \brief Example Class: RGB Camera Sensor output handler.
 *
 * This class is an example for writing an RGB Camera Sensor output handlers. In order to handle RGB Camera Sensor output you must:
 *  -# create an object of class
 *  \code
    OEM_RGBCameraProcessing mMyRGBCameraProcessing = new OEM_RGBCameraProcessing(&mEgoData, mGPSPosition);
*  \endcode
 *  -# register the output handler with the \ref Cognata::SDK::CognataSim object
 * \code
    CognataErr mErr = mSim->registerSensor<RGBCameraOutput>(EgoCarNumber, mRgbCameraID, *mMyRGBCameraProcessing);
 *  \endcode
 *  -# Once a new message is received the \ref Dispatch method is called.
  */
class OEM_RGBCameraProcessing : public RGBCamera
{
public:
    OEM_RGBCameraProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }



    /*!
 * Main method for handling RGB Camera sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param rgbCameraOutput RGB Camera sensor output: representation of the current frame as captured by the Camera sensor POV
 *
 * use the Dispatch method to read the sensor data:
 * \code
            uint8_t* pixels = (uint8_t*)(&rgbCameraOutput.pixels()[0]);
            uint32_t channels = 4; // RGBA
            // process the data. for example: write it to file.
            writeBMPFile(rgbCameraOutput.width(), rgbCameraOutput.height(), channels, pixels);

  \endcode
 */

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const RGBCameraOutput &rgbCameraOutput) override;

    sensor_msgs::Image getRosMsg()
    {
        return mRosMsg;
    }

private:
    EgoData *mEgoData = nullptr;
    sensor_msgs::Image mRosMsg;
};

/*!
 * \brief Example Class: Depth Camera Sensor output handler.
 *
 * This class is an example for writing a Depth Camera Sensor output handlers. In order to handle Depth Camera Sensor output you must:
 *  -# create an object of class
 *  \code
    OEM_DchCameraProcessing mMyDepthCameraProcessing = new OEM_DchCameraProcessing(&mEgoData, mGPSPosition);
*  \endcode
 *  -# register the output handler with the \ref Cognata::SDK::CognataSim object
 * \code
    CognataErr mErr = mSim->registerSensor<DepthCameraOutput>(EgoCarNumber, mDepthCameraID, *mMyDepthCameraProcessing);
 *  \endcode
 *  -# Once a new message is received the \ref Dispatch method is called.
  */
class OEM_DchCameraProcessing : public DepthCamera
{
public:
    OEM_DchCameraProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
 * Main method for handling Depth Camera sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param depthCameraOutput Depth Camera sensor output: representation of the current frame as captured by the Camera sensor POV
 *
 * use the Dispatch method to read the sensor data:
 * \code
            uint8_t* pixels = (uint8_t*)(&depthCameraOutput.pixels()[0]);
            uint32_t channels = 4; // RGBA
            // process the data. for example: write it to file.
            writeBMPFile(depthCameraOutput.width(), depthCameraOutput.height(), channels, pixels);

  \endcode
 */

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const DepthCameraOutput &depthCameraOutput) override;

    sensor_msgs::Image getRosMsg()
    {
        return mRosMsg;
    }

private:
    EgoData *mEgoData = nullptr;
    sensor_msgs::Image mRosMsg;
};

class OEM_DcsCameraProcessing : public DepthCamera
{
public:
    OEM_DcsCameraProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
 * Main method for handling Depth Camera sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param depthCameraOutput Depth Camera sensor output: representation of the current frame as captured by the Camera sensor POV
 *
 * use the Dispatch method to read the sensor data:
 * \code
            uint8_t* pixels = (uint8_t*)(&depthCameraOutput.pixels()[0]);
            uint32_t channels = 4; // RGBA
            // process the data. for example: write it to file.
            writeBMPFile(depthCameraOutput.width(), depthCameraOutput.height(), channels, pixels);

  \endcode
 */

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const DepthCameraOutput &depthCameraOutput) override;

    sensor_msgs::Image getRosMsg()
    {
        return mRosMsg;
    }

private:
    EgoData *mEgoData = nullptr;
    sensor_msgs::Image mRosMsg;
};

class OEM_CarTelemetriesProcessing : public CarTelemetries
{
public:
    OEM_CarTelemetriesProcessing()
    {
    }

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const CarTelemetriesOutput &carTelemetriesOutput) override;

    cognata_sdk::CarTelemetriesMsg getRosMsg()
    {
        return mRosMsg;
    }

private:
    cognata_sdk::CarTelemetriesMsg mRosMsg;
};

class OEM_SCLProcessing : public SemanticClassLabeling
{
public:
    OEM_SCLProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
 * Main method for handling Semantic Class labeling sensor output
 * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
 * @param baseSensorInfo general sensor information.
 * @param sclOutput Semantic Class labeling sensor output: representation of the current frame as captured by the Camera sensor POV
 *
 * use the Dispatch method to read the sensor data:
 * \code
         uint8_t* pixels = (uint8_t*)(&sclOutput.pixels()[0]);
         uint32_t channels = 4; // RGBA
         // process the data. for example: write it to file.
         writeBMPFile(sclOutput.width(), sclOutput.height(), channels, pixels); 
 \endcode
*/
    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const SemanticClassLabelingOutput &sclOutput) override;
    
    sensor_msgs::Image getRosMsg()
    {
        return mRosMsg;
    }

private:
    sensor_msgs::Image mRosMsg;
    EgoData *mEgoData = nullptr;
};

class OEM_SILProcessing : public SemanticInstanceLabeling
{
public:
    OEM_SILProcessing(EgoData *egoData, Eigen::Vector3f &gpsPos)
        : mEgoData(egoData)
    {
        mEgoData->mGPSPosition = gpsPos;
    }

    /*!
         * Main method for handling Semantic Instance labeling sensor output
         * @param baseInfo general information regarding the simulation: frame number, simulation time in seconds, end of simulation flag, etc.
         * @param baseSensorInfo general sensor information.
         * @param silOutput Semantic Instance labeling sensor output: representation of the current frame as captured by the Camera sensor POV
         *
         * use the Dispatch method to read the sensor data:
         * \code
                    uint8_t* pixels = (uint8_t*)(&silOutput.pixels()[0]);
                    uint32_t channels = 4; // RGBA
                    // process the data. for example: write it to file.
                    writeBMPFile(silOutput.width(), silOutput.height(), channels, pixels);

          \endcode
         */

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const SemanticInstanceLabelingOutput &silOutput) override;
    
    sensor_msgs::Image getRosMsg()
    {
        return mRosMsg;
    }

private:
    sensor_msgs::Image mRosMsg;
    EgoData *mEgoData = nullptr;
};

class OEM_LoadingHandler : public LoadingStateCallback
{
public:
    virtual void NewState(LoadingStateReport::stateType newState)
    {
        // place your code here
        // ---------------------
        // This method is invoked at each simulation loading states.

        ROS_INFO("Loading State: %s", LoadingStateReport_stateType_Name(newState).c_str());
    }
};

// global sensors
class OEM_DOGTProcessing : public DynamicObjectGT
{
public:
    OEM_DOGTProcessing(const EgoData *egoData)
        : m_EgoData(egoData)
    {
    }

    void Dispatch(const EngineToClientMessage &baseInfo, 
                  const SensorOutput &baseSensorInfo, 
                  const DynamicObjectGroundTruthOutput &dogtOutput) override;

    cognata_sdk::DOGTOutput getDogtRosMsg()
    {
        return mDogtRosMsg;
    }

private:
    const EgoData *m_EgoData;

    bool mfirstProcess = true;
    Eigen::Vector3f mEgoBeginningPos;
    float mEgoBeginningHdg;
    cognata_sdk::DOGTOutput mDogtRosMsg;
};


struct Quaternion
{
    double w, x, y, z;

    Quaternion(double yaw, double pitch, double roll) // yaw (Z), pitch (Y), roll (X)
    {
        // Abbreviations for the various angular functions
        double cy = cos(yaw * 0.5);
        double sy = sin(yaw * 0.5);
        double cp = cos(pitch * 0.5);
        double sp = sin(pitch * 0.5);
        double cr = cos(roll * 0.5);
        double sr = sin(roll * 0.5);

        w = cr * cp * cy + sr * sp * sy;
        x = sr * cp * cy - cr * sp * sy;
        y = cr* sp * cy + sr * cp * sy;
        z = cr * cp * sy - sr * sp * cy;
    }
};


#endif // __COGNATASENSORS_H__
