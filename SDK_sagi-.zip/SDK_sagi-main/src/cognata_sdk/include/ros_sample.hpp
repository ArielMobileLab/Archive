//
// sample.h - sample application that use cognata simulation engine SDK
//
// Copyright Cognata Ltd. (c) 2018 - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
// Proprietary and confidential

#ifndef __COGNATASAMPLE_H__
#define __COGNATASAMPLE_H__

// ROS Topic definition
#define RGB_CAMERA_TOPIC "/cognataSDK/image/raw"
#define INSTANCE_SEGMENTATION_TOPIC "/cognataSDK/image/instance_segmentation"
#define CLASS_SEGMENTATION_TOPIC "/cognataSDK/image/class_segmentation"
#define DCH_CAMERA_TOPIC "/cognataSDK/image/depth_dch"
#define DCS_CAMERA_TOPIC "/cognataSDK/image/depth_dcs"
#define LIDAR_TOPIC "/cognataSDK/lidar/points"
#define GPS_INFO "/cognataSDK/GPS/info"
#define GPS_IMU "/cognataSDK/GPS/imu"
#define TELEMETRY_TOPIC "/cognataSDK/telemetry/info"
#define RADAR_TOPIC "/cognataSDK/radar/info"
#define DRIVER_CMD_TOPIC "/cognataSDK/car_command/driver_cmd"
#define GAS_CMD_TOPIC "/cognataSDK/car_command/gas_cmd"
#define BRAKE_CMD_TOPIC "/cognataSDK/car_command/brake_cmd"
#define STEER_CMD_TOPIC "/cognataSDK/car_command/steer_cmd"
#define ACCELERATION_CMD_TOPIC "/cognataSDK/car_command/acceleration_cmd"
//ROS ROI
#define ROI_TOPIC "/cognataSDK/roi"
#define DOGT_TOPIC "/cognataSDK/dogt"

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>

#include <CognataSim.h> // SDK
#include <MathUtils.h>

#include <ros/ros.h> // ROS
#include <std_msgs/Int8.h>
#include <std_msgs/Float32.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud2.h>

#include "keyPress.hpp" // simple keyboard handling for windows and Linux
#include "sensors.hpp"

class OEM_GPSProcessing;
class OEM_ROIProcessing;
class OEM_LidarProcessing;
class OEM_RadarProcessing;
class OEM_RGBCameraProcessing;
class OEM_DchCameraProcessing;
class OEM_DcsCameraProcessing;
class OEM_E2CCProcessing;
class OEM_LaneDetectorProcessing;

class OEM_DOGTProcessing;
class ClosestTarget;
class EgoData;

#define ERROR_MSG(msg)\
{\
    cerr << msg;\
}

#define IMPORTANT_MSG(msg)\
{\
    cout << msg;\
}

#define VERBOSE_MSG(msg)\
if (mVerbose)\
{\
    cout << msg;\
}

#define THROW_IF_ERR(msg,returnCode)\
if (mErr != COGNATA_ERR_OK)\
{\
    ERROR_MSG(msg << " Return code: " << CognataErr_Name(mErr) << endl);\
    throw returnCode;\
}

enum SampleErrorCode
{
    WRONG_NUMBER_OF_ARGUMENTS = 1,
    SERVER_CONNECTION_FAILED,
    QUERY_LOADING_SCENE_FAILED,
    QUERY_ENGINE_VERSION_FAILED,
    QUERY_TERRAIN_FAILED,
    QUERY_CARS_INFO_FAILED,
    QUERY_MOVING_OBJECTS_INFO_FAILED,
    QUERY_SENSORS_FAILED,
    QUERY_GLOBAL_SENSORS_FAILD,
    REGISTER_ROI_FAILED,
    REGISTER_Radar_FAILED,
    REGISTER_GPS_FAILED,
    REGISTER_LIDAR_FAILED,
    REGISTER_RGB_FAILED,
    REGISTER_DEPTHCAM_FAILED,
    REGISTER_SCL_FAILED,
    REGISTER_SIL_FAILED,
    REGISTER_E2C_FAILED,
    REGISTER_DOGT_FAILED,
    REGISTER_LANE_DETECTOR_FAILED,
    REGISTER_CAR_TELEMETRIES_FAILED,
    SET_CONFIGURATION_FAILED,
    SET_SENSOR_PARAM_FAILED,
    START_SIMULATION_FAILED,
    QUERY_SIMULATION_RUNNING_FAILED,
    ADVANCE_FRAMES_DISCONNECTED,
    ADVANCE_FRAMES_FAILED,
    DISPATCH_MESSAGES_FAILED,
    LOG_CAR_COMMAND_FAILED,
    DISCONNECT_FAILED,
    SEND_MANUAL_DRIVER_FAILED,
    SEND_PARTIAL_MANUAL_DRIVER_FAILED,
    SEND_AI_DRIVER_FAILED,
    QUERY_SIMULATION_TIME_FAILED,
    QUERY_SIMULATION_FRAME_FAILED,
    INVALID_ARGUMENTS
};

enum DrivingCommandParts
{
    UNDEFINED = 1,
    UNSUPPORTED = 2,
    GAS_CMD = 3,
    BRAKES_CMD = 4,
    STEERING_CMD = 5,
    ACCELERATION_CMD = 6
};

const std::string usageString =
R"foo(
usage: CognataSample <IP> <Port> [--ai]
                    [--physics-step <miliseconds>] [--render-fps <fps>]
                    [--wakeup-every-steps <steps>]
                    [--silent]
                    [--optimize-rendering]
The arguments' description is as follows:

    <IP>                                    - Simulation host IP address
    <Port>                                  - Simulation host port
    --ai                                    - Sets simulation to drive autonomously
    --physics-step          <miliseconds>   - Sets simulation physics step to 'milliseconds'
    --render-fps            <fps>           - Sets simulation render FPS to 'fps'
    --wakeup-every-steps   <steps>          - Sets simulation wakeup rate to 'steps'
    --silent                                - Sets CognataSample output mode to silent
    --optimize-rendering                    - Sets RGB features off between desired FPS rendering
)foo";

/*! \brief sample code demonstrating how to use the SDK to connect to Cognata's SimCloud
*	Steps needed when to connect to the simulation:
*
*	-# \ref createSimulation "Create the CognataSim object."
*	-# \ref connectToSimulation "Connect to the SimCloud server."
*   -# Optionally, you can now:
*      -# \ref queryTerrain "Query SimCloud for terrain info"
*      -# \ref queryAllCarsInitalInformation "Query SimCloud for initial information for the different vehicles"
*      -# \ref queryAllMovingObjectsInitialInformation "Query SimCloud for information about moving objects in the scene"
*      -# \ref queryEgoCarSensors "Query SimCloud for the sensors equipped on the Ego car"
*	-# \ref registerSensors "Register Sensor output handlers."
*	-# \ref configureSimulation "Configure the SimCloud simulation."
*	-# \ref startSimulation "Start the SimCloud simulation."
*	-# \ref sampleMainLoop "The SimCloud simulation main loop."
*      -# as part of the main loop \ref sendNewCommands "calculate desired ego behavior and send to SimCloud"
*	-# \ref disconnect "Disconnect from the SimCloud simulation."
*/

typedef std_msgs::Float32 Float32Msg;
typedef std_msgs::Float32Ptr Float32MsgPtr;
typedef std_msgs::Int8 Int8Msg;
typedef std_msgs::Int8Ptr Int8MsgPtr;

class SampleCode
{
public:
    SampleCode();
    ~SampleCode();

/*! \brief Run the sample code application
*
* this function will run through all the different SDK calls needed to connect to the
* simulation engine and run it properly.
*
* When using this call make sure that you pass the two mandatory parameters.
* - IP - IP Address of the SimCloud server you are connecting to.
* - Port - IP Port of the SimCloud Server you are connecting to.
 * other optional parameters:
* -  \--ai -  Optional. Sets simulation to drive autonomously
* -  \--physics-step \<miliseconds\> - Optional. Physics step to 'milliseconds'
* -  \--render-fps            \<fps\>           - Optional.  Sets simulation render FPS to 'fps'
* -  \--wakeup-every-steps   \<steps\>          - Optional. Sets simulation wakeup rate to 'steps'
* -  \--silent                                - Optional. Sets CognataSample output mode to silent
* -  \--optimize-rendering                    - Optional. Sets RGB features off between desired FPS rendering
* -  \--SAVE_SENSOR_FILES                     - Optional. Saves sensor data to disk (Lidar and RGB camera)
*/
    void run(int argc, char **argv);

private:
    void rosInitialize(ros::NodeHandle &nh);
    void rosPublish();
    ///
    /*!
     * \if SHOW_SOME_PRIVATE_FUNCS
* \brief Sample code for creating the CognataSim object.
*
* This function handles creating the CognataSim simulation Object and then using it to connect to the SimCloud server.
* Since the CognataSim object is the main API access point to the simulation, you will most likely need to keep as member data.
* After creating the CognataSim object, create an LoadingState object and use it to register
* \endif
*/
    void createSimulation();
    void showUsage();
    bool isValidArgumentValue(int argc, char** argv, int argNameIdx);
    void parseCommandLineParameters(int argc, char **argv);
    /// \cond SHOW_SOME_PRIVATE_FUNCS
    /*!
	* \brief connect to the SimCloud server
	*
	* Once the \ref Cognata::SDK::CognataSim "CognataSim" object was created, use it to connect to the SimCloud server:
	* \code
	* // Connection string of the format "<IP Address> <Port Number>.
	* std::string conString = "127.0.01 1234";
	* CognataErr mErr = mSim->connectToEngine(mConnectionString);
	* \endcode
    * see \ref Cognata::SDK::CognataSim::connectToEngine "CognataSim::connectToEngine" for possible return values for connection attempt;
	*/
    void connectToSimulation();
/// \endcond
    /*!
 * \brief wait for the simulation engine to finish loading the scene
 *
 * After a connection to the SimCloud server was established, and depending on the simulation scene size,
 * it might be necessary to wait for the simulation to finish loading the scene:
 * \code
 *
 * bool isloading = true;
 * CognataErr mErr = mSim->isLoadingScene(isloading);
 * if(mErr == QUERY_LOADING_SCENE_FAILED)
 * {
 *      cerr << "Problem occurred while loading the simulation!";
 * }
 * \endcode
 *
 */
    void waitForSimulationToLoad();
    void queryEngineVersion();
/*!
 * \brief query SimCloud for terrain information
 *
 * After a connection to the SimCloud server was established, you can query SimCloud for the name of the terrain used
 * by the simulation:
 * \code
 *  std::string terrainName;
    CognataErr mErr = mSim->getTerrain(terrainName);
    \endcode
 */
    void queryTerrain();
/*!
 * \brief query SimCloud for vehicle information
 *
 * After a connection to the SimCloud server was established, you can query SimCloud for information on the different
 * vehicles participating in the simulation:
 * \code
 * std::vector<CarQueryReport> carsList;
 * CognataErr mErr = mSim->getCarsInfo(carsList);
   \endcode
 * The vehicle information returned  from the call is stored in <a href="./CognataSimMessages.html#Cognata.SDK.CarQueryReport">CarQueryReport</a> objects
 */
    void queryAllCarsInitalInformation();
/*!
 * \brief query SimCloud for moving object information
 * After a connection to the SimCloud server was established, you can query SimCloud for information on the different
 * moving objects used by the simulation:
 * \code
 * std::vector<MovingObjectQueryReport> movingObjectsList;
 * CognataErr mErr = mSim->getMovingObjectInfo(movingObjectsList);
   \endcode
 * The moving object information returned from the call is stored in <a href="./CognataSimMessages.html#Cognata.SDK.MovingObjectQueryReport ">MovingObjectQueryReport</a> objects
 */
    void queryAllMovingObjectsInitialInformation();
    /*!
 * \brief query SimCloud for Ego car sensor information
 * After a connection to the SimCloud server was established, you can query SimCloud for information on the different
 * sensors equipped on the Ego car used by the simulation:
 * \code
 * std::vector<SensorQueryReport> sensorsList;
 * CognataErr mErr = mSim->getSensorsInfo(sensorsList);
   \endcode
 * The Ego car's sensor information retruned from the call is stored in <a href="./CognataSimMessages.html#Cognata.SDK.SensorQueryReport">SensorQueryReport </a> objects
 */
    void queryEgoCarSensors();
    void queryGlobalSensors();
    void modifyDOGTParams();
/// \cond SHOW_SOME_PRIVATE_FUNCS
/*!
 * \brief registers Ego car sensor processing handlers
 *
 * In order to handle the output of the different sensors (both Ego sensors and global sensors, it is necessary to
 * register sensor handlers. this is done by extending the \ref Cognata::SDK::Sensor "Sensor" class.
 *
 * Several such message handlers are defined in the example code for your convenience. some of them include
 * \ref OEM_GPSProcessing "The GPS sensor handler" and \ref OEM_LidarProcessing "The Lidar sensor handler"
 *
 * Sensor Handler registration is performed in the following manner:
 * \code
 * EgoData* egoData = new EgoData();
 * OEM_LidarProcessing* myLidarProcessor =  new OEM_LidarProcessing(egoData, mGPSPosition);
 * CognataErr mErr = mSim->registerSensor<LidarOutput>(EgoCarNumber, (uint32_t)mLidarID, *myLidarProcessor);
 * \endcode
 *
 * Note: the mGPSPosition (Position of the Sensor) and the mLidarID (unique identifier of the sensor) can be extracted
 * from the \ref queryEgoCarSensors "queryEgoCarSensors" call.
 *
  */
    void registerSensors();
    void registerGlobalSensors();
/*!
 * \brief configure SimCloud FPS, physical simulation step, and other aspects of the SimCloud simulation
 *
 * Once you have connected to the SimCloud simulation you can configure different SimCloud aspects:
 * \code
 * // create the configuration command and step configuration objects
 * ConfigurationCommand *configurationCommand = new ConfigurationCommand();
 * TimeStepConfig *timeStepConfig = new TimeStepConfig();
 *
 * // configure fps
 * unsigned int fps = 30;
 * timeStepConfig->set_fps(fps);
 * // configure physical step
 * float step = 30.0f/1000.0f;
 * timeStepConfig->set_fixeddeltatime(step);
 * // set timestep config and send the configuration
 * configurationCommand->set_allocated_timestepconfig(timeStepConfig);
 * CognataErr mErr = mSim->setConfiguration(configurationCommand);
  * \endcode
  *
  * It is also possible to configure when the client wakes up (defined in simulation steps), and more.
 */
    void configureSimulation();

/**
 * set Configure Versions of SDK and OEM versions
 *!
 * \brief query SimCloud for terrain information
 *
 * After a connection to the SimCloud server was established, you can query SimCloud for the name of the terrain used
 * by the simulation:
 * \code
 *  std::string terrainName;
    CognataErr mErr = mSim->setVersionCommand(terrainName);
    \endcode
 */

    void setConfigureVersions();

    void startSimulation();
    void printSampleMenu();
    void initSimEngineCarDriver();
    
/// \cond SHOW_SOME_PRIVATE_FUNCS
    /*!
 * \brief example simulation loop
 *
 * Once you started the simulation you should enter the main loop. The main loop should handle a few things:
 *  - check if the simulation is still running.
 *  - if so, advaance to next frame and block the application while we wait for the next frame message from SimCloud
 *  - dispatch registered message handlers
 *  - do end of frame actions
 *  - calculate your new state and send new Commands to SimCloud for the next simulation step.
 *
 * \code
 *     bool isRunnning = true;
    while (isRunnning)
    {
        CognataErr error = COGNATA_ERR_OK;
        // check if we are still running.
        error = mSim->isRunning(isRunnning);
        // advance the frame and block until a message is received.
        error = mSim->advanceFramesAndBlockForMessages(mMessageTimeoutInSec); // thread blocking call
        // activate all messages received in frame by calling the Dispatch method in each connected data processor
        error = mSim->dispatchMessages();
        sendNewCommands();
    }
 * \endcode
 *
 * Note: to keep things simple no error handling is done in the code above. are made in this code.
 * you should definitely check for errors in a real world application.

 */
    void sampleMainLoop();
/// \cond SHOW_SOME_PRIVATE_FUNCS
    /*!
 * \brief send new commands to the SimCloud simulation.
 *
 * Once the simulation is in the main loop you should process the sensor output and derive new commands for the Ego
 * car.
 * \code
 * // control the ego car command and add new car configuration command
 * CarCommand* pCarCommand = new CarCommand();
 * CarConfiguration* pCarConfiguration = new CarConfiguration();
 * // in a real life application the gas, brake and steering values would be calculated by processing sensor output.
 * float gas = 1.0f;
 * float brake = 0.0f;
 * float steering = 0.0f;
 *
 * pCarCommand->set_id(EgoCarNumber);
 * pCarConfiguration->set_gas(gas);
 * pCarConfiguration->set_brake(brake);
 * pCarConfiguration->set_steering(steering);
 *
 * pCarCommand->set_allocated_drive(pCarConfiguration);
 * mErr = mSim->carControlCmd(pCarCommand);
 * \endcode
 *
 */
    void sendNewCommands();
/*!
* \brief disconnect from the SimCloud server
*
* Disconnect from the SimCloud server once you have finished working it:
* \code
* CongnataErr error = mSim->disconnectFromEngine();
* \endcode
*/
    void disconnect();
    void processKeypress();
    void getSimulationParams();

private:
    // CallBacks functions
    void carGasCMDCallback(const Float32Msg &msg);
    void carBrakeCMDCallback(const Float32Msg &msg);
    void carSteerCMDCallback(const Float32Msg &msg);
    void carAccelerationCMDCallback(const Float32Msg &msg);
    void carDriverCallback(const Int8Msg &msg);
    
	void increaseAcceleration();
    void decreaseAcceleration();
    void recalcAcceleration();
    void publishCarControlCommand(DrivingCommandParts cmd_type);

    // Subscribers
    ros::Subscriber mCarDriver_sub;
    ros::Subscriber mCarGasCMD_sub;
    ros::Subscriber mCarBrakeCMD_sub;
    ros::Subscriber mCarSteerCMD_sub;
    ros::Subscriber mCarAccelerationCMD_sub;
    
    // Publishers
    ros::Publisher  mCarDriver_pub,
                    mCarGasCMD_pub,
                    mCarBrakeCMD_pub,
                    mCarSteerCMD_pub,
                    mCarAccelerationCMD_pub,
                    mRgbCamera_pub,
                    mLidar_pub,
                    mGps_infopub,
                    mGps_imupub,
                    mTelmetry_pub,
                    mRadar_pub,
                    mRoi_pub,
                    mDogt_pub,
                    mDchCamera_pub,
                    mDcsCamera_pub,
                    mInstanceSegmentation_pub,
                    mClassSegmentation_pub;

    CognataErr mErr = COGNATA_ERR_OK;
    // Constants for run
    float mMessageTimeoutInSec = 300.0f;
    std::unique_ptr<CognataSim> mSim = nullptr;
    
    bool mClientEgoCarUseAI = true;
    bool mServerEgoCarUseAI = true;
    
    bool mOptimizeRendering = true;
    bool mGPS = false;
    
    std::string mConnectionString;

    Eigen::Vector3f mGPSPosition;

    int mGpsID = -1;
    int mRgbCameraID = -1;
    int mRgbCameraID2 = -1;
    int mDchCameraID = -1;
    int mDcsCameraID = -1;
    int mLidarID = -1;
    int mE2CID = -1;
    int mSCLID = -1;
    int mSILID = -1;
    int mROIID = -1;
    int mRadarID = -1;

    std::set<int> mLaneDetectorIDs;
    int mCarTelemetriesID = -1;

    OEM_GPSProcessing* mMyGPSProcessing = nullptr;
    OEM_ROIProcessing* mMyROIProcessing = nullptr;
    OEM_RadarProcessing* mMyRadarProcessing = nullptr;
    OEM_LidarProcessing* mMyLidarProcessing = nullptr;
    OEM_RGBCameraProcessing* mMyRGBCameraProcessing = nullptr;
    OEM_SILProcessing* mInstanceSegmentationProcessing = nullptr;
    OEM_SCLProcessing* mClassSegmentationProcessing = nullptr;
    OEM_DchCameraProcessing* mMyDchCameraProcessing = nullptr;
    OEM_DcsCameraProcessing* mMyDcsCameraProcessing = nullptr;
    OEM_E2CCProcessing* mMyE2CProcessing = nullptr;
    OEM_LaneDetectorProcessing* mMyLDProcessing = nullptr;
    OEM_CarTelemetriesProcessing* mMyTelemetriesProcessing = nullptr;


    // global sensors
    int mDogtID = -1;

    OEM_DOGTProcessing *mMyDOGTProcessing = nullptr;

    bool mIsRunning = false;

    int mKeyPressed = -1;
    bool mPause = false; // a sample global variable. Not part of the SDK.

    int mPhysicsStep = 30;
    int mRenderFPS = 30;
    int mWakeupEverySteps = 2;

    bool mVerbose = true;

    float mDt = 0.0f;
    float mLastTime = 0;

    ClosestTarget* mClosestTarget = nullptr;

    EgoData* mEgoData = nullptr;

    //Vehicle control variables - Client (publisher) side :
    float mClientSteering = 0.0f;
    float mClientGas = 1.0f;
    float mClientBrake = 0.0f;
	float mClientAcceleration = mClientGas - mClientBrake;

    //Vehicle control variables - Server (subscriber) side :
    float mSrvSteering = 0.0f;
    float mSrvGas = 1.0f;
    float mSrvBrake = 0.0f;
	float mSrvAcceleration = mSrvGas - mSrvBrake;

    const float kGasStep = 0.05f;
    const float kGasMax = 1.0f;
    const float kGasMin = 0.0f;
    const float kBrakeStep = 0.05f;
    const float kBrakeMax = 1.0f;
    const float kBrakeMin = 0.0f;
    const float kSteeringStep = 0.01f;
    const float kSteeringMax = 1.0f;
    const float kSteeringMin = -1.0f;
};

#endif // __COGNATASAMPLE_H__
