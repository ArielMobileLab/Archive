//
// main.cpp - sample application that use cognata simulation engine SDK
//
// Copyright Cognata Ltd. (c) 2018 - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
// Proprietary and confidential


#include <ros/ros.h>
#include <std_msgs/String.h>
#include "ros_sample.hpp"

int main(int argc, char **argv)
{
    /// Verify that the version of the library that we linked against is
    /// compatible with the version of the headers we compiled against.
    GOOGLE_PROTOBUF_VERIFY_VERSION;

    int result = 0;

    try
    {
        SampleCode sampleCode;
        sampleCode.run(argc, argv);
    }
    catch (SampleErrorCode e)
    {
        ERROR_MSG("Sample code finished with error code: " << e << endl);
        result = e;
    }

    return result;
}
