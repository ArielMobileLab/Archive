//
// sensors.cpp - sample application that use cognata simulation engine SDK
//
// Copyright Cognata Ltd. (c) 2018 - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
// Proprietary and confidential

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>
#include <algorithm> // max, reverse

#include <CognataSim.h>

#include "keyPress.hpp" // simple keyboard handling for windows and Linux
#include "sensors.hpp"

using namespace std;

//ROS utility functions
template <class RosMsg>
static inline void ROSInputHeader(RosMsg& msg, 
                                  const EngineToClientMessage &baseInfo, 
                                  const SensorOutput &baseSensorInfo, 
                                  const string& frameId);

template <class RosVector>
static inline void ROSConvertVector(RosVector& rvec, const SDKVector3& sdkvec);

static void ObjToRos(cognata_sdk::ObjectDescription& rosobj, 
                     const ObjectDescription& obj);
static void ROSCopyVehicleInfo(cognata_sdk::VehicleMsg& vehicle, 
                               const ObjectDescription& obj);
static void ROSCopyTLInfo(cognata_sdk::TrafficLightMsg& traffic_light, 
                          const ObjectDescription& obj);

std::vector<uint8_t> FlipImage(const char *start, const char* end, 
                               size_t width, size_t channelNum);

void OEM_ROIProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                 const SensorOutput &baseSensorInfo, 
                                 const ROIOutput &roiOutput)
{
    mClosestTarget->isValid = false;
    mClosestTarget->DistLgt = 100000000; // TODO max value
    if (mfirstProcess == true)
    {
        mfirstProcess = false;
        mEgoBeginningPos = mEgoData->mPosition;
        mEgoBeginningHdg = mEgoData->heading;
    }

    //Clearing
    mRoiRosMsg.pedestrianList.clear();
    mRoiRosMsg.othertList.clear();
    mRoiRosMsg.vehicleList.clear();
    mRoiRosMsg.annotationList.clear();
    mRoiRosMsg.trafficLightList.clear();

    ROSInputHeader(mRoiRosMsg, baseInfo, baseSensorInfo, "/map");

    for (int i = 0; i < roiOutput.objectslist_size(); i++)
    {
        ObjectDescription obj = roiOutput.objectslist(i);
        switch(obj.ObjectType_case())
        {
            case ObjectDescription::ObjectTypeCase::kPedestrian :
            {
                cognata_sdk::PedestrianMsg ped;
                ROSInputHeader(ped, baseInfo, baseSensorInfo, "/map");
                ObjToRos(ped.description, obj);
                //pedestrian specific variables
                ROSConvertVector(ped.pedestrian_velocity, obj.pedestrian().velocity());                
                //push into main ROI msg
                mRoiRosMsg.pedestrianList.push_back(ped);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kAnnotation :
            {
                cognata_sdk::AnnotationMsg anno;
                ROSInputHeader(anno, baseInfo, baseSensorInfo, "/map");
                ObjToRos(anno.description, obj);
                //annotation specific variables
                ROSConvertVector(anno.localTransform.translation, 
                                  obj.annotation().localtransform().position());
                ROSConvertVector(anno.localTransform.rotation, 
                                  obj.annotation().localtransform().rotation());
                //push into main ROI msg
                mRoiRosMsg.annotationList.push_back(anno);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kVehicle :
            {
                cognata_sdk::VehicleMsg vehicle;
                ROSInputHeader(vehicle, baseInfo, baseSensorInfo, "/map");
                ObjToRos(vehicle.description, obj);
                //vehicle specific variables
                ROSCopyVehicleInfo(vehicle, obj);
                //push into main ROI msg
                mRoiRosMsg.vehicleList.push_back(vehicle);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kTrafficLight :
            {
                cognata_sdk::TrafficLightMsg trafLight;
                ROSInputHeader(trafLight, baseInfo, baseSensorInfo, "/map");
                ObjToRos(trafLight.description, obj);
                //annotation specific variables
                ROSCopyTLInfo(trafLight, obj);
                //push into main ROI msg
                mRoiRosMsg.trafficLightList.push_back(trafLight);
                break;
            }
            default :
            {
                cognata_sdk::ObjectDescription other;
                ROSInputHeader(other, baseInfo, baseSensorInfo, "/map");
                ObjToRos(other, obj);

                //push into main ROI msg
                mRoiRosMsg.othertList.push_back(other);
            }
        }
    }
}


void OEM_GPSProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                 const SensorOutput &baseSensorInfo, 
                                 const GPSOutput &gpsOutput)
{
    // place your code here
    // ---------------------
    // This sample class received GPS sensor messages
    Eigen::Vector3f pos = SDKVecToVector3f(gpsOutput.position());
    // update ego data from GPS
    mEgoData->heading = gpsOutput.orientation().z();
    mEgoData->speed = gpsOutput.speed();

    Eigen::Vector3f rotatedGPSPos = transformPointByRotationDegree(
             mEgoData->mGPSPosition, SDKVecToVector3f(gpsOutput.orientation())
             );
    mEgoData->mPosition = pos - rotatedGPSPos;
    mEgoData->mAccelerationLocal = SDKVecToVector3f(gpsOutput.acceleration());
    mEgoData->mAngularAccelerationLocal = 
                       SDKVecToVector3f(gpsOutput.angularaccelerationlocal3d());
    mEgoData->mVelocityLocal = SDKVecToVector3f(gpsOutput.velocitylocal3d());
    mEgoData->mAngularVelocityLocal = 
                           SDKVecToVector3f(gpsOutput.angularvelocitylocal3d());

    mEgoData->initialized = true;

    ROSInputHeader(mRosGPSMsg, baseInfo, baseSensorInfo, "/map");
    ROSInputHeader(mRosIMUMsg, baseInfo, baseSensorInfo, "/map");

    // GPS
    mRosGPSMsg.status.status = 0;  // Navigation Satellite fix status for any Global Navigation Satellite System - see NavSatStatus.h, 0 = unaugmented fix
    mRosGPSMsg.status.service = 1; // Bits defining which Global Navigation Satellite System signals were used by the receiver.  - see NavSatStatus.h, 1 - GPS
    mRosGPSMsg.latitude = gpsOutput.lat();
    //mRosGPSMsg.longitude = gpsOutput.long_();
    mRosGPSMsg.longitude = gpsOutput.speed();
    // --- Removed for Cheeting Lane Detection ---
    // mRosGPSMsg.position_covariance_type = 2; // 2 - Diaganol Known
    // ---------------------------------------------
    mRosGPSMsg.position_covariance_type = -gpsOutput.lanenumber();
    
    // IMU
    Quaternion q = Quaternion(gpsOutput.orientation().x(), 
                              gpsOutput.orientation().y(), 
                              gpsOutput.orientation().z());
    mRosIMUMsg.orientation.w = q.w;
    mRosIMUMsg.orientation.x = q.x;
    mRosIMUMsg.orientation.y = q.y;
    mRosIMUMsg.orientation.z = q.z;
    ROSConvertVector(mRosIMUMsg.angular_velocity, gpsOutput.angularvelocitylocal3d());
    ROSConvertVector(mRosIMUMsg.linear_acceleration, gpsOutput.acceleration());
}

void OEM_RadarProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                   const SensorOutput &baseSensorInfo, 
                                   const RadarOutput &radarOutput)
{
    // place your code here
    // ---------------------
    // This sample class received Radar sensor messages

    mRosMsg.targets.clear();
    //Header
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    //RadarOutputHeader
    mRosMsg.radarId = std::to_string(baseSensorInfo.outputsensorid());
    ROSConvertVector(mRosMsg.radarPlacement.linear, 
                     radarOutput.header().radarplacement().location());
    ROSConvertVector(mRosMsg.radarPlacement.angular, 
                     radarOutput.header().radarplacement().orientation());

    mRosMsg.hFov = radarOutput.header().horizontalfov();
    mRosMsg.vFov = radarOutput.header().verticalfov();

    //RadarOutputTarget
    for (int i = 0; i < radarOutput.targets_size(); i++)
    {
        RadarOutput_Target target = radarOutput.targets().Get(i);
        cognata_sdk::RadarOutputTarget data;
        ROSInputHeader(data, baseInfo, baseSensorInfo, "/map");
        data.id = target.id();
        data.timeStamp = target.timestamp();
        data.range = target.range();
        data.azimuth = target.azimuth();
        data.elevation = target.elevation();
        data.rangeRate = target.rangerate();
        data.amplitude = target.amplitude();
        data.isAggregate = target.geometrictarget().isaggregate();
        data.trackingStatus = target.radartarget().trackingstatus();
        data.age = target.radartarget().age();
        data.lastSeen = target.radartarget().lastseen();
        data.isStationary = target.radartarget().isstationary();
        data.isGhost = target.radartarget().isghost();

        mRosMsg.targets.push_back(data);
    }
}

void OEM_LidarProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                   const SensorOutput &baseSensorInfo, 
                                   const LidarOutput &lidarOutput)
{
    // place your code here
    // ---------------------
    // This sample class received Lidar sensor messages
    
    // Headers & static info - could probably be inited elsewhere
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");

    mRosMsg.is_dense = true;
    mRosMsg.height = 1;                                                                             // Height
    mRosMsg.point_step = (uint8_t)(3 * sizeof(float) + 
                                   2 * sizeof(u_int8_t) + 
                                       sizeof(u_int16_t));                                          // Step
    mRosMsg.width = lidarOutput.points().length() / 
                                          (mRosMsg.point_step * mRosMsg.height);                    // Width
    mRosMsg.row_step = (uint32_t)(mRosMsg.point_step * mRosMsg.width);                              // Row Step
    
    mRosMsg.fields.resize(6);                                                                       // Field definition
    mRosMsg.fields[0].name = "x";
    mRosMsg.fields[0].offset = 0;
    mRosMsg.fields[0].datatype = sensor_msgs::PointField::FLOAT32;
    mRosMsg.fields[0].count = 1;
    mRosMsg.fields[1].name = "y";
    mRosMsg.fields[1].offset = mRosMsg.fields[0].offset + (uint32_t)sizeof(float);
    mRosMsg.fields[1].datatype = sensor_msgs::PointField::FLOAT32;
    mRosMsg.fields[1].count = 1;
    mRosMsg.fields[2].name = "z";
    mRosMsg.fields[2].offset = mRosMsg.fields[1].offset + (uint32_t)sizeof(float);
    mRosMsg.fields[2].datatype = sensor_msgs::PointField::FLOAT32;
    mRosMsg.fields[2].count = 1;
    mRosMsg.fields[3].name = "delta_time_uint16";
    mRosMsg.fields[3].offset = mRosMsg.fields[2].offset + (uint32_t)sizeof(float);
    mRosMsg.fields[3].datatype = sensor_msgs::PointField::UINT16;
    mRosMsg.fields[3].count = 1;
    mRosMsg.fields[4].name = "lidar_identifier";
    mRosMsg.fields[4].offset = mRosMsg.fields[3].offset + (uint32_t)sizeof(uint16_t);
    mRosMsg.fields[4].datatype = sensor_msgs::PointField::UINT8;
    mRosMsg.fields[4].count = 1;
    mRosMsg.fields[5].name = "intensity";
    mRosMsg.fields[5].offset = mRosMsg.fields[4].offset + (uint32_t)sizeof(uint8_t);
    mRosMsg.fields[5].datatype = sensor_msgs::PointField::UINT8;
    mRosMsg.fields[5].count = 1;
    mRosMsg.data.resize(lidarOutput.points().length());
    memcpy(&mRosMsg.data[0], &lidarOutput.points()[0], lidarOutput.points().length());
    // mRosMsg.data.resize(mRosMsg.point_step * lidarOutput.points().length());
    // mRosMsg.data = std::vector<uint8_t>(&lidarOutput.points()[0], &lidarOutput.points()[0] + lidarOutput.points().length());
}

static std::vector<uint8_t> FlipImage(const char *start, const char* reader)
{
    std::vector<uint8_t> to_ret;
    while (reader >= start)
    {
        to_ret.push_back(*(reader-3));
        to_ret.push_back(*(reader-2));
        to_ret.push_back(*(reader-1));
        to_ret.push_back(*(reader));
        reader -= 4;
    }

    return to_ret;
}

void OEM_RGBCameraProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                       const SensorOutput &baseSensorInfo, 
                                       const RGBCameraOutput &rgbCameraOutput)
{
    // place your code here
    // ---------------------
    // This sample class received RGB sensor messages
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    mRosMsg.width = rgbCameraOutput.width();                                                   // Width
    mRosMsg.height = rgbCameraOutput.height();                                                 // Height
    mRosMsg.encoding = "rgba8";                                                                // Cognata RGBA to ROS BGRA
    mRosMsg.step = mRosMsg.width * 4;                                                          // No. of channels

    mRosMsg.data = FlipImage(rgbCameraOutput.pixels().data(),
                             rgbCameraOutput.pixels().data() + 
                             mRosMsg.step * mRosMsg.height - 1, 
                             mRosMsg.width, 4);
}


void OEM_DchCameraProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                       const SensorOutput &baseSensorInfo, 
                                       const DepthCameraOutput &depthCameraOutput)
{
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    mRosMsg.width = depthCameraOutput.width();                                                  // Width
    mRosMsg.height = depthCameraOutput.height();                                                // Height
    mRosMsg.encoding = "mono16";                                                                // Cognata RGBA to ROS BGRA
    mRosMsg.step = mRosMsg.width * 2;                                                           // No. of channels
    mRosMsg.data.resize(mRosMsg.step * mRosMsg.height);
    size_t sizeInFloats = depthCameraOutput.pixels().size() / 4;
    
    uint16_t *mDepth_Pixels = (uint16_t*)&mRosMsg.data[0];
    float *floatPixels = (float*)(depthCameraOutput.pixels().data());

    for (size_t i = 0 ; i < sizeInFloats ; ++i)
    {
        mDepth_Pixels[i] = static_cast<uint16_t>(floatPixels[i]);
    }
}

void OEM_DcsCameraProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                       const SensorOutput &baseSensorInfo, 
                                       const DepthCameraOutput &depthCameraOutput)
{
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    mRosMsg.width = depthCameraOutput.width();                                                  // Width
    mRosMsg.height = depthCameraOutput.height();                                                // Height
    mRosMsg.encoding = "mono16";                                                                // Cognata RGBA to ROS BGRA
    mRosMsg.step = mRosMsg.width * 2;                                                           // No. of channels
    mRosMsg.data.resize(mRosMsg.step * mRosMsg.height);
    size_t sizeInUint16 = depthCameraOutput.pixels().size() / 2;

    const uint16_t* pixels = (const uint16_t*)(depthCameraOutput.pixels().data());
    uint16_t *mDepth_Pixels = (uint16_t*)&mRosMsg.data[0];

    for (size_t i = 0 ; i < sizeInUint16 ; ++i)
    {
        mDepth_Pixels[i] = pixels[i];
        mDepth_Pixels[i] = mDepth_Pixels[i] * 1000/65536;
    }
}

void OEM_E2CCProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                  const SensorOutput &baseSensorInfo, 
                                  const E2COutput &e2COutput)
{
    // place your code here
    // ---------------------
    // This sample class received E2C sensor messages
}

void OEM_LaneDetectorProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                          const SensorOutput &baseSensorInfo, 
                                          const LaneDetectorOutput &ldOutput)
{
    // place your code here
    // ---------------------
    // This sample class receives lane detection data
}

void OEM_DOGTProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                  const SensorOutput &baseSensorInfo, 
                                  const DynamicObjectGroundTruthOutput &dogtOutput)
{
    // place your code here
    // ---------------------
    // This sample class received Dynamic Object GT sensor messages

    if (mfirstProcess == true)
    {
        mfirstProcess = false;
        mEgoBeginningPos = m_EgoData->mPosition;
        mEgoBeginningHdg = m_EgoData->heading;
    }

    //Clearing
    mDogtRosMsg.trafficLightList.clear();
    mDogtRosMsg.pedestrianList.clear();
    mDogtRosMsg.vehicleList.clear();
    mDogtRosMsg.annotationList.clear();
    mDogtRosMsg.othertList.clear();

    ROSInputHeader(mDogtRosMsg, baseInfo, baseSensorInfo, "/map");
    
    for (int i = 0; i < dogtOutput.objects_size(); i++)
    {
        ObjectDescription obj = dogtOutput.objects(i);
        switch(obj.ObjectType_case()) //TODO: replace with factory
        {
            case ObjectDescription::ObjectTypeCase::kPedestrian :
            {
                cognata_sdk::PedestrianMsg ped;
                ROSInputHeader(ped, baseInfo, baseSensorInfo, "/map");
                ObjToRos(ped.description, obj);
                //pedestrian specific variables
                ROSConvertVector(ped.pedestrian_velocity, obj.pedestrian().velocity());
                //push into main ROI msg
                mDogtRosMsg.pedestrianList.push_back(ped);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kAnnotation :
            {
                cognata_sdk::AnnotationMsg anno;
                ROSInputHeader(anno, baseInfo, baseSensorInfo, "/map");
                ObjToRos(anno.description, obj);
                //annotation specific variables
                ROSConvertVector(anno.localTransform.translation, 
                                  obj.annotation().localtransform().position());
                ROSConvertVector(anno.localTransform.rotation, 
                                  obj.annotation().localtransform().rotation());
                //push into main ROI msg
                mDogtRosMsg.annotationList.push_back(anno);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kVehicle :
            {
                cognata_sdk::VehicleMsg vehicle;
                ROSInputHeader(vehicle, baseInfo, baseSensorInfo, "/map");
                ObjToRos(vehicle.description, obj);
                //vehicle specific variables
                ROSCopyVehicleInfo(vehicle, obj);
                //push into main ROI msg
                mDogtRosMsg.vehicleList.push_back(vehicle);
                break;
            }
            case ObjectDescription::ObjectTypeCase::kTrafficLight :
            {
                cognata_sdk::TrafficLightMsg trafLight;
                ROSInputHeader(trafLight, baseInfo, baseSensorInfo, "/map");
                ObjToRos(trafLight.description, obj);
                //annotation specific variables
                ROSCopyTLInfo(trafLight, obj);
                //push into main ROI msg
                mDogtRosMsg.trafficLightList.push_back(trafLight);
                break;
            }
            default :
            {
                cognata_sdk::ObjectDescription other;
                ROSInputHeader(other, baseInfo, baseSensorInfo, "/map");
                ObjToRos(other, obj);

                //push into main ROI msg
                mDogtRosMsg.othertList.push_back(other);
            }
        }
    }
}

void OEM_CarTelemetriesProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                            const SensorOutput &baseSensorInfo, 
                                            const CarTelemetriesOutput &telemetriesOutput)
{
    mRosMsg.wheels.clear();

    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    
    mRosMsg.turnLight = CarConfiguration::SignalState_Name(telemetriesOutput.turnlight());
    mRosMsg.acceleration = telemetriesOutput.acceleration();
    mRosMsg.brake = telemetriesOutput.brake();
    mRosMsg.gas = telemetriesOutput.gas();
    mRosMsg.steering = telemetriesOutput.steering(); 

   

    ROSConvertVector(mRosMsg.centerOfMass.linear, 
                                 telemetriesOutput.centerofmasslocalposition());
    ROSConvertVector(mRosMsg.centerOfMass.angular, 
                                 telemetriesOutput.centerofmasslocalrotation());

    mRosMsg.engineRpm = telemetriesOutput.enginerpm();
    mRosMsg.engineLoad = telemetriesOutput.engineload();
    mRosMsg.engineTorque = telemetriesOutput.enginetorque();
    mRosMsg.enginePower = telemetriesOutput.enginepower();

    mRosMsg.currentGear = telemetriesOutput.currentgear();

    for (int i = 0; i < telemetriesOutput.wheels_size(); i++)
    {
        WheelTelemetriesOutput wheel = telemetriesOutput.wheels().Get(i);
        cognata_sdk::WheelTelemetries data;
        ROSInputHeader(data, baseInfo, baseSensorInfo, "/map");
        data.angularVelocity  = wheel.angularvelocity();
        data.steerAngle = wheel.steerangle();
        data.driveTorque = wheel.drivetorque();
        data.brakeTorque = wheel.braketorque();
        data.reactionTorque = wheel.reactiontorque();
        data.tireForce.x = wheel.tireforce().x();
        data.tireForce.y = wheel.tireforce().y();
        data.tireSlip.x = wheel.tireslip().x();
        data.tireSlip.y = wheel.tireslip().y();
        data.canSlip = wheel.canslip();
        data.combinedTireSlip = wheel.combinedtireslip();
        data.suspensionCompression = wheel.suspensioncompression();
        data.downForce = wheel.downforce();
        data.contactAngle = wheel.contactangle();
        data.contactDepth = wheel.contactdepth();
        data.contactSpeed = wheel.contactspeed();
        data.isGrounded = wheel.grounded();
        ROSConvertVector(data.wheelVelocity, wheel.wheelvelocity());

        mRosMsg.wheels.push_back(data);
    }
}

void OEM_SCLProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                 const SensorOutput &baseSensorInfo, 
                                 const SemanticClassLabelingOutput &sclOutput)
{
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    mRosMsg.width = sclOutput.width();                                                          // Width
    mRosMsg.height = sclOutput.height();                                                        // Height
    mRosMsg.encoding = "rgba8";                                                                 // Cognata RGBA to ROS BGRA
    mRosMsg.step = mRosMsg.width * 4;                                                           // No. of channels

    mRosMsg.data = FlipImage(sclOutput.pixels().data(),
                             sclOutput.pixels().data() + 
                             mRosMsg.step * mRosMsg.height - 1, 
                             mRosMsg.width, 4);
}

void OEM_SILProcessing::Dispatch(const EngineToClientMessage &baseInfo, 
                                 const SensorOutput &baseSensorInfo, 
                                 const SemanticInstanceLabelingOutput &silOutput)
{
    ROSInputHeader(mRosMsg, baseInfo, baseSensorInfo, "/map");
    mRosMsg.width = silOutput.width();                                                          // Width
    mRosMsg.height = silOutput.height();                                                        // Height
    mRosMsg.encoding = "rgba8";                                                                 // Cognata RGBA to ROS BGRA
    mRosMsg.step = mRosMsg.width * 4;                                                           // No. of channels

    mRosMsg.data = FlipImage(silOutput.pixels().data(),
                             silOutput.pixels().data() + 
                             mRosMsg.step * mRosMsg.height - 1, 
                             mRosMsg.width, 4);
}

//ROS utility functions - implementation
template <class RosMsg>
static inline void ROSInputHeader(RosMsg& msg, 
                                  const EngineToClientMessage &baseInfo, 
                                  const SensorOutput &baseSensorInfo, 
                                  const string& frameId)
{
    msg.header.frame_id = frameId;                                                          //ros frames not implemented yet
    msg.header.seq = baseSensorInfo.outputtime();                                           // Sensor Time
    msg.header.stamp.sec = baseInfo.simulationtimeinsec();                                  // Simulation Time
}

template <class RosVector>
static inline void ROSConvertVector(RosVector& rvec, const SDKVector3& sdkvec)
{
    rvec.x = sdkvec.x();
    rvec.y = sdkvec.y();
    rvec.z = sdkvec.z();
}

static void ObjToRos(cognata_sdk::ObjectDescription& rosobj, const ObjectDescription& obj)
{
    rosobj.objectId = obj.id();
    rosobj.ROIType = obj.roitype();
    rosobj.ROISubtype = obj.roisubtype();

    ROSConvertVector(rosobj.boundingBox.transform.translation, 
                                      obj.boundingbox().transform().position());
    ROSConvertVector(rosobj.boundingBox.transform.rotation, 
                                      obj.boundingbox().transform().rotation());

    rosobj.boundingBox.height = obj.boundingbox().height();
    rosobj.boundingBox.width = obj.boundingbox().width();
    rosobj.boundingBox.length = obj.boundingbox().length();

    if (obj.has_motion())
    {
        ROSConvertVector(rosobj.motion.linear, obj.motion().velocity());
        ROSConvertVector(rosobj.motion.angular, obj.motion().angularrates());
    }

    for (int o = 0; o < obj.sensorids_size(); o++)
    {
        rosobj.sensorIds.push_back(obj.sensorids(o));
    }
}

static void ROSCopyVehicleInfo(cognata_sdk::VehicleMsg& vehicle, const ObjectDescription& obj)
{
    vehicle.vehicleType = Vehicle_Type_Name(obj.vehicle().type());
    vehicle.vehicleRole = Vehicle_Role_Name(obj.vehicle().role());
    vehicle.navigationSegment = obj.vehicle().navigationsegment();
    vehicle.laneId = obj.vehicle().laneid();
    vehicle.lanesFromLeft = obj.vehicle().lanesfromleft();
    vehicle.headLightState = obj.vehicle().lightsstate().headlight();
    vehicle.brakeLightState = obj.vehicle().lightsstate().brake();
    vehicle.reverseLightState = obj.vehicle().lightsstate().reverse();
    vehicle.signalState = CarConfiguration::SignalState_Name(obj.vehicle().signalstate());
    vehicle.signalLight = CarConfiguration::SignalState_Name(obj.vehicle().signallight());

    for (int o = 0; o < obj.vehicle().wheels().size(); o++)
    {
        Wheel wheel = obj.vehicle().wheels(o);
        cognata_sdk::WheelMsg wheelRos;

        ROSConvertVector(wheelRos.relativePosition, wheel.relativeposition());
        wheelRos.steeringAngle = wheel.steeringangle();
        wheelRos.rotateAngle = wheel.rotateangle();
        wheelRos.name = wheel.name();
        
        vehicle.wheels.push_back(wheelRos);
    }
}

static void ROSCopyTLInfo(cognata_sdk::TrafficLightMsg& traffic_light, const ObjectDescription& obj)
{
    traffic_light.status = TrafficLight_Status_Name(obj.trafficlight().status());
    traffic_light.bulbStatus = obj.trafficlight().bulbstatus();
    traffic_light.functioningStatus = obj.trafficlight().functioningstatus();
    traffic_light.behaviour = obj.trafficlight().behaviour();
    traffic_light.trafficSignalStatus = obj.trafficlight().trafficsignalstatus();
    traffic_light.azimuthAngle = obj.trafficlight().azimuthangle();
    traffic_light.facing = obj.trafficlight().facing();
}

std::vector<uint8_t> FlipImage(const char *start, const char* end, size_t width, size_t channelNum)
{
    std::vector<uint8_t> toRet;
    
    while (start < end)
    {
        const char *chunkReader = end - (width * channelNum);
        
        while(chunkReader < end)
        {
            for(int i = (channelNum-1) ; i >= 0 ; --i)
            {
                toRet.push_back(*(chunkReader+i));    
            }
            
            chunkReader += channelNum;
        }
        
        end -= (width * channelNum);
    }

    return toRet;
}
