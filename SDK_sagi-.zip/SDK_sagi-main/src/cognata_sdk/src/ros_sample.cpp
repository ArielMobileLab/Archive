//
// ros_sample.cpp - sample application that use cognata simulation engine SDK
//
// Copyright Cognata Ltd. (c) 2018 - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// All trade-marks, trade names, service marks and logos referenced herein belong to their respective companies
// Proprietary and confidential

#include <thread>    // sleep
#include <algorithm> // max

#include <CognataSim.h> // SDK

#include "keyPress.hpp" // simple keyboard handling for windows and Linux
#include "ros_sample.hpp"

SampleCode::SampleCode()
{
}

SampleCode::~SampleCode()
{
    delete mMyGPSProcessing;
    delete mMyROIProcessing;
    delete mMyRadarProcessing;
    delete mMyLidarProcessing;
    delete mMyRGBCameraProcessing;
    delete mMyDchCameraProcessing;
    delete mMyDcsCameraProcessing;
    delete mMyE2CProcessing;
    delete mMyLDProcessing;
    delete mMyTelemetriesProcessing;
    delete mClosestTarget;
    delete mEgoData;
    delete mMyDOGTProcessing;
}

void SampleCode::run(int argc, char **argv)
{
    parseCommandLineParameters(argc, argv);
    
    // ROS Init
    ros::init(argc, argv, "node");
    ros::NodeHandle nh;             // declare ROS node handler
    ros::AsyncSpinner spinner(2);   // start spinner
    spinner.start();
    rosInitialize(nh);              // publisher init for sensor outpul & control subscriber

    createSimulation();
    connectToSimulation();
    waitForSimulationToLoad();
    setConfigureVersions();
    // Finished loading - Query the simulation before starting it - Optional
    // ---------------------------------------------------------------------
    queryEngineVersion();
    queryTerrain();
    queryAllCarsInitalInformation();
    queryAllMovingObjectsInitialInformation();
    queryGlobalSensors();

    queryEgoCarSensors();
    
    modifyDOGTParams();
    // Register Sensor Handlers
    // ------------------------
    if (mGPS)
    {
        ROS_INFO("Register GPS Sensor ");
        mMyGPSProcessing = new OEM_GPSProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<GPSOutput>(EgoCarNumber, GPSID, *mMyGPSProcessing);

        THROW_IF_ERR("registerSensor (GPS) Failed.", REGISTER_GPS_FAILED);
    }
    if (mRgbCameraID2 != -1)
    {
        ROS_INFO("Register RGBCamera Sensor ");
       mMyRGBCameraProcessing = new OEM_RGBCameraProcessing(mEgoData, mGPSPosition);
       mErr = mSim->registerSensor<RGBCameraOutput>(EgoCarNumber, (uint32_t)mRgbCameraID2, *mMyRGBCameraProcessing);

        THROW_IF_ERR("registerSensor (RGB Camera) Failed.", REGISTER_RGB_FAILED);
    }
    //registerSensors();
    registerGlobalSensors();

    // Configure Simulation
    // --------------------
    configureSimulation();

    // Start simulation
    // ----------------
    startSimulation();
    initKeyboard();
    printSampleMenu();
    initSimEngineCarDriver();

    // Main Loop
    //----------
    sampleMainLoop();

    // End of simulation
    // -----------------
    ros::shutdown(); // Close ROS , wait for ctrl-c
    disconnect();
}

void SampleCode::rosInitialize(ros::NodeHandle &nh)
{
    // Subscriber & Publisher for DRIVER commands :
    // A positive value is a flag for turning on the AI Driving. A negative is a flag for turning on the Manual (SDK) Driving.
    // Please note that this flag is only a sample for convenience. The Simulation Engine switches to manual driving when any 
    // car control driving command is recieved (gas, steering, brakes, acceleration).
    mCarDriver_sub = nh.subscribe(DRIVER_CMD_TOPIC, 1, &SampleCode::carDriverCallback, this);
    mCarDriver_pub = nh.advertise<Int8Msg>(DRIVER_CMD_TOPIC, 1);

    // Subscriber & Publisher for Car GAS commands. Gas valid values : [0..1]
    mCarGasCMD_sub = nh.subscribe(GAS_CMD_TOPIC, 1, &SampleCode::carGasCMDCallback, this);
    mCarGasCMD_pub = nh.advertise<Float32Msg>(GAS_CMD_TOPIC, 1);
    
    // Subscriber & Publisher for Car BRAKE commands. Braking valid values : [0..1] (regardless of gas)
    mCarBrakeCMD_sub = nh.subscribe(BRAKE_CMD_TOPIC, 1, &SampleCode::carBrakeCMDCallback, this);
    mCarBrakeCMD_pub = nh.advertise<Float32Msg>(BRAKE_CMD_TOPIC, 1);
    
    // Subscriber & Publisher for Car STEERING commands. Steering valid values : [-1..1]
    mCarSteerCMD_sub = nh.subscribe(STEER_CMD_TOPIC, 1, &SampleCode::carSteerCMDCallback, this);
    mCarSteerCMD_pub = nh.advertise<Float32Msg>(STEER_CMD_TOPIC, 1);
    
    // Subscriber & Publisher for Car ACCELERATION commands. Acceleration valid values : [-1..1].
    // This is in fact gas-brakes (gas_value minus brakes_value) and it overrides gas&brakes values in the 
    // Simulation Engine, as well as in this sample code.
    mCarAccelerationCMD_sub = nh.subscribe(ACCELERATION_CMD_TOPIC, 1, &SampleCode::carAccelerationCMDCallback, this);
    mCarAccelerationCMD_pub = nh.advertise<Float32Msg>(ACCELERATION_CMD_TOPIC, 1);


    //Ros topic definition for sensors:
    mRgbCamera_pub = nh.advertise<sensor_msgs::Image>(RGB_CAMERA_TOPIC, 10);
    mInstanceSegmentation_pub = nh.advertise<sensor_msgs::Image>(INSTANCE_SEGMENTATION_TOPIC, 10);
    mClassSegmentation_pub = nh.advertise<sensor_msgs::Image>(CLASS_SEGMENTATION_TOPIC, 10);
    mDchCamera_pub = nh.advertise<sensor_msgs::Image>(DCH_CAMERA_TOPIC, 10);
    mDcsCamera_pub = nh.advertise<sensor_msgs::Image>(DCS_CAMERA_TOPIC, 10);
    mLidar_pub = nh.advertise<sensor_msgs::PointCloud2>(LIDAR_TOPIC, 10);
    mGps_infopub = nh.advertise<sensor_msgs::NavSatFix>(GPS_INFO, 10);
    mGps_imupub = nh.advertise<sensor_msgs::Imu>(GPS_IMU, 10);
    mTelmetry_pub = nh.advertise<cognata_sdk::CarTelemetriesMsg>(TELEMETRY_TOPIC, 10);
    mRadar_pub = nh.advertise<cognata_sdk::RadarOutputHeader>(RADAR_TOPIC, 10);
    mRoi_pub = nh.advertise<cognata_sdk::ROIOutput>(ROI_TOPIC, 10);
    mDogt_pub = nh.advertise<cognata_sdk::DOGTOutput>(DOGT_TOPIC, 10);
}

void SampleCode::createSimulation()
{
    // Create simulation and connect to server
    mSim = std::make_unique<CognataSim>();
    ROS_INFO("Starting Cognata Simulation version: %s", mSim->getSDKVersion().c_str());

    mClosestTarget = new ClosestTarget();
    mEgoData = new EgoData();

    // register loading state (before connection)
    OEM_LoadingHandler *myLoadingStateHandler = new OEM_LoadingHandler();
    mSim->registerLoadingStateCallback(*myLoadingStateHandler);
}

void SampleCode::showUsage()
{
    IMPORTANT_MSG(usageString << std::endl);
}

bool SampleCode::isValidArgumentValue(int argc, char **argv, int argNameIdx)
{
    int argValueIdx = argNameIdx + 1;
    return ((argc > argValueIdx) &&
            (argv[argValueIdx][0] != '-'));
}

void SampleCode::parseCommandLineParameters(int argc, char **argv)
{
    // Note : By default the Simulation Engine starts with an AI driver, so regardless of the setting here
    // we would have to send a message to the Simulation Engine if we want to start in Manual/SDK Driver mode. 
    mServerEgoCarUseAI = false;
    mClientEgoCarUseAI = false;

    // parse command line parameters
    mOptimizeRendering = false;
    if (argc < 3)
    {
        ROS_ERROR("Wrong number of command line arguments");
        showUsage();
        throw WRONG_NUMBER_OF_ARGUMENTS;
    }

    //build connection string from arg's
    mConnectionString = argv[1];
    mConnectionString += " ";
    mConnectionString += argv[2];

    bool invalidArgs = false;
    for (int i = 3; i < argc; i++)
    {
        std::string arg = argv[i];

        if (arg.compare("--silent") == 0)
        {
            mVerbose = false;
        }

        if (arg.compare("--gps") == 0)
        {
            ROS_INFO("Using gps command");

            mGPS = true;
        }

        if (arg.compare("--optimize-rendering") == 0)
        {
            ROS_INFO("Using optimize-rendering command");

            mOptimizeRendering = true;
        }

        if (arg.compare("--ai") == 0)
        {	// Note :  this is the default Simulation Engine's state.
            ROS_INFO("Ego car driving with AI Driver");
            mServerEgoCarUseAI = true;
            mClientEgoCarUseAI = true;
        }

        if (arg.compare("--physics-step") == 0)
        {
            if (!isValidArgumentValue(argc, argv, i))
            {
                invalidArgs = true;
                break;
            }
            mPhysicsStep = std::stoi(argv[i + 1]);
            if (mPhysicsStep <= 0)
            {
                invalidArgs = true;
                break;
            }
        }

        if (arg.compare("--render-fps") == 0)
        {
            if (!isValidArgumentValue(argc, argv, i))
            {
                invalidArgs = true;
                break;
            }

            mRenderFPS = std::stoi(argv[i + 1]);
            if (mRenderFPS <= 0)
            {
                invalidArgs = true;
                break;
            }
        }

        if (arg.compare("--wakeup-every-steps") == 0)
        {
            if (!isValidArgumentValue(argc, argv, i))
            {
                invalidArgs = true;
                break;
            }
            mWakeupEverySteps = std::stoi(argv[i + 1]);
            if (mWakeupEverySteps <= 0)
            {
                invalidArgs = true;
                break;
            }
        }
    }

    if (invalidArgs)
    {
        ROS_ERROR("Invalid arguments!");
        showUsage();
        throw INVALID_ARGUMENTS;
    }

    ROS_INFO("Connection String: %s", mConnectionString.c_str());
}

void SampleCode::connectToSimulation()
{
    // Connect to simulation
    // -----------------------------------------------------------
    mErr = COGNATA_ERR_CONNECTION_FAILED;
    ROS_INFO("Connecting to engine");

    while (mErr != COGNATA_ERR_OK)
    {
        mErr = mSim->connectToEngine(mConnectionString);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    THROW_IF_ERR("Failed to connect to server.", SERVER_CONNECTION_FAILED);

    ROS_INFO("Connected to engine");
}

void SampleCode::waitForSimulationToLoad()
{
    // wait for loading to finish
    // --------------------------
    ROS_INFO("Loading Scene");
    bool isloading = true;

    while (isloading)
    {
        mErr = mSim->isLoadingScene(isloading);
        THROW_IF_ERR("isLoadingScene Failed.", QUERY_LOADING_SCENE_FAILED);
    }

    ROS_INFO("Loading Finished");
}

void SampleCode::queryEngineVersion()
{
    // Engine version
    std::string versions;
    ROS_INFO("Get Engine Version");

    mErr = mSim->getEngineVersion(versions);

    THROW_IF_ERR("Failed to get Engine version", QUERY_ENGINE_VERSION_FAILED);

    ROS_INFO("Cognata Engine version: %s", versions.c_str());
}

void SampleCode::queryTerrain()
{
    // Terrain
    std::string terrainName;
    ROS_INFO("Get Terrain");
    mErr = mSim->getTerrain(terrainName);

    THROW_IF_ERR("Failed to get Terrain", QUERY_TERRAIN_FAILED);

    ROS_INFO("Terrain: %s", terrainName.c_str());
}

void SampleCode::queryAllCarsInitalInformation()
{
    std::vector<CarQueryReport> carsList;
    ROS_INFO("Get cars");

    mErr = mSim->getCarsInfo(carsList);
    THROW_IF_ERR("getCarInfo Failed.", QUERY_CARS_INFO_FAILED);

    for (auto car : carsList)
    {
        ROS_INFO("=========================");
        ROS_INFO("Car:");
        ROS_INFO("Name = %s", car.name().c_str());
        ROS_INFO("Brand = %s", car.brand().c_str());
        SDKVector3 velocity = car.velocity();
        ROS_INFO("Velocity = %f, %f, %f", velocity.x(), velocity.y(), velocity.z());
        SDKVector3 acceleration = car.acceleration();
        ROS_INFO("Acceleration = %f, %f, %f", acceleration.x(), acceleration.y(), acceleration.z());
        ROS_INFO("ROI Object Id = %d", car.roiobjectid());
        SDKBoundingBox carBB = car.boundingbox();
        SDKVector3 position = carBB.transform().position();
        ROS_INFO("Position = %f, %f, %f", position.x(), position.y(), position.z());
        SDKVector3 rotation = carBB.transform().rotation();
        ROS_INFO("Rotation = %f, %f, %f", rotation.x(), rotation.y(), rotation.z());
        ROS_INFO("height = %f", carBB.height());
        ROS_INFO("width = %f", carBB.width());
        ROS_INFO("length = %f", carBB.length());
        ROS_INFO("lane id = %d", car.locationparams().laneid());
        ROS_INFO("Politeness = %f", car.behaviourparams().politeness());
        ROS_INFO("SafetyTime = %f", car.behaviourparams().safetytime());
        ROS_INFO("Comfortable Braking = %f", car.behaviourparams().comfortablebraking());
        ROS_INFO("Desired Speed = %f", car.behaviourparams().desiredspeed());
        ROS_INFO("Desired Interval = %f", car.behaviourparams().desiredinterval());
        ROS_INFO("=========================");
    }
}

void SampleCode::queryAllMovingObjectsInitialInformation()
{
    std::vector<MovingObjectQueryReport> movingObjectsList;
    ROS_INFO("Get MovingObjects");

    mErr = mSim->getMovingObjectInfo(movingObjectsList);
    if (mErr != COGNATA_ERR_OK)
    {
        ROS_ERROR("getMovingObjectInfo Failed. Return code: %s", CognataErr_Name(mErr).c_str());
    }
    else
    {
        for (auto obj : movingObjectsList)
        {
            ROS_INFO("=========================");
            ROS_INFO("Moving Obj:");
            ROS_INFO("Name = %s", obj.name().c_str());
            ROS_INFO("Brand = %s", obj.brand().c_str());
            ROS_INFO("ROI Object Id = %d", obj.roiobjectid());
            SDKBoundingBox objBB = obj.boundingbox();
            SDKVector3 position = objBB.transform().position();
            ROS_INFO("Position = %f, %f, %f", position.x(), position.y(), position.z());
            SDKVector3 rotation = objBB.transform().rotation();
            ROS_INFO("Rotation = %f, %f, %f", rotation.x(), rotation.y(), rotation.z());
            ROS_INFO("height = %f", objBB.height());
            ROS_INFO("width = %f", objBB.width());
            ROS_INFO("length = %f", objBB.length());
            ROS_INFO("lane id = %d", obj.locationparams().laneid());
            int num_of_path_points = obj.path().waypoints_size();
            ROS_INFO("Number of waypoints: %d (X,Y)", num_of_path_points);
            for (int i = 0; i < num_of_path_points; ++i)
            {
                ROS_INFO("waypoint %d (%f , %f)", i, obj.path().waypoints(i).x(), obj.path().waypoints(i).y());
            }
            ROS_INFO("=========================");
        }
    }
}
void SampleCode ::queryGlobalSensors()
{
    std::vector<GlobalSensorQueryReport> globalSensorsList;
    ROS_INFO("Get Global sensors");
    mErr = mSim->getGlobalSensors(globalSensorsList);
    THROW_IF_ERR("getGlobalSensors", QUERY_GLOBAL_SENSORS_FAILD);

    mDogtID = -1;
    // go over all global sensors and print their params
    for (auto sensor : globalSensorsList)
    {
        ROS_INFO("=========================");
        ROS_INFO("Sensor:");
        ROS_INFO("Name = %s", sensor.name().c_str());
        ROS_INFO("ID = %d", sensor.sensorid());
        ROS_INFO("FPS = %d", sensor.fps());

        switch (sensor.QueryType_case())
        {

        case GlobalSensorQueryReport::kDOGTReport:
        {
            if (mDogtID == -1)
            {
                // save first DOGT ID
                mDogtID = (int)sensor.sensorid();
            }

            ROS_INFO("Found DOGT Sensor at id: %d", mDogtID);
            break;
        }

        default:
            break;
        }

        ROS_INFO("=========================");
    }
}

void SampleCode::queryEgoCarSensors()
{
    // query ego car sensors
    std::vector<SensorQueryReport> sensorsList;
    ROS_INFO("Get sensors");
    mErr = mSim->getSensorsInfo(sensorsList);
    THROW_IF_ERR("getSensorInfo Failed", QUERY_SENSORS_FAILED);

    // go over all sensors and print thier names
    mGpsID = -1;
    mRgbCameraID = -1;
    mRgbCameraID2 = -1;
    mDchCameraID = -1;
    mDcsCameraID = -1;
    mLidarID = -1;
    mE2CID = -1;
    mSCLID = -1;
    mSILID = -1;
    mRadarID = -1;
    mLaneDetectorIDs.clear();

    for (auto sensor : sensorsList)
    {
        ROS_INFO("=========================");
        ROS_INFO("Sensor:");
        ROS_INFO("Name = %s", sensor.name().c_str());
        SDKVector3 position = sensor.transform().position();
        ROS_INFO("Position = %f, %f, %f", position.x(), position.y(), position.z());
        SDKVector3 rotation = sensor.transform().rotation();
        ROS_INFO("Rotation(Roll, Pitch, Yaw) = %f, %f, %f", rotation.x(), rotation.y(), rotation.z());

        switch (sensor.QueryType_case())
        {
        case SensorQueryReport::kRoiReport:
        {
            ROS_INFO("*** ROI sensor Position is irrelevant ***");
            if (mROIID == -1)
            {
                mROIID = (int)sensor.sensorid();
            }
            break;
        }

        case SensorQueryReport::kGpsReport:
        {
            if (mGpsID == -1)
            {
                // save first GPS ID
                mGpsID = (int)sensor.sensorid();
            }

            mGPSPosition[0] = position.x();
            mGPSPosition[1] = position.y();
            mGPSPosition[2] = position.z();
            ROS_INFO("Found GPS Sensor at id: %d", mGpsID);
            break;
        }

        case SensorQueryReport::kRgbCameraReport:
        {
            if (mRgbCameraID == -1)
            {
                // save first RGB Camera ID
                mRgbCameraID = (int)sensor.sensorid();
            }
            else if (mRgbCameraID2 == -1)
            {
                mRgbCameraID2 = (int)sensor.sensorid();
            }

            RGBCameraConfig rgbConfig = sensor.rgbcamerareport();
            ROS_INFO("Camera Width: %d", rgbConfig.width());
            ROS_INFO("Camera height: %d", rgbConfig.height());
            ROS_INFO("Horizontal FOV: %f", rgbConfig.hfov());
            ROS_INFO("Vertical FOV: %f", rgbConfig.vfov());
            break;
        }

        case SensorQueryReport::kRadarReport:
        {
            if (mRadarID == -1)
            {
                // save first Lidar ID
                mRadarID = (int)sensor.sensorid();
            }
            break;
        }

        case SensorQueryReport::kDepthCameraReport:
        {
            DepthCameraConfig depthConfig = sensor.depthcamerareport();

            if (depthConfig.dcdatatype() == 0)
            {
                mDchCameraID = (int)sensor.sensorid();
            }
            else
            {
                mDcsCameraID = (int)sensor.sensorid();
            }

            ROS_INFO("Camera Width: %d", depthConfig.width());
            ROS_INFO("Camera height: %d", depthConfig.height());
            ROS_INFO("Horizontal FOV: %f", depthConfig.hfov());
            ROS_INFO("Vertical FOV: %f", depthConfig.vfov());
            ROS_INFO("DC Data Type: %d", depthConfig.dcdatatype());
            break;
        }
        case SensorQueryReport::kLidarReport:
        {
            if (mLidarID == -1)
            {
                // save first Lidar ID
                mLidarID = (int)sensor.sensorid();
            }
            break;
        }
        case SensorQueryReport::kSlClassReport:
        {
            if (mSCLID == -1)
            {
                // save first SCL ID
                mSCLID = (int)sensor.sensorid();

                //ROS_INFO("Found SL Class Sensor at id: %d", mSCLID);
            }

            break;
        }

        case SensorQueryReport::kSlInstanceReport:
        {
            if (mSILID == -1)
            {
                // save first SIL ID
                mSILID = (int)sensor.sensorid();

                //ROS_INFO("Found SL Instance Sensor at id: %d", mSILID);
            }

            break;
        }
        case SensorQueryReport::kE2CReport:
        {
            if (mE2CID == -1)
            {
                // save first E2C ID
                mE2CID = (int)sensor.sensorid();
            }
            break;
        }

        case SensorQueryReport::kLaneDetectorReport:
        {
            mLaneDetectorIDs.insert((int)sensor.sensorid());
            break;
        }

        case SensorQueryReport::kCarTelemetriesReportFieldNumber:
        {
            if (mCarTelemetriesID == -1)
            {
                // save first car telemetry ID
                mCarTelemetriesID = (int)sensor.sensorid();
            }
            break;
        }

        default:
            break;
        }
        ROS_INFO("=========================");
    }

    // if the engine reqested ROI with no GPS, alert the user that it is not possible and do not register the ROI sensor
    if (mROIID != -1 && mGpsID == -1)
    {
        ROS_ERROR("ROI Sensor cannot be used without a GPS Sensor. ROI Sensor will be turned off");
        mROIID = -1;
    }
}
/// \endcond

void SampleCode::modifyDOGTParams()
{
    // modify dynamic object GT params
    if (mDogtID >= 0)
    {
        VERBOSE_MSG("Modify Dynamic Object GT" << std::endl);
        DOGTModifiable *pDOGTModifiable = new DOGTModifiable();
        pDOGTModifiable->set_fps(27);
        pDOGTModifiable->set_record(true);
        mErr = mSim->setSensorParam<DOGTModifiable>((uint32_t)mDogtID, pDOGTModifiable);

        THROW_IF_ERR("setSensorParam (Dynamic Object GT) Failed.", SET_SENSOR_PARAM_FAILED);
    }
}


void SampleCode::registerSensors()
{
    // Register Sensors
    // -----------------------------------------------------------
    // Register your Sensor Handlers here
    if (mROIID != -1)
    {
        ROS_INFO("Register ROI Sensor ");
        mMyROIProcessing = new OEM_ROIProcessing(mClosestTarget, mEgoData);

        // Connecting the Region of interest reports
        mErr = mSim->registerSensor<ROIOutput>(EgoCarNumber, ROIID, *mMyROIProcessing);

        THROW_IF_ERR("registerSensor (ROI) Failed.", REGISTER_ROI_FAILED);
    }

    if (mGpsID != -1)
    {
        ROS_INFO("Register GPS Sensor ");
        mMyGPSProcessing = new OEM_GPSProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<GPSOutput>(EgoCarNumber, GPSID, *mMyGPSProcessing);

        THROW_IF_ERR("registerSensor (GPS) Failed.", REGISTER_GPS_FAILED);
    }

    if (mLidarID != -1)
    {
        ROS_INFO("Register Lidar Sensor ");
        mMyLidarProcessing = new OEM_LidarProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<LidarOutput>(EgoCarNumber, (uint32_t)mLidarID, *mMyLidarProcessing);

        THROW_IF_ERR("registerSensor (Lidar) Failed.", REGISTER_LIDAR_FAILED);
    }

    if (mRgbCameraID != -1)
    {
        ROS_INFO("Register RGBCamera Sensor ");
        mMyRGBCameraProcessing = new OEM_RGBCameraProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<RGBCameraOutput>(EgoCarNumber, (uint32_t)mRgbCameraID, *mMyRGBCameraProcessing);

        if (mRgbCameraID2 != -1)
        {
            mErr = mSim->registerSensor<RGBCameraOutput>(EgoCarNumber, (uint32_t)mRgbCameraID2, *mMyRGBCameraProcessing);
        }

        THROW_IF_ERR("registerSensor (RGB Camera) Failed.", REGISTER_RGB_FAILED);
    }

    if (mDchCameraID != -1)
    {
        ROS_INFO("Register DepthCamers Sensor ");
        mMyDchCameraProcessing = new OEM_DchCameraProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<DepthCameraOutput>(EgoCarNumber, (uint32_t)mDchCameraID, *mMyDchCameraProcessing);

        THROW_IF_ERR("registerSensor (Depth Camera) Failed.", REGISTER_DEPTHCAM_FAILED);
    }

    if (mDcsCameraID != -1)
    {
        ROS_INFO("Register DepthCamers Sensor ");
        mMyDcsCameraProcessing = new OEM_DcsCameraProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<DepthCameraOutput>(EgoCarNumber, (uint32_t)mDcsCameraID, *mMyDcsCameraProcessing);

        THROW_IF_ERR("registerSensor (Depth Camera) Failed.", REGISTER_DEPTHCAM_FAILED);
    }

    if (mRadarID != -1)
    {
        ROS_INFO("Register Radar Sensor ");
        mMyRadarProcessing = new OEM_RadarProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<RadarOutput>(EgoCarNumber, (uint32_t)mRadarID, *mMyRadarProcessing);

        THROW_IF_ERR("registerSensor (Radar) Failed.", REGISTER_Radar_FAILED);
    }

    if (mE2CID != -1)
    {
        ROS_INFO("Register E2C Sensor ");
        mMyE2CProcessing = new OEM_E2CCProcessing();
        mErr = mSim->registerSensor<E2COutput>(EgoCarNumber, (uint32_t)mE2CID, *mMyE2CProcessing);

        THROW_IF_ERR("registerSensor (E2C) Failed.", REGISTER_E2C_FAILED);
    }

    if (mLaneDetectorIDs.empty() == false)
    {
        ROS_INFO("Register LaneDetector sensors ");
        mMyLDProcessing = new OEM_LaneDetectorProcessing(mEgoData);

        for (auto it = mLaneDetectorIDs.cbegin(); it != mLaneDetectorIDs.cend(); ++it)
        {
            mErr = mSim->registerSensor<LaneDetectorOutput>(EgoCarNumber, (uint32_t)*it, *mMyLDProcessing);
            THROW_IF_ERR("registerSensor (LaneDetector) Failed.", REGISTER_LANE_DETECTOR_FAILED);
        }
    }

    if (mCarTelemetriesID != -1)
    {
        ROS_INFO("Register Car Telemetries sensor ");
        mMyTelemetriesProcessing = new OEM_CarTelemetriesProcessing();
        mErr = mSim->registerSensor<CarTelemetriesOutput>(EgoCarNumber, (uint32_t)mCarTelemetriesID, *mMyTelemetriesProcessing);

        THROW_IF_ERR("registerSensor (Car Telemetries) Failed.", REGISTER_CAR_TELEMETRIES_FAILED);
    }

    if (mSCLID != -1)
    {
        ROS_INFO("Register Semantic Class Labeling Sensor ");
        mClassSegmentationProcessing = new OEM_SCLProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<SemanticClassLabelingOutput>(EgoCarNumber, (uint32_t)mSCLID, *mClassSegmentationProcessing);
        if (mErr != COGNATA_ERR_OK)
        {
            ROS_ERROR("registerSensor (SCL) Failed. Return code: %s", CognataErr_Name(mErr).c_str());
            throw REGISTER_SCL_FAILED;
        }
    }

    if (mSILID != -1)
    {
        ROS_INFO("Register Semantic Instance Labeling Sensor ");
        mInstanceSegmentationProcessing = new OEM_SILProcessing(mEgoData, mGPSPosition);
        mErr = mSim->registerSensor<SemanticInstanceLabelingOutput>(EgoCarNumber, (uint32_t)mSILID, *mInstanceSegmentationProcessing);
        if (mErr != COGNATA_ERR_OK)
        {
            ROS_ERROR("registerSensor (SIL) Failed. Return code: %s", CognataErr_Name(mErr).c_str());
            throw REGISTER_SIL_FAILED;
        }
    }
}

void SampleCode::registerGlobalSensors()
{
    // Place your code here:
    // --------------------
    // Register your Global Sensor Handlers

    ROS_INFO("Register DOGT Sensor ");
    mMyDOGTProcessing = new OEM_DOGTProcessing(mEgoData);

    // Connecting the Dynamic Object Ground Truth reports
    mErr = mSim->registerSensor<DynamicObjectGroundTruthOutput>(DOGTID, *mMyDOGTProcessing);

    THROW_IF_ERR("registerSensor (DOGT) Failed.", REGISTER_DOGT_FAILED);
}

void SampleCode::configureSimulation()
{
    // Place your code here:
    // --------------------
    // Change the following code if you want to configure the simulation

    // set configuration parameters
    ConfigurationCommand *configurationCommand = new ConfigurationCommand();

    // time step configuration
    TimeStepConfig *timeStepConfig = new TimeStepConfig();

    configurationCommand->set_optimizerendering(mOptimizeRendering);

    if (mPhysicsStep >= 0)
    {
        timeStepConfig->set_fixeddeltatime((float)(mPhysicsStep) / 1000.0f);
        ROS_INFO("Fixed Delta Time: %f", timeStepConfig->fixeddeltatime());
    }
    else
    {
        ROS_ERROR("Invalid Fixed Delta Time: %d. Unexpected results.", mPhysicsStep);
    }

    if (mRenderFPS > 0)
    {
        timeStepConfig->set_fps((uint32_t)mRenderFPS);
        ROS_INFO("FPS: %d", timeStepConfig->fps());
    }
    else
    {
        ROS_ERROR("Invalid FPS: %d. Unexpected results.", mRenderFPS);
    }

    if (mWakeupEverySteps >= 0)
    {
        timeStepConfig->set_wakeupeverysteps((float)mWakeupEverySteps);
        ROS_INFO("Wakeup Every Steps: %f", timeStepConfig->wakeupeverysteps());
    }
    else
    {
        ROS_ERROR("Invalid Wakeup Every Steps: %d. Unexpected results.", mWakeupEverySteps);
    }
    configurationCommand->set_allocated_timestepconfig(timeStepConfig);

    // set configuration
    mErr = mSim->setConfiguration(configurationCommand);

    THROW_IF_ERR("setConfiguration Failed.", SET_CONFIGURATION_FAILED);
}

void SampleCode::setConfigureVersions()
{
    VersionCommand *pVersionCommand = new VersionCommand();
    pVersionCommand->set_sdkversion(mSim->getSDKVersion());
    pVersionCommand->set_oemversion("sampleOemVersion");

    mErr = mSim->setVersionCommand(pVersionCommand);

    THROW_IF_ERR("setConfigureVersions Failed.", SET_CONFIGURATION_FAILED);
}

void SampleCode::startSimulation()
{
    // Start the simulation (in blocking mode)
    // ---------------------------------------

    ROS_INFO("Starting simulation (blocking)");

    mErr = mSim->start(BLOCKING);

    THROW_IF_ERR("Failed to start simulation.", START_SIMULATION_FAILED);
}

void SampleCode::printSampleMenu()
{
    // Sample code menu
    if (mServerEgoCarUseAI == true)
    {
        ROS_INFO("Using Engine AI");
    }
	else
	{
        ROS_INFO("Using SDK driving");
	}

    if (mOptimizeRendering == true)
    {
        ROS_INFO("Using Optimize Rendering");
    }

    ROS_INFO("-----------------");
    ROS_INFO("Keyboard commands:");
    ROS_INFO("-----------------");

    ROS_INFO("'1' - Increase Gas");
    ROS_INFO("'2' - Decrease Gas ");
    ROS_INFO("'3' - Increase Brake ");
    ROS_INFO("'4' - Increase Brake ");
    ROS_INFO("'W' - Increase Acceleration / Decrease Brake");
    ROS_INFO("'S' - Decrease Acceleration / Increase Brake");
    ROS_INFO("'A' - Turn Left");
    ROS_INFO("'D' - Turn Right");

    ROS_INFO("'P' - Pause/Resume simulation");
    ROS_INFO("'M' - Enable Manual Driving. Disables Engine AI driving");
    ROS_INFO("'N' - Enable Using Engine AI. Disables Manual driving");

    ROS_INFO("'Q' - Exit the simulation");
}

void SampleCode::initSimEngineCarDriver()
{
    // By default the Simulation Engine starts with an AI driver.
    // If we want to START the simulation with Manual/SDK driving we need to trigger it by sending ANY driving command.
    if (mServerEgoCarUseAI == false)
    {
        mErr = mSim->sendCarControlAccelerationCmd(EgoCarNumber,mSrvGas - mSrvBrake);
        THROW_IF_ERR("Send manual driver failed for partial message.", SEND_PARTIAL_MANUAL_DRIVER_FAILED);
        ROS_INFO("Initializing Sim Engine driver to Manual / SDK driving.");
    }
    else
    {
        // do nothing.
    }
}

void SampleCode::sampleMainLoop()
{
    // main Simulation loop - thread blocking
    // -----------------------------------------------------------
    mIsRunning = true;

    while (mIsRunning)
    {
        mKeyPressed = -1;

        mErr = mSim->isRunning(mIsRunning);

        THROW_IF_ERR("isRunning failed.", QUERY_SIMULATION_RUNNING_FAILED);

        if (mPause == false)
        {
            // By calling advanceFramesAndBlockForMessages the OEM framework:
            // 1) Signals ready for next sensor frames to Simulation
            // 2) Activates SDK data listening loop;
            // 3) Blocks the thread until a message is received
            // 4) Advance to next frame
            mErr = mSim->advanceFramesAndBlockForMessages(mMessageTimeoutInSec); // thread blocking call

            if (mErr == COGNATA_ERR_DISCONNECTED)
            {
                ROS_FATAL("advanceFramesAndBlockForMessages disconnected. Return code: %s", CognataErr_Name(mErr).c_str());
                throw ADVANCE_FRAMES_DISCONNECTED;
            }

            THROW_IF_ERR("advanceFramesAndBlockForMessages failed.", ADVANCE_FRAMES_FAILED);

            // get data and place it in sensor class member
            mErr = mSim->dispatchMessages();

            THROW_IF_ERR("dispatchMessages failed.", DISPATCH_MESSAGES_FAILED);

            // Place your code here:
            // ---------------------
            // Publish data to topics
            rosPublish();
        }

        // Based on sensor data processing send new commands to simulated ego car
        // Send car commands to control the vehicle
        // ----------------------------------------------------------------------
        // Place your code here:
        // ---------------------
        // Here you generate new ego car commands based on Sensor Fusion and Policy
        sendNewCommands();
    }
}

void SampleCode::rosPublish()
{
    if (mMyRGBCameraProcessing != nullptr)
    {
        mRgbCamera_pub.publish(mMyRGBCameraProcessing->getRosMsg());
    }
    
    if (mInstanceSegmentationProcessing != nullptr)
    {
        mInstanceSegmentation_pub.publish(mInstanceSegmentationProcessing->getRosMsg());
    }

    if (mClassSegmentationProcessing != nullptr)
    {
        mClassSegmentation_pub.publish(mClassSegmentationProcessing->getRosMsg());
    }

    if (mMyDchCameraProcessing != nullptr)
    {
        mDchCamera_pub.publish(mMyDchCameraProcessing->getRosMsg());
    }

    if (mMyDcsCameraProcessing != nullptr)
    {
        mDcsCamera_pub.publish(mMyDcsCameraProcessing->getRosMsg());
    }

    if (mMyLidarProcessing != nullptr)
    {
        mLidar_pub.publish(mMyLidarProcessing->getRosMsg());
    }

    if (mMyGPSProcessing != nullptr)
    {
        mGps_infopub.publish(mMyGPSProcessing->getRosGPSMsg());
        mGps_imupub.publish(mMyGPSProcessing->getRosIMUMsg());   
    }

    if (mMyTelemetriesProcessing != nullptr)
    {
        mTelmetry_pub.publish(mMyTelemetriesProcessing->getRosMsg());
    }

    if (mMyRadarProcessing != nullptr)
    {
        mRadar_pub.publish(mMyRadarProcessing->getRosMsg());
    }

    if (mMyDOGTProcessing != nullptr)
    {
        mDogt_pub.publish(mMyDOGTProcessing->getDogtRosMsg());
    }

    if (mMyROIProcessing != nullptr)
    {
        mRoi_pub.publish(mMyROIProcessing->getRoiRosMsg());
    }
}

void SampleCode::sendNewCommands()
{
    processKeypress();

    getSimulationParams();

    // check for exit key
    if (mKeyPressed == 'Q')
    {
        releaseKeyboard();
        ROS_INFO("Q pressed, exiting");
        mErr = mSim->stop(22, "Sample disengagement");
        mIsRunning = false;
    }
}

void SampleCode::disconnect()
{
    // Disconnect - House keeping, cleaning resources even though the resources will be closed properly
    // -----------------------------------------------------------------------------------
    ROS_INFO("disconnecting");

    mErr = mSim->disconnectFromEngine();

    THROW_IF_ERR("disconnect failed.", DISCONNECT_FAILED);
}

void SampleCode::recalcAcceleration()
{
    mClientAcceleration = mClientGas - mClientBrake;
}

void SampleCode::increaseAcceleration()
{
    recalcAcceleration();
    if (mClientAcceleration >= 0)
    {
        mClientAcceleration = std::min(mClientAcceleration + kGasStep, kGasMax);
        mClientGas = mClientAcceleration;
        mClientBrake = 0.0f;
    }
    else
    {
        mClientAcceleration = std::min(mClientAcceleration + kBrakeStep, kBrakeMax);
        if (mClientAcceleration < 0)
        {
            mClientBrake = std::max(-1*mClientAcceleration, kBrakeMin);
            mClientGas = 0;
        }
        else // we tipped it over
        {
            mClientGas = std::max(0.0f, kGasMin);
            mClientBrake = 0.0f;
            recalcAcceleration();
        }
    }
}

void SampleCode::decreaseAcceleration()
{
    recalcAcceleration();
    if (mClientAcceleration > 0)
    {
        mClientAcceleration = std::max(mClientAcceleration - kGasStep, -1*kBrakeMax);
        if (mClientAcceleration > 0)
        {
            mClientGas = mClientAcceleration;
            mClientBrake = 0.0f;
        }
        else // we tipped it over
        {
            mClientBrake = std::min(-1*mClientAcceleration,kBrakeMin);
            mClientGas = 0.0f;
            recalcAcceleration();
        }
    }
    else // m_ClientAcceleration =< 0
    {
        mClientAcceleration = std::max(mClientAcceleration - kBrakeStep, -1*kBrakeMax);
        mClientBrake = -1*mClientAcceleration;
        mClientGas = 0.0f;
    }
}

void SampleCode::publishCarControlCommand(DrivingCommandParts cmd_type)
{
    Float32MsgPtr command(new Float32Msg);
    
    switch (cmd_type)
    {
        case GAS_CMD :
        {
            command->data = mClientGas;
            mCarGasCMD_pub.publish(command);
            break;
        }

        case BRAKES_CMD :
        {
            command->data = mClientBrake;
            mCarBrakeCMD_pub.publish(command);
            break;
        }

        case STEERING_CMD :
        {
            command->data = mClientSteering;
            mCarSteerCMD_pub.publish(command);
            break;
        }

        case ACCELERATION_CMD :
        {
            command->data = mClientAcceleration;
            mCarAccelerationCMD_pub.publish(command);
            break;  
        }
    }
}

void SampleCode::processKeypress()
{
    mKeyPressed = getKey();

    if (mKeyPressed != -1)
    {
        switch (mKeyPressed)
        {
            //using ROS intraproccess communication for car controls
            case '1': // increase gas
            {
                if (mClientEgoCarUseAI == false)
                {
                    mClientGas = std::min(mClientGas + kGasStep, kGasMax);
                    recalcAcceleration();
                    publishCarControlCommand(GAS_CMD);
                }
                break;
            }

            case '2': // decrease gas
            {
                if (mClientEgoCarUseAI == false)
                {
                    mClientGas = std::max(mClientGas - kGasStep, kGasMin);
                    recalcAcceleration();
                    publishCarControlCommand(GAS_CMD);
                }
                break;
            }

            case '3': // increase brakes
            { 
                if (mClientEgoCarUseAI == false)
                {
                    mClientBrake = std::min(mClientBrake + kBrakeStep, kBrakeMax);
                    recalcAcceleration();
                    publishCarControlCommand(BRAKES_CMD);
                }
                break;
            }
			
			case '4': // decrease brakes
            {
                if (mClientEgoCarUseAI == false)
                {
                    mClientBrake = std::max(mClientBrake - kBrakeStep, kBrakeMin);
                    recalcAcceleration();
                    publishCarControlCommand(BRAKES_CMD);
                }
                break;
            }

			case 'W': // increase acceleration
            {
                if (mClientEgoCarUseAI == false)
                {
                    increaseAcceleration();
                    publishCarControlCommand(ACCELERATION_CMD);
                }
                break;
            }

            case 'S': // decrease acceleration
            {
                if (mClientEgoCarUseAI == false)
                {
                    decreaseAcceleration();
                    publishCarControlCommand(ACCELERATION_CMD);
                }
                break;
            }
     
            case 'D':
            {
                if (mClientEgoCarUseAI == false)
                {
                    //intraproccess communication for car controls
                    mClientSteering = std::min(mClientSteering + kSteeringStep, kSteeringMax);
                    publishCarControlCommand(STEERING_CMD);
                }
                break;
            }

            case 'A':
            {
                if (mClientEgoCarUseAI == false)
                {
                    //intraproccess communication for car controls
                    mClientSteering = std::max(mClientSteering - kSteeringStep, kSteeringMin);
                    publishCarControlCommand(STEERING_CMD);
                }
                break;
            }

            case 'P':
            {
                mPause = !mPause;
                ROS_INFO("Pause: %d", mPause);

                // Sample code :
                // Pause is not an SDK command. 
                // It is added here for convenience only. Hence it does not have a dedicated ROS publisher and subscriver.
                // If needed - either :
                //    a. add a pause-request ROS command 
                // or 
                //    b. Advance by frames using the SDK's command : CognataSim::advanceFramesAndBlockForMessages(float timeoutInSeconds)          

                break;
            }

            case 'M':
            {
                Int8MsgPtr command(new Int8Msg);
                command->data = -1;
                mCarDriver_pub.publish(command);

                mClientEgoCarUseAI = false;
                ROS_INFO("Ego Car Use AI: %d", mClientEgoCarUseAI);

                // sending an acceleraion command to activate the manual driving :
                recalcAcceleration();
                publishCarControlCommand(ACCELERATION_CMD);
                break;
            }

            case 'N':
            {
                Int8MsgPtr command(new Int8Msg);
                command->data = 1;
                mCarDriver_pub.publish(command);

                mClientEgoCarUseAI = true;
                ROS_INFO("Ego Car Use AI: %d", mClientEgoCarUseAI);
                break;
            }
        }
    }
}

void SampleCode::getSimulationParams()
{
    // get current simulation time
    float time = 0;
    mErr = mSim->getCurrSimulationTime(time);

    THROW_IF_ERR("Get current Simulation Time failed.", QUERY_SIMULATION_TIME_FAILED);

    mDt = time - mLastTime;
    mLastTime = time;

    // get current frame
    unsigned int frame;
    mErr = mSim->getCurrFrame(frame);

    THROW_IF_ERR("Get current Simulation Frame failed.", QUERY_SIMULATION_FRAME_FAILED);
}

void SampleCode::carGasCMDCallback(const Float32Msg &msg)
{
    mSrvGas = (float)msg.data;

    std::string logMessage("Car Command: partial driving command msg format : ");
    logMessage += "Gas: " + std::to_string(mSrvGas);

    mErr = mSim->sendCarControlGasCmd(EgoCarNumber,mSrvGas);
    THROW_IF_ERR("Send manual driver failed for partial message.", SEND_PARTIAL_MANUAL_DRIVER_FAILED);

    // The SDK does not check if we are in a Manual or AI Driving states. Sending car control commands automatically 
    // switches off the AI driving control and hands over the vehicle control to the SDK. Hence we'll update the local state variable :
    mServerEgoCarUseAI = false;
    
    // Add Engine-Log message (optional)
    mErr = mSim->log(1, logMessage);
    THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);
    // Add ROS log message
    ROS_INFO("Updated Gas to %f. Last SENT values: [Steering = %f, Gas = %f, Brake = %f, Acceleration = %f] ",mSrvGas, mSrvSteering, mSrvGas, mSrvBrake, mSrvAcceleration);
}

void SampleCode::carBrakeCMDCallback(const Float32Msg &msg)
{
    mSrvBrake = (float)msg.data;

    std::string logMessage("Car Command: partial driving command msg format : ");
    logMessage += "Brake: " + std::to_string(mSrvBrake);

    mErr = mSim->sendCarControlBrakesCmd(EgoCarNumber,mSrvBrake);
    THROW_IF_ERR("Send manual driver failed for partial message.", SEND_PARTIAL_MANUAL_DRIVER_FAILED);

    // The SDK does not check if we are in a Manual or AI Driving states. Sending car control commands automatically 
    // switches off the AI driving control and hands over the vehicle control to the SDK. Hence we'll update the local state variable :
    mServerEgoCarUseAI = false;
    
    // Add Engine-Log message (optional)
    mErr = mSim->log(1, logMessage);
    THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);
    // Add ROS log message
    ROS_INFO("Updated Brake to %f. Last SENT values: [Steering = %f, Gas = %f, Brake = %f, Acceleration = %f] ",mSrvBrake, mSrvSteering, mSrvGas, mSrvBrake, mSrvAcceleration);
}

void SampleCode::carSteerCMDCallback(const Float32Msg &msg)
{
    mSrvSteering = (float)msg.data;

    std::string logMessage("Car Command: partial driving command msg format : ");
    logMessage += "Steering: " + std::to_string(mSrvSteering);

    mErr = mSim->sendCarControlSteeringCmd(EgoCarNumber,mSrvSteering);
    THROW_IF_ERR("Send manual driver failed for partial message.", SEND_PARTIAL_MANUAL_DRIVER_FAILED);

    // The SDK does not check if we are in a Manual or AI Driving states. Sending car control commands automatically 
    // switches off the AI driving control and hands over the vehicle control to the SDK. Hence we'll update the local state variable :
    mServerEgoCarUseAI = false;
    
    // Add Engine-Log message (optional)
    mErr = mSim->log(1, logMessage);
    THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);
    // Add ROS log message
    ROS_INFO("Updated Steering to %f. Last SENT values: [Steering = %f, Gas = %f, Brake = %f, Acceleration = %f] ",mSrvSteering, mSrvSteering, mSrvGas, mSrvBrake, mSrvAcceleration);
}

void SampleCode::carAccelerationCMDCallback(const Float32Msg &msg)
{
    mSrvAcceleration = (float)msg.data;

    std::string logMessage("Car Command: partial driving command msg format : ");
    logMessage += "Acceleration: " + std::to_string(mSrvAcceleration);

    mErr = mSim->sendCarControlAccelerationCmd(EgoCarNumber,mSrvAcceleration);
    THROW_IF_ERR("Send manual driver failed for partial message.", SEND_PARTIAL_MANUAL_DRIVER_FAILED);

    // The SDK does not check if we are in a Manual or AI Driving states. Sending car control commands automatically 
    // switches off the AI driving control and hands over the vehicle control to the SDK. Hence we'll update the local state variable :
    mServerEgoCarUseAI = false;
    
    // Add Engine-Log message (optional)
    mErr = mSim->log(1, logMessage);
    THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);    
    // Add ROS log message
    ROS_INFO("Updated Acceleration to %f. Last SENT values: [Steering = %f, Gas = %f, Brake = %f, Acceleration = %f] ",mSrvAcceleration, mSrvSteering, mSrvGas, mSrvBrake, mSrvAcceleration);
}

void SampleCode::carDriverCallback(const Int8Msg &msg)
{
    int8_t aIDriverTurnOn = (int8_t)msg.data;
    if (aIDriverTurnOn > 0)
    {
        uint32_t currCarID = EgoCarNumber;

        mErr = mSim->sendAiDriveCarCmd(currCarID);
        THROW_IF_ERR("Send AI driver failed.", SEND_AI_DRIVER_FAILED);
        
        mServerEgoCarUseAI = true;

        // create log message
        std::string logMessage("Car Command: Activate AI Driving.");

        // Add Engine-Log message (optional)
        mErr = mSim->log(1, logMessage);
        THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);
        // Add ROS log message
        ROS_INFO("Requesting AI Driver activation.");
    }
    else if (aIDriverTurnOn < 0)
    {   // Note : Actual Manual (SDK) Driving for the Simulation Engine is activated by sending driving command (gas/brake/steer/acceleration) and not by this flag.
        // This flag is for sample purposes only.
        mServerEgoCarUseAI = false;
        // Add Engine-Log message (optional)
        std::string logMessage("Car Log: Activate Manual Driving flagged. Actual Manual Driving is activated by a driving command and not by this flag.");
        mErr = mSim->log(1, logMessage);
        THROW_IF_ERR("log failed.", LOG_CAR_COMMAND_FAILED);
        
        // Add ROS log message
        ROS_INFO("Enabling Manual/SDK driver ");
    }
}
