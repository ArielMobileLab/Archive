#!/usr/bin/env python
# scripts for Cognata_ROS1_SDK that enable simulator teleoperation control for EGO car via wheel and pedals inputs.
# for Cognata SDK_ROS1-v0.1.04 and G920 wheel and pedals.
# include acc control and speed display with brake response to stop acc

import rospy
import math
import keyboard  # Requires Super User (sudo -s)
import json
import datetime
from cognata_sdk.msg import DOGTOutput
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import Float32, Int8
from sensor_msgs.msg import Joy

closeList = []


class fonts:  # works only for print() function
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class front_car:
    id = -1
    distance_x = 0
    distance_y = 0
    velocity_x = 0
    velocity_y = 0


class adaptive_cruise_control:

    def __init__(self):
        rospy.init_node('adaptive_cruise_control_node', anonymous=True)
        self.in_session = False  # for running and shutting down purposes
        rospy.on_shutdown(self.shutdown_handler)
        self.vehicleList = None
        self.ego_car_lane = 0
        self.car_cmd_steer = Float32()
        self.car_cmd_accel = Float32()
        self.car_cmd_brake = Float32()
        self.car_cmd_gas = Float32()
        self.car_cmd_accB = Float32()
        self.car_speed = Float32()
        self.acc_on = False  # ACC Flag
        self.keyboard_increment_factor = 0.1
        self.lane_size = 3.7  # meters
        self.front_car = front_car()
        self.currentListIdx = 0
        self.maximum_front_car_distance = 100  # Initializing maximum front car distance
        self.time_distance = 2.0
        self.reference_distance = 10.0  # Desired keeping distance
        self.error_percentage = 0.1  # 10% Error

        self.kp = 0.25  # PID control Parameters
        self.kd = 0.7
        self.ka = 1

        self.dogt_listener = rospy.Subscriber("/cognataSDK/dogt", DOGTOutput, self.DOGTcb)  # DOGT Listener
        self.gps_listener = rospy.Subscriber("/cognataSDK/GPS/info", NavSatFix, self.GPScb)  # GPS Listener
        self.wheel_listener = rospy.Subscriber("joy", Joy, self.WHEELcb)  # wheel Listener
        self.car_cmd_publisher_steer = rospy.Publisher('/cognataSDK/car_command/steer_cmd', Float32,
                                                       queue_size=10)  # Publisher
        self.car_cmd_publisher_accel = rospy.Publisher('/cognataSDK/car_command/acceleration_cmd', Float32,
                                                       queue_size=10)  # Publisher
        self.car_cmd_publisher_drive = rospy.Publisher('/cognataSDK/car_command/driver_cmd', Int8,
                                                       queue_size=10)  # Publisher
        self.car_cmd_publisher_brake = rospy.Publisher('/cognataSDK/car_command/brake_cmd', Float32,
                                                       queue_size=10)  # Publisher
        self.car_cmd_publisher_gas = rospy.Publisher('/cognataSDK/car_command/gas_cmd', Float32,
                                                     queue_size=10)  # Publisher

        print(fonts.YELLOW + "waiting for all topics to be avalable...")
        rospy.wait_for_message("/cognataSDK/dogt", DOGTOutput, 120)
        rospy.wait_for_message("/cognataSDK/GPS/info", NavSatFix, 120)
        print(fonts.BLUE + "starting ACC application" + fonts.ENDC)
        self.number_of_agents = len(self.vehicleList)
        # print(fonts.BOLD + fonts.BLUE + "Vehicle List Size = " +str(len(self.vehicleList))) # Printing Number of Vehicle Agents
        self.rate = rospy.Rate(10)  # 10 [Hz]
	    self.acc_on = True
        while not rospy.is_shutdown():
            self.keyboard_listener()
            self.car_cmd_publisher_steer.publish(self.car_cmd_steer)
            if (self.car_cmd_brake.data != 0.0):
                self.acc_on = False
            if (self.acc_on):
                print(fonts.BOLD + fonts.GREEN +"ACC IS ON")
                self.get_front_car()
                self.control()
                self.car_cmd_publisher_accel.publish(self.car_cmd_accel)
            else:
                print(fonts.BOLD + fonts.RED +"ACC IS OFF")
                self.car_cmd_publisher_brake.publish(self.car_cmd_brake)
                self.car_cmd_publisher_gas.publish(self.car_cmd_gas)
            self.rate.sleep()

        self.in_session = True

        # DOGT message callback

    def DOGTcb(self, msg):
        self.vehicleList = msg.vehicleList
        for idx, car in enumerate(self.vehicleList):
            self.dista = pow(car.description.boundingBox.transform.translation.x, 2) + pow(
                car.description.boundingBox.transform.translation.y, 2)
            if ((math.sqrt(self.dista)) < 10):
                closeList.append(str((0.03 * msg.header.seq)) + ": " + (
                            str(car.description.ROISubtype) + " Number " + str(
                        car.description.objectId) + " in lane " + str(-int(car.laneId)) + " (X:" + str(
                        ('%.3f' % car.description.boundingBox.transform.translation.x)) + " ,Y:" + str(
                        ('%.3f' % car.description.boundingBox.transform.translation.y)) + ")"))
                #print("Close Vehicle:" + str('%.3f' % (math.sqrt(self.dista))))

    # GPS message callback
    def GPScb(self, msg):
        self.ego_car_lane = msg.position_covariance_type
        self.car_speed = msg.longitude
        # print(fonts.GREEN + "Ego car lane ID = " + str(self.ego_car_lane))

    def WHEELcb(self, msg):
        self.car_cmd_steer.data = -1 * msg.axes[0]
        self.car_cmd_accB = msg.buttons[23]
        # if self.acc_on == 0:
        self.car_cmd_gas.data = (1 + msg.axes[2]) / 2
        self.car_cmd_brake.data = (1 + msg.axes[3]) / 2

    def shutdown_handler(self):
        # if self.in_session:
        print(fonts.BOLD + fonts.CYAN + "Quitting Adaptive Cruise Control")

    # Pull Front Car
    def get_front_car(self):

        # Initializing front car
        self.front_car.id = -1
        self.front_car.distance_y = 0
        self.front_car.distance_x = self.maximum_front_car_distance
        self.front_car.velocity = 0

        for idx, car in enumerate(self.vehicleList):
            if (-int(
                    car.laneId) == self.ego_car_lane and car.description.boundingBox.transform.translation.x > 0 and abs(
                    car.description.boundingBox.transform.translation.y) < self.lane_size):  #
                #print("Distance =" + str(car.description.boundingBox.transform.translation.x) + " to Car#" + str(idx) + " in vehicle list ")

                if (car.description.boundingBox.transform.translation.x < self.front_car.distance_x):
                    self.front_car.distance_x = car.description.boundingBox.transform.translation.x
                    self.front_car.distance_y = car.description.boundingBox.transform.translation.y
                    self.front_car.velocity_x = car.description.motion.linear.x
                    self.front_car.velocity_y = car.description.motion.angular.z
                    self.front_car.id = idx
                    # print("[" + self.vehicleList[idx].description.objectId + "," + self.vehicleList[idx].description.ROISubtype + "," + str(self.dist_to_front_car) + "]")
        # if (self.front_car.id >= 0):
        #     print("front car No." + fonts.BOLD + fonts.BLUE + self.vehicleList[self.front_car.id].description.objectId + fonts.ENDC + " is : " + fonts.BOLD + fonts.BLUE + self.vehicleList[self.front_car.id].description.ROISubtype + fonts.ENDC + ", with distance : "+ fonts.BOLD + fonts.BLUE +str(self.vehicleList[self.front_car.id].description.boundingBox.transform.translation.x) + fonts.ENDC)
        # else:
        #     print(fonts.BOLD + fonts.BLUE + "Maximum Space" + fonts.ENDC)
        # return 1

    #   PID control for applying adaptive cruise
    def control(self):
        # X Control
        error = self.front_car.distance_x - self.reference_distance #distance
        error_dot = self.front_car.velocity_x  # - ego_car_speed
        error_itg = 0  #
        output = self.kp * error + self.kd * error_dot + self.ka * error_itg

        if ((error/self.reference_distance) > self.error_percentage) or ((error/self.reference_distance) < -self.error_percentage):
         print(fonts.ENDC + "no car in lane")
         
        else:
         print(fonts.ENDC + "distance = " + fonts.GREEN + str(error/self.reference_distance * 100)[0:5] + "%")
         


        if (error / self.reference_distance) >= 4:      #speed limit to 75 (ratio of 15 speed to acceleration)
            self.car_cmd_accel.data = 5 / self.car_speed

        else:
            self.car_cmd_accel.data = output
        # self.car_cmd_accel.data = self.clamp(output, -1, 1)

    def keyboard_listener(self):
        if keyboard.is_pressed('escape'):
            quit()
        if keyboard.is_pressed('space'):
            if not self.acc_on:
                print(fonts.BOLD + fonts.GREEN + "ACC Activated" + fonts.ENDC)
                self.acc_on = True
            else:
                print(fonts.BOLD + fonts.RED + "ACC Disengage" + fonts.ENDC)
                self.acc_on = False
        # self.car_cmd_steer.data = self.clamp(self.car_cmd_steer.data, -1, 1)
        # self.car_cmd_accel.data = self.clamp(self.car_cmd_accel.data, -1, 1)

    # Clamp
    def clamp(n, smallest, largest):
        return max(smallest, min(n, largest))
    # def on_key_release(self):
    #     if keyboard.is_released('w'):
    #         print(fonts.BOLD + fonts.CYAN + "W key released")
    #     if keyboard.is_released('s'):
    #         print(fonts.BOLD + fonts.CYAN + "S key released")
    #     if keyboard.is_released('a'):
    #         print(fonts.BOLD + fonts.CYAN + "A key released")
    #     if keyboard.is_released('d'):
    #         print(fonts.BOLD + fonts.CYAN + "D key released")


if __name__ == '__main__':
    try:
        adaptive_cruise_control()
        print(fonts.BOLD + fonts.CYAN + "Quitting Adaptive Cruise Control")
    except rospy.ROSInterruptException:
        rospy.loginfo("adaptive_cruise_control_node finished")
