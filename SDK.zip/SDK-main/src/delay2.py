#!/usr/bin/env python
from sensor_msgs.msg import Joy
import functools
import rospy

rospy.init_node("delay")

pub = rospy.Publisher("delayed", Joy, queue_size=4)
print("delay2")

def delayed_callback(msg, event):
    pub.publish(msg)


def callback(msg):
    timer = rospy.Timer(rospy.Duration(0.15), functools.partial(delayed_callback, msg), oneshot=True)


sub = rospy.Subscriber("joy", Joy, callback, queue_size=4)
rospy.spin()
